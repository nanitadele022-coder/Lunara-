# Lunara — Production Deployment Guide

This guide details the optimized production pipeline, environment configs, and target cloud platforms for deploying **Lunara** (Soft Luxury Digital Planner & Mindfulness Portal) securely.

---

## 🏛️ Build & Chunk-Splitting Optimization

Lunara features high-fidelity visual structures and interactive dashboards (powered by `recharts`, `lucide-react`, and `motion`). To ensure lightning-fast entry-point loads, the build settings are optimized inside `/vite.config.ts` via **rollup dynamic code-splitting**.

### 📦 Key Bundler Settings
- **Chunk Segmentation**: Third-party packages inside `node_modules` are separated into target cacheable modules (`vendor-react`, `vendor-charts`, `vendor-motion`, and `vendor-icons`).
- **Assets Compression**: Sourcemaps are deactivated for optimized bundle minification.
- **Visual Performance**: Asset file delivery handles long-term immutable cache-control headers.

---

## ⚡ Vercel Deployment (Recommended)

Lunara is fully configured with a native standalone `vercel.json` descriptor in the workspace root.

### 1. Injected Routing File (`vercel.json`)
The Vercel router is equipped to:
* Rewrite all dynamic client-side SPA links back to `/index.html` to avoid `404 Not Found` errors on nested page refreshes.
* Inject `Cache-Control` static headers for `/assets/` and static graphics to maximize edge CDN delivery rates.

### 2. Steps to Deploy
1. Install Vercel CLI locally if preferred:
   ```bash
   npm install -g vercel
   ```
2. Initiate connection and deploy:
   ```bash
   vercel
   ```
3. For final production promotion:
   ```bash
   vercel --prod
   ```

---

## 🔥 Firebase Provisioning (Firestore & Rules)

If synchronized cloud state has been activated in your AI Studio dashboard, follow these simple guidelines to secure your production database.

### 1. Deploy Security Rules
Verify that the `firestore.rules` are updated and locked:
```bash
firebase deploy --only firestore:rules
```

### 2. Live Rules Schema
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      
      match /tasks/{document} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
      match /habits/{document} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
      match /journals/{document} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
      match /budgetItems/{document} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
      match /savingGoals/{document} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
      match /goals/{document} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
  }
}
```

---

## 🔒 Environment Variable Guidelines

All production secrets should be managed in your Deployment Settings panel or Environment Console.

| Variable Name | Environment | Description |
| :--- | :--- | :--- |
| `VITE_FIREBASE_API_KEY` | Client-side | General Web API key for Auth handshakes |
| `VITE_FIREBASE_PROJECT_ID` | Client-side | Project Identifier for Cloud DB matching |
| `VITE_FIREBASE_AUTH_DOMAIN` | Client-side | Custom Auth domain mapping |

> ⚠️ **Security Notice**: Never prefix private admin keys with `VITE_` as Vite automatically compiles and exposes variables with this prefix directly to the browser client bundle.

---

## 🚀 Standard Production Compilation
To compile optimized output folders manually for generic static hosting services (Netlify, AWS S3, Cloudflare Pages, GitHub Pages):

```bash
# Install dependencies
npm install

# Run type check & build static HTML/JS index structures
npm run build
```
Production assets will compile gracefully into the `/dist` directory.
