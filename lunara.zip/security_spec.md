# Lunara Application Security Spec

## 1. Data Invariants

For our `users/{userId}` collection storing user profiles:
- A user profile must ONLY be readable and writeable by the authenticated owner (`request.auth.uid == userId`).
- Users must be logged in and possess an email-verified state (when using official accounts) to register.
- User profile data must strictly conform to allowed shapes and string size boundaries to prevent wallet denial attacks.

## 2. The "Dirty Dozen" Malicious Payloads

The following payloads violate user privacy or shape invariants and must encounter `PERMISSION_DENIED`:

1. **Identity Theft Read**: Requesting `/users/user_alice` profile when logged in as `user_bob`.
2. **Anonymous Write**: Attempting to create user profiles without a valid auth token.
3. **Ghost Field Write**: Creating/updating user profile with unmapped properties like `isAdmin: true` or `role: 'premium'`.
4. **Spoofed Ownership**: Logged as `user_bob`, attempting to write to `/users/user_bob` but setting the `email` of `user_alice`.
5. **Huge Name Payload**: Setting a user `name` field of over 10KB to trigger resource exhaustion.
6. **Malicious ID Poisioning**: Attempting to write a document at path `/users/!!malicious_garbage_id$$` with non-matching characters.
7. **Invalid Theme Setting**: Attempting to set theme to an unsanctioned value like `'extreme-brutalist'`.
8. **Negative Length Values**: Bypassing size logic by injecting negative values.
9. **Unverified Email Register**: Attempting to register standard email/password user profile when `email_verified` is false (for email-based sign-up flows requiring verification).
10. **Null Value Tampering**: Overwriting mandatory fields with `null`.
11. **Immutability Breach**: Overwriting persistent fields on existing profile directories.
12. **Wildcard Write bypass**: Bypassing match filters using collection paths in IDs.

## 3. The Rules Test Blueprint
The complete standard ruleset will run validations on all operations, enforcing that all 12 scenarios get rejected.
