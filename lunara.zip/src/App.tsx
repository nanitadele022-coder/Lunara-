import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Calendar,
  CheckCircle2,
  DollarSign,
  PenTool,
  Sparkles,
  Target,
  Settings as SettingsIcon,
  Home,
  LogOut,
  Menu,
  X,
  User,
  Bell,
  Sun,
  Moon,
  Volume2,
  RefreshCw,
  HelpCircle,
} from 'lucide-react';

// Custom component imports
import LandingPage from './components/LandingPage';
import AuthPages from './components/AuthPages';
import Onboarding from './components/Onboarding';
import { useAuth } from './context/AuthContext';
import Dashboard from './components/Dashboard';
import DailyPlanner from './components/DailyPlanner';
import HabitTracker from './components/HabitTracker';
import BudgetPlanner from './components/BudgetPlanner';
import Journal from './components/Journal';
import GoalTracker from './components/GoalTracker';
import SettingsView from './components/Settings';

// Firestore CRUD and Sync imports
import {
  syncTasks,
  saveTask,
  deleteTask,
  syncHabits,
  saveHabit,
  deleteHabit,
  syncJournals,
  saveJournal,
  deleteJournal,
  syncBudgetItems,
  saveBudgetItem,
  deleteBudgetItem,
  syncSavingGoals,
  saveSavingGoal,
  deleteSavingGoal,
  syncSMARTGoals,
  saveSMARTGoal,
  deleteSMARTGoal,
} from './lib/firestoreService';

// Global Types and Initial Data Seeding
import {
  Task,
  Habit,
  BudgetItem,
  SavingGoal,
  JournalEntry,
  SMARTGoal,
  UserProfile,
  AppNotification,
  INITIAL_TASKS,
  INITIAL_HABITS,
  INITIAL_BUDGET,
  INITIAL_SAVING_GOALS,
  INITIAL_JOURNAL,
  INITIAL_GOALS,
} from './types';

// Helper local loaders with defaults
const loadLocal = <T,>(key: string, backup: T): T => {
  const saved = localStorage.getItem(key);
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      console.warn('Parsing error on', key);
    }
  }
  return backup;
};

export default function App() {
  const [selectedPage, setSelectedPage] = useState<string>('landing');
  const [selectedDate, setSelectedDate] = useState<string>('2026-05-23'); // seeding current calendar date
  const [syncLoading, setSyncLoading] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Modern Premium Toast and modal notifications
  interface ToastMessage {
    id: string;
    text: string;
    type: 'info' | 'success' | 'warning' | 'error';
  }
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const showToast = (text: string, type: ToastMessage['type'] = 'success') => {
    const id = `toast-${Date.now()}`;
    setToasts((prev) => [...prev, { id, text, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  interface ModalConfig {
    isOpen: boolean;
    title: string;
    message: string;
    confirmLabel?: string;
    cancelLabel?: string;
    onConfirm?: () => void;
  }
  const [modal, setModal] = useState<ModalConfig>({
    isOpen: false,
    title: '',
    message: '',
  });

  const showModal = (
    title: string,
    message: string,
    onConfirm: () => void,
    confirmLabel = 'Confirm',
    cancelLabel = 'Cancel'
  ) => {
    setModal({
      isOpen: true,
      title,
      message,
      confirmLabel,
      cancelLabel,
      onConfirm: () => {
        onConfirm();
        setModal((prev) => ({ ...prev, isOpen: false }));
      }
    });
  };

  // Core application states loaded from Firebase Authentication
  const { currentUser, userProfile, logoutUser, updateProfileOnboardState, updateProfileTheme, isFirebaseActive } = useAuth();
  
  const [tasks, setTasks] = useState<Task[]>(() =>
    loadLocal<Task[]>('lunara_tasks', INITIAL_TASKS)
  );
  const [habits, setHabits] = useState<Habit[]>(() =>
    loadLocal<Habit[]>('lunara_habits', INITIAL_HABITS)
  );
  const [budgetItems, setBudgetItems] = useState<BudgetItem[]>(() =>
    loadLocal<BudgetItem[]>('lunara_budget', INITIAL_BUDGET)
  );
  const [savingGoals, setSavingGoals] = useState<SavingGoal[]>(() =>
    loadLocal<SavingGoal[]>('lunara_saving_goals', INITIAL_SAVING_GOALS)
  );
  const [journals, setJournals] = useState<JournalEntry[]>(() =>
    loadLocal<JournalEntry[]>('lunara_journals', INITIAL_JOURNAL)
  );
  const [goals, setGoals] = useState<SMARTGoal[]>(() =>
    loadLocal<SMARTGoal[]>('lunara_goals', INITIAL_GOALS)
  );

  const [notifications, setNotifications] = useState<AppNotification[]>([
    {
      id: 'n-1',
      text: 'Welcome to your digital planner portal. Your offline environment is secure.',
      date: '2026-05-23',
      read: false,
      category: 'system',
    },
  ]);

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return loadLocal<boolean>('lunara_theme_dark', false);
  });

  // Real-time synchronization of all planner features with Firestore
  useEffect(() => {
    if (!currentUser || !isFirebaseActive) return;

    const unsubTasks = syncTasks(currentUser.uid, (syncedTasks) => {
      setTasks(syncedTasks);
    });
    const unsubHabits = syncHabits(currentUser.uid, (syncedHabits) => {
      setHabits(syncedHabits);
    });
    const unsubJournals = syncJournals(currentUser.uid, (syncedJournals) => {
      setJournals(syncedJournals);
    });
    const unsubBudget = syncBudgetItems(currentUser.uid, (syncedBudget) => {
      setBudgetItems(syncedBudget);
    });
    const unsubSavingGoals = syncSavingGoals(currentUser.uid, (syncedSavingGoals) => {
      setSavingGoals(syncedSavingGoals);
    });
    const unsubSMARTGoals = syncSMARTGoals(currentUser.uid, (syncedGoals) => {
      setGoals(syncedGoals);
    });

    return () => {
      unsubTasks();
      unsubHabits();
      unsubJournals();
      unsubBudget();
      unsubSavingGoals();
      unsubSMARTGoals();
    };
  }, [currentUser, isFirebaseActive]);

  // Automatically manage route gate status for authenticated sessions
  useEffect(() => {
    if (userProfile) {
      if (selectedPage === 'landing' || selectedPage === 'auth') {
        if (userProfile.onboarded) {
          setSelectedPage('dashboard');
        } else {
          setSelectedPage('onboarding');
        }
      }
    } else {
      if (selectedPage !== 'landing' && selectedPage !== 'auth') {
        setSelectedPage('landing');
      }
    }
  }, [userProfile, selectedPage]);

  useEffect(() => {
    localStorage.setItem('lunara_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('lunara_habits', JSON.stringify(habits));
  }, [habits]);

  useEffect(() => {
    localStorage.setItem('lunara_budget', JSON.stringify(budgetItems));
  }, [budgetItems]);

  useEffect(() => {
    localStorage.setItem('lunara_saving_goals', JSON.stringify(savingGoals));
  }, [savingGoals]);

  useEffect(() => {
    localStorage.setItem('lunara_journals', JSON.stringify(journals));
  }, [journals]);

  useEffect(() => {
    localStorage.setItem('lunara_goals', JSON.stringify(goals));
  }, [goals]);

  // Apply dark class to body dynamically
  useEffect(() => {
    localStorage.setItem('lunara_theme_dark', JSON.stringify(darkMode));
    const target = document.body;
    if (darkMode) {
      target.classList.add('dark');
      target.style.backgroundColor = '#1C191D';
      target.style.color = '#F7F3EE';
    } else {
      target.classList.remove('dark');
      target.style.backgroundColor = '#F7F3EE';
      target.style.color = '#3A3640';
    }
  }, [darkMode]);

  // Unified Handler Events
  const handleOnboardingComplete = (name: string, lifestyle: string) => {
    updateProfileOnboardState(name, lifestyle);

    // Customize pre-seeded tasks slightly based on the selected lifestyle
    if (lifestyle === 'student') {
      const studentTasks: Task[] = [
        {
          id: 'st-1',
          text: 'Finish research proposal draft chapter',
          completed: false,
          priority: 'high',
          timeSlot: '10:00 - 12:00',
          date: '2026-05-23',
          category: 'Study',
        },
        ...tasks,
      ];
      setTasks(studentTasks);
    }
    setSelectedPage('dashboard');
  };

  const handleAddTask = (item: Omit<Task, 'id'>) => {
    const newTask: Task = {
      ...item,
      id: `task-node-${Date.now()}`,
    };
    if (currentUser && isFirebaseActive) {
      saveTask(currentUser.uid, newTask);
    } else {
      setTasks([newTask, ...tasks]);
    }
  };

  const handleToggleTask = (id: string) => {
    const targetTask = tasks.find((t) => t.id === id);
    if (!targetTask) return;
    const updatedTask = { ...targetTask, completed: !targetTask.completed };

    if (currentUser && isFirebaseActive) {
      saveTask(currentUser.uid, updatedTask);
    } else {
      setTasks(
        tasks.map((t) => (t.id === id ? updatedTask : t))
      );
    }
  };

  const handleDeleteTask = (id: string) => {
    if (currentUser && isFirebaseActive) {
      deleteTask(currentUser.uid, id);
    } else {
      setTasks(tasks.filter((t) => t.id !== id));
    }
  };

  const handleToggleHabit = (id: string, date: string) => {
    const targetHabit = habits.find((h) => h.id === id);
    if (!targetHabit) return;

    const completed = targetHabit.completedDates.includes(date);
    let nextDates = [...targetHabit.completedDates];
    if (completed) {
      nextDates = nextDates.filter((d) => d !== date);
    } else {
      nextDates.push(date);
    }
    const newStreaks = completed ? Math.max(0, targetHabit.streaks - 1) : targetHabit.streaks + 1;

    const updatedHabit = {
      ...targetHabit,
      completedDates: nextDates,
      streaks: newStreaks,
    };

    if (currentUser && isFirebaseActive) {
      saveHabit(currentUser.uid, updatedHabit);
    } else {
      setHabits(
        habits.map((h) => (h.id === id ? updatedHabit : h))
      );
    }
  };

  const handleAddHabit = (
    name: string,
    category: string,
    frequency: 'daily' | 'weekly'
  ) => {
    const newHabit: Habit = {
      id: `habit-node-${Date.now()}`,
      name,
      category,
      streaks: 0,
      completedDates: [],
      createdAt: selectedDate,
      frequency,
    };
    if (currentUser && isFirebaseActive) {
      saveHabit(currentUser.uid, newHabit);
    } else {
      setHabits([newHabit, ...habits]);
    }
  };

  const handleDeleteHabit = (id: string) => {
    if (currentUser && isFirebaseActive) {
      deleteHabit(currentUser.uid, id);
    } else {
      setHabits(habits.filter((h) => h.id !== id));
    }
  };

  const handleAddBudgetItem = (item: Omit<BudgetItem, 'id'>) => {
    const newItem: BudgetItem = {
      ...item,
      id: `budget-node-${Date.now()}`,
    };
    if (currentUser && isFirebaseActive) {
      saveBudgetItem(currentUser.uid, newItem);
    } else {
      setBudgetItems([newItem, ...budgetItems]);
    }
  };

  const handleDeleteBudgetItem = (id: string) => {
    if (currentUser && isFirebaseActive) {
      deleteBudgetItem(currentUser.uid, id);
    } else {
      setBudgetItems(budgetItems.filter((b) => b.id !== id));
    }
  };

  const handleAddSavingGoal = (
    title: string,
    targetAmount: number,
    currentAmount: number,
    category: string
  ) => {
    const newGoal: SavingGoal = {
      id: `saving-goal-${Date.now()}`,
      title,
      targetAmount,
      currentAmount,
      category,
    };
    if (currentUser && isFirebaseActive) {
      saveSavingGoal(currentUser.uid, newGoal);
    } else {
      setSavingGoals([newGoal, ...savingGoals]);
    }
  };

  const handleDeleteSavingGoal = (id: string) => {
    if (currentUser && isFirebaseActive) {
      deleteSavingGoal(currentUser.uid, id);
    } else {
      setSavingGoals(savingGoals.filter((g) => g.id !== id));
    }
  };

  const handleUpdateSavingGoalProgress = (id: string, newAmount: number) => {
    const targetGoal = savingGoals.find((g) => g.id === id);
    if (!targetGoal) return;
    const updatedGoal = { ...targetGoal, currentAmount: newAmount };

    if (currentUser && isFirebaseActive) {
      saveSavingGoal(currentUser.uid, updatedGoal);
    } else {
      setSavingGoals(
        savingGoals.map((g) => (g.id === id ? updatedGoal : g))
      );
    }
  };

  const handleAddJournalEntry = (
    title: string,
    content: string,
    mood: any,
    prompt?: string
  ) => {
    const newJournal: JournalEntry = {
      id: `journal-node-${Date.now()}`,
      title,
      content,
      mood,
      reflectionPrompt: prompt,
      date: selectedDate,
    };
    if (currentUser && isFirebaseActive) {
      saveJournal(currentUser.uid, newJournal);
    } else {
      setJournals([newJournal, ...journals]);
    }
  };

  const handleDeleteJournalEntry = (id: string) => {
    if (currentUser && isFirebaseActive) {
      deleteJournal(currentUser.uid, id);
    } else {
      setJournals(journals.filter((j) => j.id !== id));
    }
  };

  const handleAddGoal = (goal: Omit<SMARTGoal, 'id' | 'progress'>) => {
    const newSMARTGoal: SMARTGoal = {
      ...goal,
      id: `smart-goal-${Date.now()}`,
      progress: 0,
    };
    if (currentUser && isFirebaseActive) {
      saveSMARTGoal(currentUser.uid, newSMARTGoal);
    } else {
      setGoals([newSMARTGoal, ...goals]);
    }
  };

  const handleDeleteGoal = (id: string) => {
    if (currentUser && isFirebaseActive) {
      deleteSMARTGoal(currentUser.uid, id);
    } else {
      setGoals(goals.filter((g) => g.id !== id));
    }
  };

  const handleToggleMilestone = (goalId: string, milestoneId: string) => {
    const targetGoal = goals.find((g) => g.id === goalId);
    if (!targetGoal) return;

    const updatedMilestones = targetGoal.milestones.map((m) =>
      m.id === milestoneId ? { ...m, completed: !m.completed } : m
    );

    // Calculate goals progress dynamically based on completed milestones
    const completedCount = updatedMilestones.filter((m) => m.completed).length;
    const totalCount = updatedMilestones.length;
    const nextProgress = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

    const updatedGoal = {
      ...targetGoal,
      milestones: updatedMilestones,
      progress: nextProgress,
    };

    if (currentUser && isFirebaseActive) {
      saveSMARTGoal(currentUser.uid, updatedGoal);
    } else {
      setGoals(
        goals.map((g) => (g.id === goalId ? updatedGoal : g))
      );
    }
  };

  const handleExportBackup = () => {
    const completeState = {
      profile: userProfile,
      tasks,
      habits,
      budget: budgetItems,
      savingGoals,
      journals,
      goals,
    };
    const blob = new Blob([JSON.stringify(completeState, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `lunara-digital-planner-registry-${selectedDate}.json`;
    link.click();
  };

  const handleTriggerSync = () => {
    setSyncLoading(true);
    setTimeout(() => {
      setSyncLoading(false);
      const newNotification: AppNotification = {
        id: `noti-${Date.now()}`,
        text: 'Sync Handshake Completed. All digital shelves harmonized with Celestial database structures.',
        date: selectedDate,
        read: false,
        category: 'system',
      };
      setNotifications([newNotification, ...notifications]);
      showToast('Celestial database sync complete. Workspace harmonized.', 'success');
    }, 1500);
  };

  const handleQuickAddTask = (text: string, priority: 'low' | 'medium' | 'high') => {
    handleAddTask({
      text,
      completed: false,
      priority,
      date: selectedDate,
      category: 'Creator',
    });
    showToast('Task node injected into today\'s stream.', 'success');
  };

  const handleLogout = () => {
    showModal(
      'Verify Departure',
      'Are you ready to depart from this private, securely sandboxed planning sanctuary?',
      () => {
        logoutUser();
        showToast('Sanctuary session ended gracefully.', 'info');
      },
      'Verify Departure',
      'Remain inside'
    );
  };

  // Nav Links helper
  const renderSidebarLinks = () => {
    const links = [
      { id: 'dashboard', label: 'Overview Dashboard', icon: <Home className="w-4 h-4" /> },
      { id: 'planner', label: 'Daily Planner Blocks', icon: <Calendar className="w-4 h-4" /> },
      { id: 'habit', label: 'Habit Ritual Stream', icon: <CheckCircle2 className="w-4 h-4" /> },
      { id: 'budget', label: 'Bento Cashflow Log', icon: <DollarSign className="w-4 h-4" /> },
      { id: 'journal', label: 'Reflection Musings', icon: <PenTool className="w-4 h-4" /> },
      { id: 'goals', label: 'SMART Target Board', icon: <Target className="w-4 h-4" /> },
      { id: 'settings', label: 'System Customizations', icon: <SettingsIcon className="w-4 h-4" /> },
    ];

    return (
      <nav className="space-y-1.5 pt-6 flex-1">
        {links.map((link) => {
          const isActive = selectedPage === link.id;
          return (
            <button
              key={link.id}
              onClick={() => {
                setSelectedPage(link.id);
                setMobileMenuOpen(false);
              }}
              style={{ contentVisibility: 'auto' }}
              className={`w-full flex items-center space-x-3.5 px-4.5 py-3 rounded-xl text-xs font-semibold transition-all relative ${
                isActive
                  ? 'bg-lavender text-white shadow-md shadow-lavender/10 font-bold'
                  : 'text-charcoal/70 dark:text-[#E9DCCF]/80 hover:bg-lavender/5 hover:text-lavender'
              }`}
            >
              {link.icon}
              <span>{link.label}</span>
            </button>
          );
        })}
      </nav>
    );
  };

  // Conditional Rendering Router
  const renderPageContent = () => {
    let content: React.ReactNode = null;
    switch (selectedPage) {
      case 'dashboard':
        content = (
          <Dashboard
            tasks={tasks}
            habits={habits}
            budgetItems={budgetItems}
            goals={goals}
            onQuickNavigate={(pg) => setSelectedPage(pg)}
            selectedDate={selectedDate}
            onChangeDate={setSelectedDate}
            userName={userProfile?.name || 'Graceful Planner'}
            onQuickAddTask={handleQuickAddTask}
            showToast={showToast}
          />
        );
        break;
      case 'planner':
        content = (
          <DailyPlanner
            tasks={tasks}
            onAddTask={handleAddTask}
            onToggleTask={handleToggleTask}
            onDeleteTask={handleDeleteTask}
            selectedDate={selectedDate}
            onChangeDate={setSelectedDate}
            showToast={showToast}
          />
        );
        break;
      case 'habit':
        content = (
          <HabitTracker
            habits={habits}
            onToggleHabit={handleToggleHabit}
            onAddHabit={handleAddHabit}
            onDeleteHabit={handleDeleteHabit}
            selectedDate={selectedDate}
            showToast={showToast}
          />
        );
        break;
      case 'budget':
        content = (
          <BudgetPlanner
            budgetItems={budgetItems}
            savingGoals={savingGoals}
            onAddBudgetItem={handleAddBudgetItem}
            onDeleteBudgetItem={handleDeleteBudgetItem}
            onAddSavingGoal={handleAddSavingGoal}
            onDeleteSavingGoal={handleDeleteSavingGoal}
            onUpdateSavingGoalProgress={handleUpdateSavingGoalProgress}
            selectedDate={selectedDate}
            showToast={showToast}
          />
        );
        break;
      case 'journal':
        content = (
          <Journal
            entries={journals}
            onAddEntry={handleAddJournalEntry}
            onDeleteEntry={handleDeleteJournalEntry}
            selectedDate={selectedDate}
            showToast={showToast}
          />
        );
        break;
      case 'goals':
        content = (
          <GoalTracker
            goals={goals}
            onAddGoal={handleAddGoal}
            onDeleteGoal={handleDeleteGoal}
            onToggleMilestone={handleToggleMilestone}
            showToast={showToast}
          />
        );
        break;
      case 'settings':
        content = (
          <SettingsView
            profile={userProfile!}
            onUpdateProfile={(updates) => {
              if (updates.name) {
                updateProfileOnboardState(updates.name, 'creator');
              }
              if (updates.theme) {
                updateProfileTheme(updates.theme as any);
              }
              showToast('Sanctuary settings applied with absolute harmony.', 'success');
            }}
            onExportBackup={handleExportBackup}
            onTriggerSync={handleTriggerSync}
            syncLoading={syncLoading}
            showToast={showToast}
          />
        );
        break;
      default:
        break;
    }

    return (
      <AnimatePresence mode="wait">
        {content && (
          <motion.div
            key={selectedPage}
            initial={{ opacity: 0, y: 12, filter: 'blur(3px)' }}
            animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
            exit={{ opacity: 0, y: -12, filter: 'blur(3px)' }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          >
            {content}
          </motion.div>
        )}
      </AnimatePresence>
    );
  };

  // Landing Router Switch
  if (selectedPage === 'landing') {
    return (
      <LandingPage
        onStartPlanning={() => setSelectedPage('auth')}
        onExploreFeatures={() => {
          const el = document.getElementById('features');
          el?.scrollIntoView({ behavior: 'smooth' });
        }}
      />
    );
  }

  if (selectedPage === 'auth') {
    return (
      <AuthPages
        onBackToLanding={() => setSelectedPage('landing')}
      />
    );
  }

  if (selectedPage === 'onboarding') {
    return <Onboarding onComplete={handleOnboardingComplete} />;
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 flex flex-col ${darkMode ? 'bg-[#1C191D]' : 'bg-[#F7F3EE]'}`}>
      {/* Upper Global status bar header */}
      <header className="relative z-20 flex items-center justify-between px-6 py-4 border-b border-soft-beige/25 bg-white/60 dark:bg-[#2B2730]/60 backdrop-blur-md no-print">
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-1.5 hover:bg-neutral-50 rounded-xl"
          >
            {mobileMenuOpen ? <X className="w-5 h-5 text-charcoal dark:text-cream" /> : <Menu className="w-5 h-5 text-charcoal dark:text-cream" />}
          </button>
          <div className="flex items-center space-x-2">
            <div className="w-7 h-7 rounded-full bg-lavender flex items-center justify-center">
              <span className="font-serif text-white font-bold text-xs">L</span>
            </div>
            <span className="font-serif text-lg tracking-wide font-medium text-charcoal dark:text-cream">Lunara</span>
          </div>
        </div>

        {/* Global Toolbar */}
        <div className="flex items-center space-x-4">
          {/* Theme custom toggle switcher */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 bg-cream/50 dark:bg-charcoal/40 hover:bg-lavender/5 rounded-xl transition-all cursor-pointer"
            title="Toggle Atmosphere mode"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-500" /> : <Moon className="w-4 h-4 text-[#9E8AC9]" />}
          </button>

          {/* User profile dropdown drawer indicator */}
          <div className="flex items-center space-x-2 bg-cream/40 px-3 py-1.5 rounded-full border border-soft-beige/20 text-xs">
            {userProfile?.avatarUrl ? (
              <img
                src={userProfile.avatarUrl}
                alt="Profile Avatar"
                className="w-5 h-5 rounded-full object-cover border border-lavender"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-5 h-5 rounded-full bg-lavender/25 text-dusty-lilac flex items-center justify-center">
                <User className="w-3 h-3" />
              </div>
            )}
            <span className="font-bold text-[11px] text-charcoal dark:text-cream hidden sm:inline">
              {userProfile?.name}
            </span>
          </div>
        </div>
      </header>

      {/* Main Container scaffold wrapping Sidebar & Router Body */}
      <div className="flex-1 flex max-w-7xl mx-auto w-full relative">
        {/* Desktop Sidebar Panel */}
        <aside className="hidden md:flex flex-col w-64 border-r border-soft-beige/25 bg-white/40 dark:bg-[#1C1822]/40 p-5 space-y-4 shrink-0 no-print">
          <div className="border-b border-soft-beige/10 pb-4">
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#B79CED]">Workspace Stream</span>
          </div>

          {renderSidebarLinks()}

          {/* Bottom user action logout */}
          <div className="pt-4 border-t border-soft-beige/15 space-y-2">
            <button
              onClick={handleTriggerSync}
              className="w-full py-2 bg-cream dark:bg-charcoal/20 text-charcoal dark:text-[#E9DCCF] text-[10px] font-bold tracking-widest uppercase rounded-lg hover:opacity-90 flex items-center justify-center space-x-1"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Database Sync</span>
            </button>
            <button
              onClick={handleLogout}
              className="w-full flex items-center space-x-3 px-4 py-2.5 text-xs text-red-650 hover:bg-red-50 rounded-xl transition-colors font-semibold"
            >
              <LogOut className="w-4 h-4" />
              <span>Tear Session out</span>
            </button>
          </div>
        </aside>

        {/* Mobile Sidebar Overlay Drawer */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 bg-charcoal/40 backdrop-blur-xs z-30 md:hidden no-print" onClick={() => setMobileMenuOpen(false)}>
            <div className="w-64 bg-[#F7F3EE] dark:bg-[#1C191D] h-full p-6 flex flex-col space-y-4 shadow-2xl animate-in slide-in-from-left" onClick={(e) => e.stopPropagation()}>
              <div className="flex justify-between items-center border-b border-soft-beige/25 pb-4">
                <span className="font-serif font-bold text-lg dark:text-cream">Menu shelf</span>
                <button onClick={() => setMobileMenuOpen(false)} className="p-1 hover:bg-neutral-100 rounded-lg">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {renderSidebarLinks()}

              <div className="pt-4 border-t border-soft-beige/15 space-y-2">
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center space-x-3 px-4 py-2.5 text-xs text-red-650 hover:bg-red-50 rounded-xl transition-colors font-semibold"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Logout Sanctum</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Primary Page viewport section */}
        <main id="main-content" className="flex-1 p-6 md:p-10 md:pl-12 max-w-full overflow-x-hidden min-h-[500px]">
          {renderPageContent()}
        </main>
      </div>

      {/* Premium Toast Stack overlay */}
      <div className="fixed top-6 right-6 z-55 flex flex-col gap-2 max-w-sm pointer-events-none">
        <AnimatePresence>
          {toasts.map((toast) => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: -16, scale: 0.95, filter: 'blur(3px)' }}
              animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
              exit={{ opacity: 0, y: -10, scale: 0.95, filter: 'blur(3px)' }}
              className={`p-4 rounded-2xl shadow-xl flex items-center space-x-3 text-xs font-semibold select-none border backdrop-blur-md pointer-events-auto ${
                toast.type === 'success'
                  ? 'bg-emerald-50/90 text-emerald-800 border-emerald-150'
                  : toast.type === 'info'
                  ? 'bg-lavender/10 text-dusty-lilac border-lavender/30'
                  : toast.type === 'warning'
                  ? 'bg-amber-50/90 text-amber-800 border-amber-100'
                  : 'bg-rose-50/90 text-red-700 border-red-150'
              }`}
            >
              <Sparkles className="w-4.5 h-4.5 text-lavender animate-pulse" />
              <span>{toast.text}</span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Modern Premium Modal Dialogue overlay */}
      <AnimatePresence>
        {modal.isOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop with elegant blur */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setModal((prev) => ({ ...prev, isOpen: false }))}
              className="absolute inset-0 bg-[#3A3640]/40 backdrop-blur-sm"
            />
            
            {/* Modal Dialog container with soft shadows & micro-curves */}
            <motion.div
              initial={{ opacity: 0, scale: 0.93, y: 20, filter: 'blur(3px)' }}
              animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
              exit={{ opacity: 0, scale: 0.93, y: 15, filter: 'blur(3px)' }}
              transition={{ type: 'spring', damping: 24, stiffness: 220 }}
              className="bg-white dark:bg-[#201D24] border border-soft-beige/35 dark:border-white/5 rounded-3xl p-7 shadow-2xl relative w-full max-w-md space-y-5 "
            >
              <div className="space-y-2">
                <h3 className="font-serif text-lg font-bold text-charcoal dark:text-cream">
                  {modal.title}
                </h3>
                <p className="text-xs text-charcoal/75 dark:text-cream/70 leading-relaxed">
                  {modal.message}
                </p>
              </div>

              <div className="flex space-x-3 pt-2">
                <button
                  onClick={() => setModal((prev) => ({ ...prev, isOpen: false }))}
                  className="flex-1 py-3 bg-cream dark:bg-charcoal text-charcoal dark:text-[#E9DCCF] rounded-xl text-xs font-semibold hover:opacity-95 transition-all cursor-pointer"
                >
                  {modal.cancelLabel || 'Cancel'}
                </button>
                <button
                  onClick={modal.onConfirm}
                  className="flex-1 py-3 bg-charcoal dark:bg-lavender text-cream dark:text-white rounded-xl text-xs font-semibold hover:opacity-95 transition-all cursor-pointer"
                >
                  {modal.confirmLabel || 'Confirm'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
