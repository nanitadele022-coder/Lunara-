export type PriorityType = 'low' | 'medium' | 'high';

export interface Task {
  id: string;
  text: string;
  completed: boolean;
  priority: PriorityType;
  timeSlot?: string; // e.g., "09:00 - 10:00" or empty
  note?: string;
  date: string; // YYYY-MM-DD
  category: string; // e.g., "Work", "Creator", "Study", "Personal"
}

export interface Habit {
  id: string;
  name: string;
  category: string;
  streaks: number;
  completedDates: string[]; // YYYY-MM-DD array
  createdAt: string; // YYYY-MM-DD
  frequency: 'daily' | 'weekly';
}

export type MoodType = 'serene' | 'radiant' | 'creative' | 'reflective' | 'weary' | 'restless';

export interface JournalEntry {
  id: string;
  title: string;
  content: string;
  mood: MoodType;
  reflectionPrompt?: string;
  date: string; // YYYY-MM-DD
}

export type BudgetCategory = 'Housing' | 'Food' | 'Transport' | 'Shopping' | 'Entertainment' | 'Subscriptions' | 'Creator Gear' | 'Education' | 'Other';

export interface BudgetItem {
  id: string;
  description: string;
  amount: number;
  type: 'income' | 'expense';
  category: BudgetCategory | 'Salary' | 'Freelance' | 'Allowance' | 'Dividends';
  date: string; // YYYY-MM-DD
}

export interface SavingGoal {
  id: string;
  title: string;
  targetAmount: number;
  currentAmount: number;
  category: string;
}

export interface Milestone {
  id: string;
  text: string;
  completed: boolean;
}

export interface SMARTGoal {
  id: string;
  title: string;
  description: string; // Detail on the SMART framework (Specific, Measurable, Actionable, Relevant, Time-bound)
  category: string; // "Personal", "Financial", "Career", "Wellness", "Creator"
  targetDate: string;
  progress: number; // 0 to 100
  milestones: Milestone[];
  visionBoardImage?: string; // URL/Placeholder or base64
}

export interface UserProfile {
  email: string;
  name: string;
  avatarUrl?: string;
  isLoggedIn: boolean;
  onboarded: boolean;
  syncEnabled: boolean;
  theme: 'soft-light' | 'lavender-mist' | 'minimal-ivory' | 'creamy-luxury' | 'charcoal-night';
}

export interface AppNotification {
  id: string;
  text: string;
  date: string;
  read: boolean;
  category: 'planner' | 'habit' | 'goals' | 'system';
}

// Pre-seeded authentic elegant data for immediate soft luxury visualization
export const INITIAL_TASKS: Task[] = [
  {
    id: 't-1',
    text: 'Refine editorial strategy for YouTube launch',
    completed: true,
    priority: 'high',
    timeSlot: '09:00 - 10:30',
    note: 'Incorporate user feedback on the pilot episode.',
    date: '2026-05-23',
    category: 'Creator',
  },
  {
    id: 't-2',
    text: 'Draft design spec for Lunara dashboard mockup',
    completed: false,
    priority: 'high',
    timeSlot: '11:00 - 12:30',
    note: 'Keep focus on micro-interactions and soft shadows.',
    date: '2026-05-23',
    category: 'Work',
  },
  {
    id: 't-3',
    text: 'Review Advanced React Architectures Chapter 4',
    completed: false,
    priority: 'medium',
    timeSlot: '14:00 - 15:30',
    note: 'Focus on concurrent rendering and custom hooks optimizations.',
    date: '2026-05-23',
    category: 'Study',
  },
  {
    id: 't-4',
    text: 'Weekly organic grocery run',
    completed: true,
    priority: 'low',
    timeSlot: '16:00 - 17:00',
    note: 'Pick up fresh lavender, oat milk, and sourdough.',
    date: '2026-05-23',
    category: 'Personal',
  },
  {
    id: 't-5',
    text: 'Evening yoga & meditation flow',
    completed: false,
    priority: 'medium',
    timeSlot: '18:30 - 19:30',
    note: 'Focus on breathing and gentle alignment.',
    date: '2026-05-23',
    category: 'Personal',
  }
];

export const INITIAL_HABITS: Habit[] = [
  {
    id: 'h-1',
    name: 'Morning Mindfulness (15 mins)',
    category: 'Wellness',
    streaks: 14,
    completedDates: ['2026-05-20', '2026-05-21', '2026-05-22', '2026-05-23'],
    createdAt: '2026-05-01',
    frequency: 'daily',
  },
  {
    id: 'h-2',
    name: 'Skincare Ritual',
    category: 'Self-care',
    streaks: 5,
    completedDates: ['2026-05-19', '2026-05-21', '2026-05-22', '2026-05-23'],
    createdAt: '2026-05-01',
    frequency: 'daily',
  },
  {
    id: 'h-3',
    name: 'Write 500 words of journal / story',
    category: 'Creator',
    streaks: 8,
    completedDates: ['2026-05-20', '2026-05-21', '2026-05-23'],
    createdAt: '2026-05-01',
    frequency: 'daily',
  },
  {
    id: 'h-4',
    name: 'Read 20 pages of a book',
    category: 'Study',
    streaks: 12,
    completedDates: ['2026-05-20', '2026-05-22'],
    createdAt: '2026-05-01',
    frequency: 'daily',
  }
];

export const INITIAL_BUDGET: BudgetItem[] = [
  {
    id: 'b-1',
    description: 'Design consulting retainer',
    amount: 3200,
    type: 'income',
    category: 'Freelance',
    date: '2026-05-10',
  },
  {
    id: 'b-2',
    description: 'Organic Matcha & Sourdough loaf',
    amount: 24.50,
    type: 'expense',
    category: 'Food',
    date: '2026-05-22',
  },
  {
    id: 'b-3',
    description: 'Widen Focal Lens subscription',
    amount: 19.99,
    type: 'expense',
    category: 'Subscriptions',
    date: '2026-05-15',
  },
  {
    id: 'b-4',
    description: 'Ergonomic Desk and Chair',
    amount: 650,
    type: 'expense',
    category: 'Creator Gear',
    date: '2026-05-18',
  },
  {
    id: 'b-5',
    description: 'Tutoring income',
    amount: 450,
    type: 'income',
    category: 'Salary',
    date: '2026-05-20',
  },
  {
    id: 'b-6',
    description: 'Train fare back home',
    amount: 45.00,
    type: 'expense',
    category: 'Transport',
    date: '2026-05-21',
  }
];

export const INITIAL_SAVING_GOALS: SavingGoal[] = [
  {
    id: 'sg-1',
    title: 'Paris Summer Retreat',
    targetAmount: 3500,
    currentAmount: 2400,
    category: 'Travel',
  },
  {
    id: 'sg-2',
    title: 'Premium Mirrorless Camera',
    targetAmount: 2200,
    currentAmount: 1100,
    category: 'Creator',
  },
  {
    id: 'sg-3',
    title: 'Emergency Soft Shield',
    targetAmount: 6000,
    currentAmount: 4500,
    category: 'Savings',
  }
];

export const INITIAL_JOURNAL: JournalEntry[] = [
  {
    id: 'j-1',
    title: 'Clarity in the Quiet Mornings',
    content: 'Woke up at 6:00 AM as the early sun illuminated the lavender vase on my sill. Grounding myself in silence before the notifications start pour-in makes a world of difference. There is profound magic in simply sipping hot tea, watching light dance on soft linen, and setting pure intentions. Today, I build with joy.',
    mood: 'serene',
    reflectionPrompt: 'What simple pleasure brought you peace this morning?',
    date: '2026-05-23',
  },
  {
    id: 'j-2',
    title: 'Creative Sparks and Design Rhythm',
    content: 'Had an intensive brainstorming session for the interface styling of my planner app of choice. I am heavily drawn to a soft, rounded luxury aesthetic with subtle glassmorphism and pale lavender accents. Sometimes, spending an hour finding the exact perfect off-white (#F7F3EE) is completely worth it.',
    mood: 'creative',
    reflectionPrompt: 'Where did you find sudden creative inspiration today?',
    date: '2026-05-21',
  }
];

export const INITIAL_GOALS: SMARTGoal[] = [
  {
    id: 'g-1',
    title: 'Launch "Creative Space" Podcast Series',
    description: 'Launch an elegant 8-episode podcast series interviewing young creative specialists on design ethics and balanced productivity. Specific, measurable, and highly aligned.',
    category: 'Creator',
    targetDate: '2026-09-30',
    progress: 40,
    milestones: [
      { id: 'm-1', text: 'Define 8 episode synopses and target guest list', completed: true },
      { id: 'm-2', text: 'Obtain studio microphone & set up clean workspace acoustics', completed: true },
      { id: 'm-3', text: 'Record pilot episode with Marie on architectural aesthetic', completed: false },
      { id: 'm-4', text: 'Configure branding assets, audio intros, and distribution hosting', completed: false }
    ],
    visionBoardImage: 'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'g-2',
    title: 'Establish Emergency Fund Baseline',
    description: 'Amass $6,000 in dedicated high-yield offline / locked account to cover 4 months of serene peace-of-mind expense baseline.',
    category: 'Financial',
    targetDate: '2026-11-15',
    progress: 75,
    milestones: [
      { id: 'm-5', text: 'Set up automatic $200 weekly sweep trigger', completed: true },
      { id: 'm-6', text: 'Reach $2,000 threshold milestone', completed: true },
      { id: 'm-7', text: 'Reach $4,500 threshold milestone', completed: true },
      { id: 'm-8', text: 'Complete peak baseline index ($6,000)', completed: false }
    ],
    visionBoardImage: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&q=80&w=600'
  }
];

export const REFLECTION_PROMPTS = [
  "What simple pleasure brought you peace today?",
  "Describe a recent design or aesthetic choice that made you feel balanced.",
  "What is one work/study goal you can adjust to cultivate more grace and less stress?",
  "How can you honor your physical need for rest and gentle movement tonight?",
  "Write about a person who deeply grounds and inspires you at this stage of life."
];

export const MOTIVATIONAL_QUOTES = [
  { text: "Simplicity is the ultimate sophistication.", author: "Leonardo da Vinci" },
  { text: "Grace is not just in how we move, but in how we craft our focus.", author: "Unknown" },
  { text: "Have nothing in your houses which you do not know to be useful, or believe to be beautiful.", author: "William Morris" },
  { text: "Your calm mind is the ultimate weapon against your challenges.", author: "Bryant McGill" },
  { text: "Focus is a choice to let go of the secondary.", author: "Aesthetic Mind" }
];
