import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  PenTool,
  Search,
  Book,
  Bookmark,
  Trash2,
  HelpCircle,
} from 'lucide-react';
import { JournalEntry, MoodType, REFLECTION_PROMPTS } from '../types';

interface JournalProps {
  entries: JournalEntry[];
  onAddEntry: (title: string, content: string, mood: MoodType, prompt?: string) => void;
  onDeleteEntry: (id: string) => void;
  selectedDate: string;
  showToast?: (text: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
}

export default function Journal({
  entries,
  onAddEntry,
  onDeleteEntry,
  selectedDate,
  showToast,
}: JournalProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [mood, setMood] = useState<MoodType>('serene');
  const [activePrompt, setActivePrompt] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // Briefly mock layout state for elegant skeletons
  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 350);
    return () => clearTimeout(timer);
  }, []);

  const handleCompose = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) {
      showToast?.('Please write a title and content for your reflections.', 'warning');
      return;
    }

    onAddEntry(title.trim(), content.trim(), mood, activePrompt || undefined);

    // Reset fields
    setTitle('');
    setContent('');
    setActivePrompt('');
    showToast?.('Journal page engraved beautifully.', 'success');
  };

  const getMoodConfig = (m: MoodType) => {
    switch (m) {
      case 'serene':
        return { em: '🧘', label: 'Serene', color: 'bg-emerald-50 text-emerald-700 border-emerald-150' };
      case 'radiant':
        return { em: '☀️', label: 'Radiant', color: 'bg-amber-50 text-amber-700 border-amber-150' };
      case 'creative':
        return { em: '🎨', label: 'Creative', color: 'bg-lavender/10 text-dusty-lilac border-lavender/20' };
      case 'reflective':
        return { em: '🌌', label: 'Reflective', color: 'bg-indigo-50 text-indigo-700 border-indigo-150' };
      case 'weary':
        return { em: '🌧️', label: 'Weary', color: 'bg-slate-100 text-slate-700 border-slate-200' };
      case 'restless':
        return { em: '⚡', label: 'Restless', color: 'bg-red-50 text-red-700 border-red-150' };
    }
  };

  const moodsList: MoodType[] = ['serene', 'radiant', 'creative', 'reflective', 'weary', 'restless'];

  // Filter journals
  const filteredEntries = entries.filter((ent) => {
    const q = searchQuery.toLowerCase();
    return (
      ent.title.toLowerCase().includes(q) ||
      ent.content.toLowerCase().includes(q) ||
      (ent.reflectionPrompt && ent.reflectionPrompt.toLowerCase().includes(q))
    );
  });

  return (
    <div id="journal-page" className="space-y-6">
      {/* Exquisite Journal Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-soft-beige/30 dark:border-white/5 pb-6">
        <div>
          <h2 className="font-serif text-3xl font-medium text-charcoal dark:text-cream flex items-center space-x-2">
            <PenTool className="w-7 h-7 text-lavender" />
            <span>Digital Reflection Sanctuary</span>
          </h2>
          <p className="text-xs text-charcoal/60 dark:text-[#E9DCCF]/65 mt-1">
            Inscribe wandering thoughts, cultivate morning clarity, and harvest silent insights
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Column: Compose Entry Sheet */}
        <div className="bg-white dark:bg-[#201D24] rounded-3xl p-6 border border-soft-beige/35 dark:border-white/5 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-soft-beige/20 dark:border-white/5 pb-4">
            <h3 className="font-serif text-base font-semibold text-charcoal dark:text-cream flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-lavender animate-pulse" />
              <span>Compose Review Sheet</span>
            </h3>
            <span className="text-[10px] text-charcoal/50 dark:text-cream/40 font-bold uppercase tracking-widest">
              {selectedDate}
            </span>
          </div>

          {/* Prompt selection list */}
          <div className="bg-[#F7F3EE]/60 dark:bg-white/5 p-4 rounded-xl border border-soft-beige/25 dark:border-white/5 space-y-2">
            <div className="flex items-center space-x-1.5 text-[10px] uppercase font-semibold text-dusty-lilac dark:text-lavender tracking-widest">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Sensing Prompt Catalyst</span>
            </div>
            <p className="text-xs text-charcoal/70 dark:text-cream/80 leading-relaxed font-serif italic">
              {activePrompt || "Stuck for words? Align your writing with a prompt below:"}
            </p>
            <div className="flex flex-wrap gap-2 pt-2">
              {REFLECTION_PROMPTS.map((prompt, ind) => (
                <button
                  key={ind}
                  type="button"
                  onClick={() => {
                    setActivePrompt(prompt);
                    showToast?.('Reflection prompt aligned.', 'info');
                  }}
                  className={`text-[9px] px-2.5 py-1.5 rounded-lg border font-semibold transition-all text-left max-w-full truncate cursor-pointer ${
                    activePrompt === prompt
                      ? 'bg-lavender text-white border-lavender'
                      : 'bg-white dark:bg-[#201D24] text-charcoal/70 dark:text-cream/70 border-soft-beige/40 dark:border-white/5 hover:border-lavender'
                  }`}
                >
                  {prompt}
                </button>
              ))}
              {activePrompt && (
                <button
                  onClick={() => setActivePrompt('')}
                  className="text-[9px] text-[#9E8AC9] hover:underline font-bold"
                >
                  Clear Prompt
                </button>
              )}
            </div>
          </div>

          <form onSubmit={handleCompose} className="space-y-4">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                Thought Title
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Quietude in the studio workspace"
                className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl px-4 py-3 border border-soft-beige/40 dark:border-white/10 focus:border-lavender focus:outline-hidden font-semibold"
              />
            </div>

            {/* Mood selector grid list */}
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-2">
                Dominant Sentiment / Resonance
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {moodsList.map((m) => {
                  const conf = getMoodConfig(m);
                  return (
                    <button
                      key={m}
                      type="button"
                      onClick={() => {
                        setMood(m);
                        showToast?.(`Tuned resonance to ${conf?.label}.`, 'info');
                      }}
                      className={`py-2 rounded-xl border text-center transition-all cursor-pointer ${
                        mood === m
                          ? `${conf?.color} scale-102 ring-2 ring-lavender/25 font-bold shadow-xs`
                          : 'bg-white dark:bg-white/5 border-soft-beige/30 dark:border-white/5 text-charcoal/50 dark:text-cream/50 hover:border-lavender'
                      }`}
                    >
                      <span className="block text-sm">{conf?.em}</span>
                      <span className="text-[9px] font-semibold block mt-0.5">{conf?.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5 font-bold">
                Reflection Musings
              </label>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Release your stream of consciousness freely..."
                rows={5}
                className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl p-4 border border-soft-beige/40 dark:border-white/10 focus:border-lavender focus:outline-hidden resize-none leading-relaxed font-serif"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-charcoal dark:bg-lavender text-cream dark:text-white text-xs font-semibold hover:opacity-90 transition-all flex items-center justify-center space-x-1.5 shadow-xs cursor-pointer"
            >
              <Book className="w-4 h-4" />
              <span>Engrave Page</span>
            </button>
          </form>
        </div>

        {/* Right Column: Search & Pages Archive list */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-[#201D24] rounded-3xl p-6 border border-soft-beige/35 dark:border-white/5 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-soft-beige/25 dark:border-white/5 pb-3">
              <h3 className="font-serif text-base font-semibold text-charcoal dark:text-cream">Archived Bookshelf</h3>
              <span className="text-[10px] text-charcoal/50 dark:text-cream/40 font-bold uppercase tracking-widest bg-cream dark:bg-neutral-800 px-3 py-1 rounded-full border border-soft-beige/20 dark:border-white/5">
                {filteredEntries.length} items
              </span>
            </div>

            {/* Search filter input */}
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Examine past pages..."
                className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl pl-10 pr-4 py-3 border border-soft-beige/45 dark:border-white/10 focus:border-lavender focus:outline-hidden font-semibold"
              />
              <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-charcoal/30" />
            </div>

            {isLoading ? (
              <div className="space-y-4 py-8">
                {[1, 2].map((ind) => (
                  <div key={ind} className="h-28 w-full bg-cream/15 dark:bg-white/5 animate-pulse rounded-2xl border border-soft-beige/10" />
                ))}
              </div>
            ) : filteredEntries.length === 0 ? (
              <div className="py-20 text-center text-charcoal/40 dark:text-cream/40">
                <Bookmark className="w-10 h-10 mx-auto opacity-35 mb-3" />
                <p className="font-serif italic text-sm text-charcoal/55 dark:text-cream/55">No recorded thoughts match your lens.</p>
              </div>
            ) : (
              <div className="space-y-4 max-h-[550px] overflow-y-auto pr-1">
                <AnimatePresence initial={false}>
                  {filteredEntries.map((ent, ind) => {
                    const mConf = getMoodConfig(ent.mood);
                    return (
                      <motion.div
                        key={ent.id}
                        initial={{ opacity: 0, scale: 0.96, y: 15 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.96 }}
                        transition={{ duration: 0.28, delay: ind * 0.05 }}
                        className="p-5 border border-soft-beige/30 dark:border-white/5 rounded-2xl space-y-3 bg-white dark:bg-[#201D24] shadow-2xs hover:border-lavender/35 group relative mt-1"
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-serif text-[13px] font-bold text-charcoal dark:text-cream leading-snug">
                              {ent.title}
                            </h4>
                            <span className="text-[9px] text-charcoal/40 dark:text-[#E9DCCF]/50 font-bold block uppercase tracking-wider mt-0.5">
                              {ent.date}
                            </span>
                          </div>
                          <div className="flex items-center space-x-2 shrink-0">
                            <span className={`px-2.5 py-1 rounded-md text-[9px] font-bold border ${mConf?.color}`}>
                              {mConf?.em} {mConf?.label}
                            </span>
                            <button
                              onClick={() => {
                                onDeleteEntry(ent.id);
                                showToast?.('Journal page torn gracefully.', 'info');
                              }}
                              className="p-1 hover:bg-neutral-50 dark:hover:bg-[#2F2B35] text-charcoal/20 hover:text-red-650 rounded-lg transition-colors cursor-pointer opacity-0 group-hover:opacity-100"
                              title="Tear page out"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {ent.reflectionPrompt && (
                          <p className="text-[9px] text-[#9E8AC9] bg-lavender/5 dark:bg-white/3 px-2.5 py-1.5 rounded-md border border-lavender/10 font-serif italic">
                            Prompt: {ent.reflectionPrompt}
                          </p>
                        )}

                        <p className="text-xs text-charcoal/70 dark:text-[#E9DCCF]/70 leading-relaxed font-serif whitespace-pre-wrap">
                          {ent.content}
                        </p>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
