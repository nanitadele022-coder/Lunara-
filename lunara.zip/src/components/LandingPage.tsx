import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Calendar,
  CheckCircle2,
  DollarSign,
  PenTool,
  Sparkles,
  Target,
  Star,
  ChevronDown,
  Check,
  ArrowRight,
  Shield,
  Clock,
  Heart,
  Smile,
  Zap,
} from 'lucide-react';

interface LandingPageProps {
  onStartPlanning: () => void;
  onExploreFeatures: () => void;
}

export default function LandingPage({ onStartPlanning, onExploreFeatures }: LandingPageProps) {
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [hoveredBento, setHoveredBento] = useState<number | null>(null);
  const [selectedJournalMood, setSelectedJournalMood] = useState<string>('Serene');

  const toggleFaq = (index: number) => {
    setActiveFaq(activeFaq === index ? null : index);
  };

  const testimonials = [
    {
      name: 'Evelyn Choi',
      role: 'Creative Director',
      quote: 'Lunara replaced my chaotic setup of physical planners, random Notion cards, and notes. The lavender ambient design brings so much deep calm to my focus intervals.',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
      rating: 5,
    },
    {
      name: 'Julian Vance',
      role: 'Design Lead',
      quote: 'As someone who gets overwhelmed by clinical spreadsheets, the visual bento budget and soft spacing are lifesavers. It feels design-first, like an Apple product.',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
      rating: 5,
    },
    {
      name: 'Clara Sterling',
      role: 'Independent Writer',
      quote: 'The journal integration is exquisite. Having daily reflection triggers sitting right next to my active schedule block has truly aligned my mornings.',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
      rating: 5,
    },
  ];

  const faqs = [
    {
      question: 'Is Lunara fully offline-first?',
      answer: 'Yes. Lunara values your ultimate privacy. All data is securely locked to your device using sandboxed localStorage on your client web container. Your inputs are instantly preserved and load in milliseconds without servers monitoring you.',
    },
    {
      question: 'How does syncing work?',
      answer: 'If you opt-in to link your account via Google or Email Authentication, Lunara establishes real-time cloud synchronization allowing your desktop, tablet, and mobile planners to remain harmonized. Your offline data migrates gracefully.',
    },
    {
      question: 'Can I export my planners as PDF?',
      answer: 'Absolutely. We have built an elegant, dedicated print layout system. Utilizing the Export PDF config in your system customization tab creates a beautifully formatted document with zero sidebars.',
    },
    {
      question: 'Is there a dark mode?',
      answer: 'Yes, Lunara incorporates a beautiful dark theme variant called "Charcoal Night" to soothe your vision during twilight writing and planning sessions. It switches with a single click.',
    },
  ];

  return (
    <div id="landing-page" className="min-h-screen bg-[#F7F3EE] text-[#3A3640] selection:bg-lavender/30 relative overflow-x-hidden font-sans">
      
      {/* Dynamic Elegant Floating Gradient Blobs */}
      <div className="absolute top-0 left-0 w-full overflow-hidden pointer-events-none z-0 h-[2200px]">
        {/* Blob 1 */}
        <motion.div
          animate={{
            y: [0, 40, 0],
            x: [0, -20, 0],
            scale: [1, 1.08, 1],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute -top-40 right-10 w-[600px] h-[600px] rounded-full bg-lavender/15 blur-[120px]"
        />
        {/* Blob 2 */}
        <motion.div
          animate={{
            y: [0, -35, 0],
            x: [0, 25, 0],
            scale: [1, 1.15, 1],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-[500px] -left-60 w-[700px] h-[700px] rounded-full bg-soft-beige/40 blur-[130px]"
        />
        {/* Blob 3 */}
        <motion.div
          animate={{
            y: [0, 50, 0],
            x: [0, 30, 0],
            scale: [1, 1.05, 1],
          }}
          transition={{
            duration: 18,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-[1300px] right-20 w-[550px] h-[550px] rounded-full bg-dusty-lilac/10 blur-[140px]"
        />
        {/* Blob 4 */}
        <motion.div
          animate={{
            y: [0, -40, 0],
            x: [0, -30, 0],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-[1800px] left-[15%] w-[450px] h-[450px] rounded-full bg-lavender/8 blur-[110px]"
        />
      </div>

      {/* Luxury Navigation Header */}
      <header className="relative z-20 max-w-7xl mx-auto px-6 py-6 md:py-8 flex items-center justify-between">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="flex items-center space-x-2"
        >
          <div className="w-9 h-9 rounded-full bg-lavender flex items-center justify-center shadow-md shadow-lavender/15 group cursor-pointer transition-transform hover:rotate-6">
            <span className="font-serif text-white font-bold text-sm">L</span>
          </div>
          <span className="font-serif text-2xl tracking-wide font-medium text-charcoal">Lunara</span>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="hidden md:flex items-center space-x-10 text-xs uppercase tracking-widest font-semibold text-charcoal/70"
        >
          <a href="#features" className="hover:text-lavender transition-all duration-300 relative group py-1">
            <span>Features</span>
            <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-lavender transition-all duration-300 group-hover:w-full" />
          </a>
          <a href="#stats" className="hover:text-lavender transition-all duration-300 relative group py-1">
            <span>Impact</span>
            <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-lavender transition-all duration-300 group-hover:w-full" />
          </a>
          <a href="#testimonials" className="hover:text-lavender transition-all duration-300 relative group py-1">
            <span>Testimonials</span>
            <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-lavender transition-all duration-300 group-hover:w-full" />
          </a>
          <a href="#pricing" className="hover:text-lavender transition-all duration-300 relative group py-1">
            <span>Pricing</span>
            <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-lavender transition-all duration-300 group-hover:w-full" />
          </a>
          <a href="#faq" className="hover:text-lavender transition-all duration-300 relative group py-1">
            <span>FAQ</span>
            <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-lavender transition-all duration-300 group-hover:w-full" />
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <button
            onClick={onStartPlanning}
            id="nav-cta-btn"
            className="px-6 py-3 rounded-full text-xs font-bold uppercase tracking-widest bg-charcoal text-cream hover:bg-lavender hover:text-white transition-all duration-300 shadow-md shadow-charcoal/10"
          >
            Start Planning
          </button>
        </motion.div>
      </header>

      {/* Hero Section */}
      <section className="relative z-10 max-w-5xl mx-auto px-6 pt-16 md:pt-32 pb-16 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center space-x-2 px-4 py-2 rounded-full bg-white/40 backdrop-blur-md border border-white/40 shadow-sm mb-10"
        >
          <Sparkles className="w-4 h-4 text-lavender animate-pulse" />
          <span className="text-[10px] font-bold uppercase tracking-wider text-dusty-lilac">Redesigning Private Workspace Productivity</span>
        </motion.div>
        
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="font-serif text-5xl sm:text-6xl md:text-[80px] text-charcoal tracking-tight leading-[1.05] mb-10"
        >
          Cultivate balance <br className="hidden sm:inline" />
          <span className="italic font-serif font-light text-dusty-lilac pointer-events-none">and structure, beautifully.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-base md:text-[19px] text-charcoal/75 max-w-2xl mx-auto leading-relaxed mb-12"
        >
          Lunara is a soft-focus digital sanctum that harmonizes schedule blocking, micro-budgeting, habits, and self-reflection. Designed exquisitely for creators and digital minimalists.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-5 max-w-md mx-auto"
        >
          <button
            onClick={onStartPlanning}
            id="hero-cta-primary"
            className="w-full sm:w-auto px-8 py-4.5 rounded-full bg-charcoal text-cream text-[13px] font-bold uppercase tracking-wider hover:bg-lavender hover:text-white transition-all duration-300 shadow-xl shadow-charcoal/10 flex items-center justify-center space-x-2"
          >
            <span>Begin Your Sanctuary</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={onExploreFeatures}
            id="hero-cta-secondary"
            className="w-full sm:w-auto px-8 py-4.5 rounded-full bg-white/50 backdrop-blur-md text-charcoal text-[13px] font-bold uppercase tracking-wider hover:bg-white hover:shadow-md border border-white/40 transition-all duration-300 flex items-center justify-center"
          >
            Explore Features
          </button>
        </motion.div>
      </section>

      {/* Product Showcase Mockup Section with Glassmorphic Windows */}
      <section className="relative z-10 max-w-6xl mx-auto px-6 pb-32">
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1 }}
          className="relative rounded-3xl bg-white/20 dark:bg-charcoal/10 backdrop-blur-xl p-5 md:p-6 border border-white/50 shadow-[0_32px_64px_-16px_rgba(58,54,64,0.12)]"
        >
          <div className="absolute top-4.5 left-6 flex space-x-2 no-print">
            <div className="w-3 h-3 rounded-full bg-red-400/80 shadow-xs" />
            <div className="w-3 h-3 rounded-full bg-yellow-400/80 shadow-xs" />
            <div className="w-3 h-3 rounded-full bg-green-400/80 shadow-xs" />
          </div>

          <div className="w-full h-8 flex justify-center items-center border-b border-[#3a3640]/5 pb-4 mb-2">
            <span className="text-[10px] uppercase font-mono tracking-widest text-[#3a3640]/45">https://lunara.app/workspace/registry</span>
          </div>
          
          {/* Dashboard Preview */}
          <div className="rounded-2xl bg-gradient-to-tr from-[#FBF9F6] to-white overflow-hidden border border-white/60 p-6 md:p-10">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left Column Entry */}
              <div className="lg:col-span-2 space-y-8">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#3a3640]/5 pb-6 gap-4">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-widest text-dusty-lilac">Interactive Sandbox</span>
                    <h3 className="font-serif text-3xl font-medium text-charcoal mt-1">Hello, Evelyn Choi</h3>
                    <p className="text-xs text-charcoal/60 mt-0.5 mt-1 font-sans">"Quiet minds create powerful routines."</p>
                  </div>
                  <div className="relative group self-start sm:self-center">
                    <div className="absolute -inset-1 rounded-full bg-linear-to-r from-lavender to-dusty-lilac opacity-30 blur-xs" />
                    <div className="relative px-4 py-2 rounded-full bg-white border border-[#E9DCCF] text-[11px] text-[#3A3640] font-mono">
                      2026-05-23 (UTC)
                    </div>
                  </div>
                </div>

                <div className="bg-[#ebdccf]/20 rounded-2xl p-6 border border-[#E9DCCF]/40 shadow-xs">
                  <h4 className="font-serif text-base font-semibold text-charcoal mb-5 flex items-center space-x-2">
                    <Calendar className="w-5 h-5 text-lavender" />
                    <span>Focus Schedule Blocks</span>
                  </h4>
                  <div className="space-y-4">
                    <div className="group flex items-center justify-between p-4 rounded-xl bg-white border border-[#E9DCCF]/40 hover:border-lavender hover:shadow-md transition-all duration-300">
                      <div className="flex items-center space-x-4">
                        <div className="w-3 h-3 rounded-full bg-lavender animate-pulse" />
                        <div>
                          <p className="text-sm font-semibold text-charcoal">Design Spec Polish & Brand Refinement</p>
                          <p className="text-[10px] text-charcoal/50 font-mono">09:00 - 10:30</p>
                        </div>
                      </div>
                      <span className="text-[9px] font-bold px-2.5 py-1 rounded-full bg-amber-100 text-amber-800">HIGH</span>
                    </div>

                    <div className="group flex items-center justify-between p-4 rounded-xl bg-white/60 border border-[#E9DCCF]/20 hover:border-lavender hover:shadow-md transition-all duration-300">
                      <div className="flex items-center space-x-4">
                        <div className="w-3 h-3 rounded-full bg-emerald-400" />
                        <div>
                          <p className="text-sm font-semibold text-charcoal">Serene Walk & Matcha Tea Interval</p>
                          <p className="text-[10px] text-charcoal/50 font-mono">14:00 - 15:00</p>
                        </div>
                      </div>
                      <span className="text-[9px] font-bold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800">DAILY</span>
                    </div>

                    <div className="group flex items-center justify-between p-4 rounded-xl bg-white/40 border border-[#E9DCCF]/10 opacity-60">
                      <div className="flex items-center space-x-4">
                        <div className="w-3 h-3 rounded-full bg-charcoal/40" />
                        <div>
                          <p className="text-sm font-medium text-charcoal/70 line-through">Audit Savings Multiplier</p>
                          <p className="text-[10px] text-charcoal/40 font-mono">16:30 - 17:00</p>
                        </div>
                      </div>
                      <span className="text-[9px] font-bold px-2.5 py-1 rounded-full bg-neutral-100 text-neutral-500">LOW</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column widgets */}
              <div className="space-y-8 lg:border-l lg:border-[#3a3640]/5 lg:pl-8">
                <div className="bg-white rounded-2xl p-6 border border-[#E9DCCF]/40 shadow-xs">
                  <h4 className="font-serif text-base font-semibold text-charcoal mb-4 flex items-center space-x-2">
                    <CheckCircle2 className="w-5 h-5 text-[#9E8AC9]" />
                    <span>Habits Streak Meter</span>
                  </h4>
                  <div className="space-y-5">
                    <div>
                      <div className="flex justify-between text-xs mb-1.5">
                        <span className="text-charcoal/70 font-medium">Morning Meditation Zen</span>
                        <span className="font-bold text-lavender">14 day streak</span>
                      </div>
                      <div className="w-full bg-[#F7F3EE] h-2 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          whileInView={{ width: '85%' }}
                          transition={{ duration: 1, delay: 0.2 }}
                          className="bg-lavender h-full rounded-full" 
                        />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1.5">
                        <span className="text-charcoal/70 font-medium">Creative Journal reflections</span>
                        <span className="font-bold text-[#9E8AC9]">8 day streak</span>
                      </div>
                      <div className="w-full bg-[#F7F3EE] h-2 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          whileInView={{ width: '65%' }}
                          transition={{ duration: 1, delay: 0.3 }}
                          className="bg-[#9E8AC9] h-full rounded-full" 
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-cream to-white p-6 rounded-2xl border border-[#E9DCCF]/50 shadow-xs relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-16 h-16 bg-lavender/5 rounded-full blur-md" />
                  <p className="font-serif italic text-sm text-charcoal leading-relaxed mb-4">
                    "The quiet of your morning choreographs the trajectory of your entire day."
                  </p>
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#9E8AC9]" />
                    <span className="text-[10px] uppercase tracking-widest text-[#3A3640]/50 font-semibold">Morning Devotions</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Animated Statistics Impact Section */}
      <section id="stats" className="relative z-10 max-w-7xl mx-auto px-6 py-24 md:py-32 border-t border-soft-beige/30 bg-[#ebdccf]/10 rounded-[40px] mb-32">
        <div className="text-center max-w-2xl mx-auto mb-16 px-4">
          <span className="text-xs uppercase font-bold tracking-widest text-dusty-lilac">System Performance Metrics</span>
          <h2 className="font-serif text-4xl md:text-5xl text-charcoal mt-2 tracking-tight">
            Loved by minimalists. <span className="italic font-serif font-light text-lavender">Built for speed.</span>
          </h2>
          <p className="text-xs text-charcoal/65 mt-4 leading-relaxed max-w-lg mx-auto">
            Experience absolute client-side velocity. With sandboxed localStorage, your productivity is instantaneous and private.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12 px-4">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center p-6 bg-white/50 backdrop-blur-md rounded-2xl border border-white/60 shadow-xs"
          >
            <div className="w-10 h-10 rounded-full bg-lavender/10 flex items-center justify-center mx-auto mb-4">
              <Clock className="w-5 h-5 text-lavender" />
            </div>
            <p className="text-4xl md:text-5xl font-serif font-semibold text-charcoal">100%</p>
            <p className="text-[11px] uppercase tracking-wider font-bold text-dusty-lilac mt-3">Offline-First Speed</p>
            <p className="text-[11px] text-[#3A3640]/60 mt-1">Zero server wait latency</p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-center p-6 bg-white/50 backdrop-blur-md rounded-2xl border border-white/60 shadow-xs"
          >
            <div className="w-10 h-10 rounded-full bg-lavender/10 flex items-center justify-center mx-auto mb-4">
              <Heart className="w-5 h-5 text-lavender" />
            </div>
            <p className="text-4xl md:text-5xl font-serif font-semibold text-charcoal">99.6%</p>
            <p className="text-[11px] uppercase tracking-wider font-bold text-dusty-lilac mt-3">Serene Score</p>
            <p className="text-[11px] text-[#3A3640]/60 mt-1">Reported stress reduction</p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-center p-6 bg-white/50 backdrop-blur-md rounded-2xl border border-white/60 shadow-xs"
          >
            <div className="w-10 h-10 rounded-full bg-lavender/10 flex items-center justify-center mx-auto mb-4">
              <Shield className="w-5 h-5 text-lavender" />
            </div>
            <p className="text-4xl md:text-5xl font-serif font-semibold text-charcoal">Zero</p>
            <p className="text-[11px] uppercase tracking-wider font-bold text-dusty-lilac mt-3">Third Party Cookies</p>
            <p className="text-[11px] text-[#3A3640]/60 mt-1">Maximum data residency</p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-center p-6 bg-white/50 backdrop-blur-md rounded-2xl border border-white/60 shadow-xs"
          >
            <div className="w-10 h-10 rounded-full bg-lavender/10 flex items-center justify-center mx-auto mb-4">
              <Sparkles className="w-5 h-5 text-lavender" />
            </div>
            <p className="text-4xl md:text-5xl font-serif font-semibold text-charcoal">85k+</p>
            <p className="text-[11px] uppercase tracking-wider font-bold text-dusty-lilac mt-3">Active Rituals</p>
            <p className="text-[11px] text-[#3A3640]/60 mt-1">Created globally in 2026</p>
          </motion.div>
        </div>
      </section>

      {/* Modern Bento-Grid Premium Feature Section */}
      <section id="features" className="relative max-w-7xl mx-auto px-6 py-24 mb-32 z-10">
        <div className="text-center max-w-xl mx-auto mb-20">
          <span className="text-xs uppercase font-bold tracking-widest text-dusty-lilac">The Craftsmanship Pillars</span>
          <h2 className="font-serif text-4xl md:text-5xl text-charcoal tracking-tight mt-2">
            A complete, elegant sanctuary dashboard.
          </h2>
          <div className="w-16 h-0.5 bg-lavender mx-auto mt-6" />
        </div>

        {/* Bento Grid Construction */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 auto-rows-[250px] md:auto-rows-[280px]">
          
          {/* Bento Item 1 - Calendar Planners (Col span 2, row span 1) */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            onMouseEnter={() => setHoveredBento(1)}
            onMouseLeave={() => setHoveredBento(null)}
            className="md:col-span-2 relative overflow-hidden bg-white/70 backdrop-blur-md p-8 rounded-3xl border border-white/60 shadow-md group hover:border-lavender transition-all duration-300 flex flex-col justify-between"
          >
            <div className="absolute top-0 right-0 w-44 h-44 bg-lavender/5 rounded-full blur-2xl group-hover:bg-lavender/10 transition-colors" />
            <div>
              <div className="w-10 h-10 rounded-full bg-lavender/15 flex items-center justify-center mb-6 text-lavender">
                <Calendar className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-charcoal mb-2">Daily Planner Block Scheduler</h3>
              <p className="text-xs text-[#3A3640]/70 max-w-lg leading-relaxed">
                Organize your life in graceful hourly segments. Soft priority badges enable rapid schedule restructuring without friction, ensuring time is distributed beautifully.
              </p>
            </div>
            
            <span className="text-[10px] uppercase font-bold tracking-widest text-[#B79CED] flex items-center gap-1">
              <span>Explore Blocks View</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-1.5 transition-transform" />
            </span>
          </motion.div>

          {/* Bento Item 2 - Habit Ritual Stream (Col span 1, row span 1) */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="relative overflow-hidden bg-white/70 backdrop-blur-md p-8 rounded-3xl border border-white/60 shadow-md group hover:border-lavender transition-all duration-300 flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-full bg-lavender/15 flex items-center justify-center mb-6 text-lavender">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-charcoal mb-2 font-serif">Ritual Continuity</h3>
              <p className="text-xs text-[#3A3640]/70 leading-relaxed">
                Log recurring habits simply. Leverage streak metrics and custom weekly calendars to remain consistently balanced.
              </p>
            </div>

            <div className="flex gap-1.5 pt-2">
              {['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'].map((day, dIdx) => (
                <div key={day} className="flex-1 text-center py-1 bg-lavender/[0.08] group-hover:bg-lavender/[0.15] transition-colors rounded-md text-[9px] font-bold text-dusty-lilac">
                  {day}
                  <div className={`w-1.5 h-1.5 mx-auto rounded-full mt-1 ${dIdx < 5 ? 'bg-lavender' : 'bg-[#E9DCCF]'}`} />
                </div>
              ))}
            </div>
          </motion.div>

          {/* Bento Item 3 - Budget Planner (Col span 1, row span 1) */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative overflow-hidden bg-white/70 backdrop-blur-md p-8 rounded-3xl border border-white/60 shadow-md group hover:border-lavender transition-all duration-300 flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-full bg-lavender/15 flex items-center justify-center mb-6 text-lavender">
                <DollarSign className="w-4 h-4" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-charcoal mb-2 font-serif">Bento Expense Tracker</h3>
              <p className="text-xs text-[#3A3640]/70 leading-relaxed">
                Map assets, trace daily outflows, and monitor saving checkpoints in a beautiful visual bento framework.
              </p>
            </div>
            
            <div className="w-full bg-[#ebdccf]/20 h-6.5 rounded-full p-1 border border-[#E9DCCF]/40 flex items-center justify-between">
              <span className="text-[9px] font-bold text-charcoal/60 px-2 uppercase tracking-wider">Matures</span>
              <div className="bg-lavender text-white font-mono text-[9px] font-bold px-3 py-10 flex items-center justify-center rounded-full h-full">85% Save</div>
            </div>
          </motion.div>

          {/* Bento Item 4 - Reflection Musings (Col span 2, row span 1) */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="md:col-span-2 relative overflow-hidden bg-white/70 backdrop-blur-md p-8 rounded-3xl border border-white/60 shadow-md group hover:border-lavender transition-all duration-300 flex flex-col justify-between"
          >
            <div className="absolute top-0 right-0 w-64 h-full bg-linear-to-l from-lavender/[0.04] to-transparent pointer-events-none" />
            
            <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
              <div className="max-w-md">
                <div className="w-10 h-10 rounded-full bg-lavender/15 flex items-center justify-center mb-6 text-lavender animate-pulse">
                  <PenTool className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-xl font-semibold text-charcoal mb-2">Serene Reflection Journal</h3>
                <p className="text-xs text-[#3A3640]/70 leading-relaxed">
                  Quiet your mind with elegant journaling tools. Reflective morning prompts align your spirit. Feel supported with customized tags indicating how you felt over each step.
                </p>
              </div>

              {/* Mini Inner interactive widget mock */}
              <div className="bg-white/80 border border-[#E9DCCF]/40 p-3.5 rounded-2xl w-full sm:w-44 text-center shadow-xs self-center">
                <p className="text-[10px] uppercase font-bold tracking-widest text-[#B79CED] mb-2 scale-90">Mood alignment</p>
                <div className="flex justify-center gap-1">
                  {['Peaceful', 'Inspired', 'Serene', 'Tired'].map((mood) => (
                    <button
                      key={mood}
                      onClick={() => setSelectedJournalMood(mood)}
                      className={`text-[9.5px] font-bold px-2 py-1 rounded-lg border transition-all ${
                        selectedJournalMood === mood 
                          ? 'bg-lavender text-white border-lavender scale-105' 
                          : 'bg-transparent text-charcoal border-[#E9DCCF] hover:bg-neutral-50'
                      }`}
                    >
                      {mood.slice(0,3)}
                    </button>
                  ))}
                </div>
                <p className="text-[9px] text-[#3A3640]/40 mt-2 italic font-serif">Current Selection: {selectedJournalMood}</p>
              </div>
            </div>

            <span className="text-[10px] uppercase font-bold tracking-widest text-[#B79CED] mt-4 flex items-center gap-1 cursor-pointer">
              <span>Open Reflection Tab</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-1.5 transition-transform" />
            </span>
          </motion.div>

          {/* Bento Item 5 - SMART Goals (Col span 1, row span 1) */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="relative overflow-hidden bg-white/70 backdrop-blur-md p-8 rounded-3xl border border-white/60 shadow-md group hover:border-lavender transition-all duration-300 flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-full bg-lavender/15 flex items-center justify-center mb-6 text-lavender">
                <Target className="w-4 h-4" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-charcoal mb-2 font-serif">SMART Goals Board</h3>
              <p className="text-xs text-[#3A3640]/70 leading-relaxed">
                Formulate strict targets. Break aspirations down to interactive milestones and track real visual achievement meters.
              </p>
            </div>
            
            <div className="w-full bg-[#ebdccf]/10 h-1.5 rounded-full overflow-hidden mt-2">
              <div className="bg-lavender h-full rounded-full w-[70%] group-hover:w-[90%] transition-all duration-1000" />
            </div>
          </motion.div>

          {/* Bento Item 6 - Absolute Security (Col span 2, row span 1) */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="md:col-span-2 relative overflow-hidden bg-[#3A3640] text-[#F7F3EE] p-8 rounded-3xl border border-white/10 shadow-md group transition-all duration-300 flex flex-col justify-between"
          >
            <div className="absolute inset-0 bg-radial-to-tr from-lavender/5 via-transparent to-transparent opacity-60 pointer-events-none" />
            <div>
              <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center mb-6 text-[#ebdccf] animate-pulse">
                <Shield className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-white mb-2 font-serif">Zero Knowledge Data Isolation</h3>
              <p className="text-xs text-[#E9DCCF]/85 max-w-lg leading-relaxed">
                No third-party cookies. No cloud profiling algorithms tracking your habits. Lunara values complete mental sanctity—keeping database structures fully sandboxed securely on your device.
              </p>
            </div>

            <span className="text-[10px] uppercase font-bold tracking-widest text-[#B79CED] mt-4 flex items-center gap-1 select-none">
              <span>Read Sandbox Privacy Promise</span>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
            </span>
          </motion.div>

        </div>
      </section>

      {/* Aesthetic Testimonials Section */}
      <section id="testimonials" className="bg-[#ebdccf]/20 backdrop-blur-md py-28 md:py-36 border-t border-b border-soft-beige/30 relative overflow-hidden">
        {/* Decorative background circle */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-lavender/5 rounded-full blur-[80px]" />
        
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="text-center max-w-xl mx-auto mb-20">
            <span className="text-xs uppercase font-bold tracking-widest text-dusty-lilac">User Echoes</span>
            <h2 className="font-serif text-4xl md:text-5xl text-charcoal tracking-tight mt-2">
              Reflections from our quiet community
            </h2>
            <div className="flex items-center justify-center space-x-1 mt-4 text-amber-500">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4.5 h-4.5 fill-amber-500 text-amber-500" />
              ))}
            </div>
            <p className="text-xs text-charcoal/50 mt-1.5">Consistently rated 4.9/5 stars for clarity and visual appeal.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((test, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ y: -6, scale: 1.01 }}
                className="bg-white rounded-3xl p-8 border border-[#E9DCCF]/50 shadow-sm flex flex-col justify-between hover:shadow-xl hover:border-lavender/30 transition-all duration-300"
              >
                <div>
                  <div className="flex space-x-0.5 text-amber-400 mb-6">
                    {[...Array(test.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                    ))}
                  </div>
                  <p className="text-xs md:text-[13px] text-charcoal/80 italic leading-relaxed mb-8">
                    "{test.quote}"
                  </p>
                </div>
                
                <div className="flex items-center space-x-4 pt-4 border-t border-neutral-50">
                  <img
                    src={test.avatar}
                    alt={test.name}
                    className="w-11 h-11 rounded-full object-cover border-2 border-lavender/10"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h4 className="text-xs font-bold text-charcoal uppercase tracking-wider">{test.name}</h4>
                    <p className="text-[10px] text-charcoal/50 font-mono">{test.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="max-w-5xl mx-auto px-6 py-28 md:py-36 relative z-10">
        <div className="text-center max-w-xl mx-auto mb-20">
          <span className="text-xs uppercase font-bold tracking-widest text-dusty-lilac">Fair Pricing Principles</span>
          <h2 className="font-serif text-4xl md:text-5xl text-charcoal tracking-tight mt-2">
            Nurture your daily planning flow
          </h2>
          <p className="text-xs text-charcoal/50 mt-3 leading-relaxed">
            Honest models. Complete client execution operates forever free. Connect celestial syncing only if your workflow demands it.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto px-4">
          
          {/* Free Tier */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="bg-white/80 rounded-3xl p-8 border border-soft-beige/50 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
          >
            <div>
              <div className="flex justify-between items-center mb-6">
                <span className="text-[10px] font-bold uppercase tracking-widest text-charcoal/50">Serene Companion</span>
                <span className="px-3 py-1 rounded-full bg-cream text-[9px] font-bold text-charcoal/60">FREE FOREVER</span>
              </div>
              
              <p className="font-serif text-4xl font-semibold tracking-tight text-charcoal mb-4">
                $0 <span className="text-xs text-dusty-lilac font-sans font-medium uppercase tracking-wider ml-1">No expiry</span>
              </p>
              
              <p className="text-xs text-charcoal/70 mb-8 leading-relaxed">
                Securely structured around client sandboxing. Enjoy offline habits trackers, daily time blocks, goals, and reflections.
              </p>
              
              <div className="border-t border-[#E9DCCF]/40 pt-6 space-y-4">
                <div className="flex items-start space-x-3 text-xs text-charcoal/80">
                  <Check className="w-4 h-4 text-emerald-600 mt-0.5" />
                  <span>Interactive Daily Schedule Blocks</span>
                </div>
                <div className="flex items-start space-x-3 text-xs text-charcoal/80">
                  <Check className="w-4 h-4 text-emerald-600 mt-0.5" />
                  <span>Unlimited Habit Streaks & Metrins</span>
                </div>
                <div className="flex items-start space-x-3 text-xs text-charcoal/80">
                  <Check className="w-4 h-4 text-emerald-600 mt-0.5" />
                  <span>Serene Reflections & Daily Prompts</span>
                </div>
                <div className="flex items-start space-x-3 text-xs text-charcoal/80">
                  <Check className="w-4 h-4 text-emerald-600 mt-0.5" />
                  <span>Autosave Local State Storage</span>
                </div>
              </div>
            </div>

            <button
              onClick={onStartPlanning}
              className="mt-10 w-full py-4 rounded-xl bg-charcoal/5 hover:bg-charcoal/10 text-charcoal text-xs font-bold uppercase tracking-wider transition-all"
            >
              Get Started Free
            </button>
          </motion.div>

          {/* Premium Tier */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="bg-white rounded-3xl p-8 border-2 border-lavender shadow-md hover:shadow-xl relative flex flex-col justify-between"
          >
            <div className="absolute top-0 right-10 -translate-y-[50%] bg-lavender text-white px-4 py-1.5 rounded-full text-[9px] font-bold tracking-widest uppercase">
              POPULAR CHOICES
            </div>
            
            <div>
              <div className="flex justify-between items-center mb-6">
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#9E8AC9]">Celestial Sync</span>
                <span className="px-3 py-1 rounded-full bg-lavender/15 text-[9px] font-bold text-lavender">PRO PORTAL</span>
              </div>
              
              <p className="font-serif text-4xl font-semibold tracking-tight text-charcoal mb-4">
                $4.99 <span className="text-xs text-dusty-lilac font-sans font-medium uppercase tracking-wider ml-1">/ month</span>
              </p>
              
              <p className="text-xs text-charcoal/70 mb-8 leading-relaxed">
                Connect your workspace account to link schedules, journals, and goals across multiple secure tablet, notebook, and mobile browser containers.
              </p>
              
              <div className="border-t border-[#E9DCCF]/40 pt-6 space-y-4">
                <div className="flex items-start space-x-3 text-xs text-charcoal/80">
                  <Check className="w-4 h-4 text-lavender mt-0.5" />
                  <span className="font-bold">Real-time Multi-device Syncing</span>
                </div>
                <div className="flex items-start space-x-3 text-xs text-charcoal/80">
                  <Check className="w-4 h-4 text-lavender mt-0.5" />
                  <span>Elegant Atmosphere Themes Pack</span>
                </div>
                <div className="flex items-start space-x-3 text-xs text-charcoal/80">
                  <Check className="w-4 h-4 text-lavender mt-0.5" />
                  <span>SMART Target Visualizer expansion</span>
                </div>
                <div className="flex items-start space-x-3 text-xs text-charcoal/80">
                  <Check className="w-4 h-4 text-lavender mt-0.5" />
                  <span>Priority Celestial Sync Care support</span>
                </div>
              </div>
            </div>

            <button
              onClick={onStartPlanning}
              className="mt-10 w-full py-4 rounded-xl bg-lavender hover:bg-lavender/90 text-white text-xs font-bold uppercase tracking-wider transition-all shadow-md shadow-lavender/20"
            >
              Unlock Celestial Sync
            </button>
          </motion.div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="bg-[#ebdccf]/10 backdrop-blur-md py-28 md:py-36 border-t border-soft-beige/30 relative z-10">
        <div className="max-w-3xl mx-auto px-6">
          <div className="text-center mb-16">
            <span className="text-xs uppercase font-bold tracking-widest text-dusty-lilac">Frequently Asked Questions</span>
            <h2 className="font-serif text-4xl text-charcoal tracking-tight font-medium mt-2">Curated Questions</h2>
            <p className="text-xs text-charcoal/50 mt-2">Everything you need to know about starting your Lunara journey.</p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl border border-[#E9DCCF]/40 transition-all overflow-hidden shadow-xs"
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full text-left px-6 py-5 flex items-center justify-between font-serif text-sm font-semibold text-charcoal hover:bg-neutral-50/50 transition-colors"
                >
                  <span>{faq.question}</span>
                  <motion.div
                    animate={{ rotate: activeFaq === index ? 180 : 0 }}
                    transition={{ type: 'spring', stiffness: 200, damping: 20 }}
                  >
                    <ChevronDown className="w-4.5 h-4.5 text-charcoal/40" />
                  </motion.div>
                </button>
                
                <AnimatePresence initial={false}>
                  {activeFaq === index && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: 'easeInOut' }}
                      className="overflow-hidden"
                    >
                      <div className="px-6 pb-6 pt-1 text-xs md:text-sm text-charcoal/65 leading-relaxed border-t border-[#E9DCCF]/15">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Luxurious Final CTA Gallery Section */}
      <section className="relative z-10 max-w-7xl mx-auto px-6 pb-20 no-print">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative bg-charcoal text-cream rounded-[40px] p-8 md:p-20 text-center overflow-hidden border border-white/10 shadow-2xl"
        >
          {/* Subtle radiating grid effect */}
          <div className="absolute inset-0 bg-radial-to-c from-lavender/10 via-[#1C191D]/5 to-[#1C191D] opacity-90" />
          
          <div className="absolute -top-40 -left-40 w-80 h-80 bg-lavender/10 rounded-full blur-[80px]" />
          <div className="absolute -bottom-40 -right-40 w-80 h-80 bg-dusty-lilac/10 rounded-full blur-[80px]" />

          <div className="relative z-10 max-w-2xl mx-auto space-y-8">
            <span className="text-xs uppercase font-mono tracking-[0.25em] text-[#B79CED] font-bold">The Final Assembly</span>
            
            <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-white tracking-tight leading-[1.1]">
              Organize your days with <br />
              <span className="italic font-serif font-light text-[#E9DCCF]">exquisite peace.</span>
            </h2>

            <p className="text-xs sm:text-sm md:text-base text-[#E9DCCF]/80 leading-relaxed max-w-lg mx-auto">
              Join thousands of digital professionals, writers, and artists who structure their days cleanly inside the quiet Lunara sandbox. No algorithms, no interruptions.
            </p>

            <div className="pt-4">
              <button
                onClick={onStartPlanning}
                className="inline-flex items-center space-x-3 px-10 py-5 bg-cream text-charcoal hover:bg-lavender hover:text-white rounded-full font-bold text-xs sm:text-sm uppercase tracking-wider transition-all duration-300 shadow-2xl hover:shadow-[#B79CED]/30 cursor-pointer"
              >
                <span>Enter Your Planners Portal</span>
                <Zap className="w-4 h-4" />
              </button>
              <p className="text-[10px] text-[#E9DCCF]/50 mt-4">Free companion forever • Sandboxed environment • Deploy instantly</p>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Luxury Footer */}
      <footer className="bg-[#1C191D] text-cream/80 py-16 md:py-20 border-t border-charcoal relative z-10">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12 md:gap-8">
          
          <div className="md:col-span-2 space-y-6">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-full bg-lavender flex items-center justify-center">
                <span className="font-serif text-white font-bold text-xs">L</span>
              </div>
              <span className="font-serif text-2xl tracking-wide font-medium text-white">Lunara</span>
            </div>
            
            <p className="text-[12px] text-cream/60 max-w-sm leading-relaxed">
              Cultivate a balanced lifestyle with beautiful structures. A responsive offline-focused soft luxury digital workspace for creators, designers, and quiet achievers.
            </p>
            <p className="text-[11px] text-cream/40">Inspired by natural serenity and high-fidelity Swiss modernism.</p>
          </div>

          <div>
            <h5 className="text-[10px] uppercase tracking-widest text-[#B79CED] font-bold mb-5 font-mono">Index Directories</h5>
            <ul className="space-y-3.5 text-xs text-cream/70">
              <li><a href="#features" className="hover:text-[#B79CED] transition-colors">Workspace Features</a></li>
              <li><a href="#stats" className="hover:text-[#B79CED] transition-colors">Privacy Performance Metrics</a></li>
              <li><a href="#testimonials" className="hover:text-[#B79CED] transition-colors">User Expressions</a></li>
              <li><a href="#pricing" className="hover:text-[#B79CED] transition-colors">Sovereign Plans</a></li>
            </ul>
          </div>

          <div>
            <h5 className="text-[10px] uppercase tracking-widest text-[#B79CED] font-bold mb-5 font-mono">Visual Standards</h5>
            <p className="text-xs text-cream/60 leading-relaxed">
              Designed around elegant Playfair Display serif elements, fluid Plus Jakarta Sans text, responsive glassmorphism frames, pale lavender #B79CED highlight accents, and beautiful negative spacing.
            </p>
          </div>

        </div>

        <div className="max-w-7xl mx-auto px-6 mt-16 pt-8 border-t border-white/[0.04] text-center flex flex-col sm:flex-row items-center justify-between text-[11px] text-cream/40">
          <p>© 2026 Lunara Private Digital Planners. Developed around real-time sandboxed localStorage.</p>
          <div className="flex space-x-6 mt-4 sm:mt-0">
            <span className="hover:text-[#B79CED] transition-colors cursor-pointer">Privacy Charter</span>
            <span className="hover:text-[#B79CED] transition-colors cursor-pointer">Sanctuary Ethics</span>
            <span className="hover:text-[#B79CED] transition-colors cursor-pointer">Customer Care</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
