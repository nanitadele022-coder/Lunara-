import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  Calendar,
  CheckSquare,
  Trophy,
  DollarSign,
  PenTool,
  Target,
  Plus,
  Star,
  Activity,
  Play,
  Pause,
  RotateCcw,
  Clock,
  Heart,
  TrendingUp,
  Award
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Task, Habit, BudgetItem, SMARTGoal, MOTIVATIONAL_QUOTES } from '../types';

interface DashboardProps {
  tasks: Task[];
  habits: Habit[];
  budgetItems: BudgetItem[];
  goals: SMARTGoal[];
  onQuickNavigate: (page: string) => void;
  selectedDate: string;
  onChangeDate: (date: string) => void;
  userName: string;
  onQuickAddTask: (text: string, priority: 'low' | 'medium' | 'high') => void;
  showToast?: (text: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
}

export default function Dashboard({
  tasks,
  habits,
  budgetItems,
  goals,
  onQuickNavigate,
  selectedDate,
  onChangeDate,
  userName,
  onQuickAddTask,
  showToast,
}: DashboardProps) {
  const [quickTaskText, setQuickTaskText] = useState('');
  const [quickPriority, setQuickPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [showQuickAddFloating, setShowQuickAddFloating] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Focus Timer States (custom interactive widget)
  const [timerDuration, setTimerDuration] = useState(25 * 60); // 25 Minutes standard Pomodoro
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [timerActive, setTimerActive] = useState(false);

  // Trigger brief luxurious loading skeleton loop for premium feeling
  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 600);
    return () => clearTimeout(timer);
  }, []);

  // Zen timer count down action
  useEffect(() => {
    let intervalId: any = null;
    if (timerActive && timeLeft > 0) {
      intervalId = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && timerActive) {
      setTimerActive(false);
      showToast?.('Mindfulness interval realized. Return to serene presence.', 'success');
      setTimeLeft(25 * 60);
    }
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [timerActive, timeLeft]);

  // Filter tasks for today
  const todaysTasks = tasks.filter((t) => t.date === selectedDate);
  const pendingHighPriority = todaysTasks.filter((t) => !t.completed && t.priority === 'high');

  // Budget calculations
  const monthlyExpenses = budgetItems
    .filter((item) => item.type === 'expense')
    .reduce((sum, item) => sum + item.amount, 0);

  // Motivational quote loop rotation based on calendar date
  const quoteIndex = new Date(selectedDate).getDate() % MOTIVATIONAL_QUOTES.length;
  const activeQuote = MOTIVATIONAL_QUOTES[quoteIndex];

  // Calendar dates drawer for 7 days centering selected date
  const getWeekDates = () => {
    const dates = [];
    const center = new Date(selectedDate);
    for (let i = -3; i <= 3; i++) {
      const d = new Date(center);
      d.setDate(center.getDate() + i);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      dates.push({
        dateStr: `${yyyy}-${mm}-${dd}`,
        dayName: d.toLocaleDateString('en-US', { weekday: 'narrow' }),
        dayNum: d.getDate(),
        isToday: d.toDateString() === new Date().toDateString(),
      });
    }
    return dates;
  };

  const weekDates = getWeekDates();

  const handleQuickAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickTaskText.trim()) return;
    onQuickAddTask(quickTaskText.trim(), quickPriority);
    setQuickTaskText('');
    setShowQuickAddFloating(false);
  };

  const startTimer = (mins: number) => {
    setTimerDuration(mins * 60);
    setTimeLeft(mins * 60);
    setTimerActive(true);
    showToast?.(`Zen timer started for ${mins} minutes. Focus on drawing.`, 'info');
  };

  // Prepping luxury trend data for Recharts area visual (cumulative cashflow logs)
  const chartData = [5, 4, 3, 2, 1, 0].map((daysAgo) => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() - daysAgo);
    const dateStr = d.toISOString().split('T')[0];
    const dayLabel = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

    const dayItems = budgetItems.filter((b) => b.date === dateStr);
    const income = dayItems.filter((b) => b.type === 'income').reduce((sum, b) => sum + b.amount, 0);
    const expense = dayItems.filter((b) => b.type === 'expense').reduce((sum, b) => sum + b.amount, 0);

    return {
      name: dayLabel,
      Inflow: income,
      Outflow: expense,
    };
  });

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Premium loading skeletons
  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-16 w-full bg-cream/15 dark:bg-[#201D24] animate-pulse rounded-2xl border border-soft-beige/10 py-6 px-4" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <div className="h-64 bg-cream/15 dark:bg-[#201D24] animate-pulse rounded-2xl border border-soft-beige/10" />
            <div className="grid grid-cols-2 gap-4">
              <div className="h-28 bg-cream/15 dark:bg-[#201D24] animate-pulse rounded-2xl border border-soft-beige/10" />
              <div className="h-28 bg-cream/15 dark:bg-[#201D24] animate-pulse rounded-2xl border border-[#9E8AC9]/10" />
            </div>
          </div>
          <div className="space-y-6 col-span-1">
            <div className="h-32 bg-cream/15 dark:bg-[#201D24] animate-pulse rounded-2xl border border-soft-beige/10" />
            <div className="h-48 bg-cream/15 dark:bg-[#201D24] animate-pulse rounded-2xl border border-soft-beige/10" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div id="dashboard-view" className="space-y-6">
      {/* Exquisite Top Greeting */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-soft-beige/35 dark:border-white/5 pb-6">
        <div>
          <h1 className="font-serif text-3xl md:text-4xl text-charcoal dark:text-cream tracking-tight font-medium">
            Morning, <span className="italic text-dusty-lilac">{userName}</span>
          </h1>
          <p className="text-xs text-charcoal/65 dark:text-[#E9DCCF]/60 mt-1">
            "May your tea be hot, your screen be soft, and your targets be clear."
          </p>
        </div>

        {/* Date Selector Indicator with soft shadows */}
        <div className="flex bg-white dark:bg-[#2B2730] rounded-full p-1 border border-soft-beige/35 dark:border-white/5 shadow-2xs overflow-hidden no-print">
          {weekDates.map((w) => {
            const isSelected = w.dateStr === selectedDate;
            return (
              <button
                key={w.dateStr}
                onClick={() => {
                  onChangeDate(w.dateStr);
                  showToast?.(`Aligned workspace with ${new Date(w.dateStr).toLocaleDateString()}`, 'info');
                }}
                className={`w-9 h-9 rounded-full flex flex-col items-center justify-center text-center transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-lavender text-white shadow-md shadow-lavender/10 scale-102 font-semibold'
                    : 'text-charcoal/60 dark:text-[#E9DCCF]/65 hover:text-charcoal hover:bg-neutral-50 dark:hover:bg-neutral-900'
                }`}
              >
                <span className="text-[8px] font-bold uppercase block">{w.dayName}</span>
                <span className="text-[10px] tracking-tighter block mt-0.5 font-bold">{w.dayNum}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Bento Grid Widgets Dashboard Layout */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Columns Container */}
        <div className="md:col-span-2 space-y-6">
          {/* Today's High priority checklist */}
          <div className="bg-white dark:bg-[#201D24] rounded-3xl p-6 border border-soft-beige/35 dark:border-white/5 shadow-xs">
            <div className="flex items-center justify-between border-b border-soft-beige/25 dark:border-white/5 pb-3 mb-4">
              <h3 className="font-serif text-sm font-semibold text-charcoal dark:text-cream flex items-center space-x-2">
                <CheckSquare className="w-4.5 h-4.5 text-lavender animate-pulse" />
                <span>Focus Node Checkpoints</span>
              </h3>
              <button
                onClick={() => onQuickNavigate('planner')}
                className="text-[10px] text-dusty-lilac dark:text-lavender hover:underline font-bold tracking-widest uppercase transition-colors"
              >
                Open Planner →
              </button>
            </div>

            {todaysTasks.length === 0 ? (
              <div className="py-10 text-center text-charcoal/40 dark:text-[#E9DCCF]/40">
                <p className="font-serif italic text-xs">No active nodes scheduled for this date.</p>
                <button
                  onClick={() => setShowQuickAddFloating(true)}
                  className="mt-3 text-[10px] bg-lavender/10 text-dusty-lilac px-3 py-1.5 rounded-full font-bold hover:bg-lavender/20 transition-all cursor-pointer"
                >
                  Lay Quick Node +
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {todaysTasks.slice(0, 3).map((task) => (
                  <div
                    key={task.id}
                    className="p-3.5 bg-cream/25 dark:bg-white/5 border border-soft-beige/25 dark:border-white/5 rounded-2xl flex items-center justify-between text-xs transition-all hover:bg-lavender/5"
                  >
                    <span className={`font-semibold text-[11px] ${task.completed ? 'line-through text-charcoal/40 dark:text-cream/30' : 'text-charcoal dark:text-cream'}`}>
                      {task.text}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-[8px] font-bold ${task.priority === 'high' ? 'bg-red-500/10 text-red-500' : 'bg-neutral-100 dark:bg-neutral-800 text-charcoal/60 dark:text-cream/50'}`}>
                      {task.priority.toUpperCase()}
                    </span>
                  </div>
                ))}
                {todaysTasks.length > 3 && (
                  <p className="text-[10px] text-charcoal/40 dark:text-[#E9DCCF]/40 text-center italic mt-2">
                    + {todaysTasks.length - 3} further nodes stacked inside planner views.
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Premium Financial Cashflow area Chart widget using Recharts */}
          <div className="bg-white dark:bg-[#201D24] rounded-3xl p-6 border border-soft-beige/35 dark:border-white/5 shadow-xs">
            <div className="flex items-center justify-between pb-4 border-b border-soft-beige/25 dark:border-white/5 mb-4">
              <div>
                <h3 className="font-serif text-sm font-semibold text-charcoal dark:text-cream flex items-center space-x-1.5">
                  <TrendingUp className="w-4 h-4 text-lavender" />
                  <span>Cashflow Harmony Analytics</span>
                </h3>
                <p className="text-[9px] text-charcoal/40 dark:text-[#E9DCCF]/40 leading-none mt-1">Rolling comparative inflow and outflow log structures</p>
              </div>
              <button
                onClick={() => onQuickNavigate('budget')}
                className="text-[10px] text-[#9E8AC9] hover:underline font-bold"
              >
                Full Ledger →
              </button>
            </div>

            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorInflow" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10B981" stopOpacity={0.15}/>
                      <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorOutflow" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#B79CED" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#B79CED" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" tick={{ fontSize: 9, fill: '#7D756C' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 9, fill: '#7D756C' }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.9)',
                      border: '1px solid #E9DCCF',
                      borderRadius: '16px',
                      fontSize: '11px',
                      color: '#3A3640'
                    }}
                  />
                  <Area type="monotone" dataKey="Inflow" stroke="#10B981" strokeWidth={2.5} fillOpacity={1} fill="url(#colorInflow)" />
                  <Area type="monotone" dataKey="Outflow" stroke="#B79CED" strokeWidth={2.5} fillOpacity={1} fill="url(#colorOutflow)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Goals Vision & Cashflow Bento cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-white dark:bg-[#201D24] rounded-3xl p-5 border border-soft-beige/35 dark:border-white/5 shadow-xs flex flex-col justify-between hover:border-lavender/30 transition-all group">
              <div>
                <span className="text-[10px] font-extrabold text-charcoal/40 dark:text-[#E9DCCF]/50 uppercase tracking-widest block mb-1">Target Objectives</span>
                <span className="font-serif text-2xl font-bold text-[#9E8AC9] group-hover:text-lavender transition-colors">{goals.length} active</span>
              </div>
              <button
                onClick={() => onQuickNavigate('goals')}
                className="text-[10px] font-bold text-charcoal/60 dark:text-[#E9DCCF]/70 hover:text-lavender transition-colors mt-4 text-left"
              >
                Manage Vision Board →
              </button>
            </div>

            <div className="bg-white dark:bg-[#201D24] rounded-3xl p-5 border border-soft-beige/35 dark:border-white/5 shadow-xs flex flex-col justify-between hover:border-lavender/30 transition-all group">
              <div>
                <span className="text-[10px] font-extrabold text-charcoal/40 dark:text-[#E9DCCF]/50 uppercase tracking-widest block mb-1">Outflow volume checks</span>
                <span className="font-serif text-2xl font-bold text-[#9E8AC9] group-hover:text-lavender transition-colors">${monthlyExpenses.toFixed(2)}</span>
              </div>
              <button
                onClick={() => onQuickNavigate('budget')}
                className="text-[10px] font-bold text-charcoal/60 dark:text-[#E9DCCF]/70 hover:text-lavender transition-colors mt-4 text-left"
              >
                Examine Cashflow →
              </button>
            </div>
          </div>
        </div>

        {/* Right Column Container */}
        <div className="space-y-6">
          {/* Rotating motivation quotes card with luxurious style */}
          <div className="bg-linear-to-br from-[#9E8AC9]/15 to-transparent rounded-3xl p-6 border border-[#9E8AC9]/20 relative overflow-hidden backdrop-blur-md">
            <div className="absolute top-2.5 right-4 text-[9px] font-serif italic text-dusty-lilac opacity-50 select-none">
              Inspiration Node
            </div>
            <p className="font-serif italic text-[13px] leading-relaxed text-charcoal dark:text-[#E9DCCF]/90 pt-4 quotes uppercase-first">
              "{activeQuote.text}"
            </p>
            <p className="text-[9px] uppercase tracking-widest text-[#9E8AC9] font-bold mt-4 text-right">— {activeQuote.author}</p>
          </div>

          {/* Interactive Zen Focus Timer widget */}
          <div className="bg-white dark:bg-[#201D24] rounded-3xl p-6 border border-soft-beige/35 dark:border-white/5 shadow-xs">
            <div className="flex items-center justify-between border-b border-soft-beige/25 dark:border-white/5 pb-3 mb-4">
              <h4 className="font-serif text-xs font-semibold text-charcoal dark:text-cream flex items-center space-x-1.5">
                <Clock className="w-4 h-4 text-lavender animate-pulse" />
                <span>Zen Meditation Timer</span>
              </h4>
              <button
                onClick={() => setTimeLeft(25 * 60)}
                className="p-1 text-charcoal/30 hover:text-lavender transition-all"
                title="Reset session"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="text-center space-y-4 py-2">
              <div className="font-mono text-3xl font-bold text-charcoal dark:text-cream tracking-widest">
                {formatTime(timeLeft)}
              </div>

              {/* Slider / Preset Choices */}
              <div className="flex justify-center gap-1.5 flex-wrap">
                <button
                  type="button"
                  onClick={() => startTimer(5)}
                  className="px-2.5 py-1 text-[9px] font-bold border border-soft-beige/40 rounded-full hover:border-lavender text-charcoal/60 dark:text-cream/50"
                >
                  5m Zen
                </button>
                <button
                  type="button"
                  onClick={() => startTimer(15)}
                  className="px-3 py-1 text-[9px] font-bold border border-soft-beige/40 rounded-full hover:border-lavender text-charcoal/60 dark:text-cream/50"
                >
                  15m Breath
                </button>
                <button
                  type="button"
                  onClick={() => startTimer(25)}
                  className="px-3 py-1 text-[9px] font-bold border border-soft-beige/40 rounded-full hover:border-lavender text-charcoal/60 dark:text-cream/50"
                >
                  25m Pomodoro
                </button>
              </div>

              <div className="flex justify-center space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setTimerActive(!timerActive)}
                  className={`px-5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 ${
                    timerActive
                      ? 'bg-charcoal text-cream'
                      : 'bg-lavender text-white shadow-md shadow-lavender/10'
                  }`}
                >
                  {timerActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{timerActive ? 'Pause flow' : 'Start Focus'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Quick-toggle Habits Status bar */}
          <div className="bg-white dark:bg-[#201D24] rounded-3xl p-6 border border-soft-beige/35 dark:border-white/5 shadow-xs">
            <div className="flex items-center justify-between border-b border-soft-beige/20 dark:border-white/5 pb-3 mb-4">
              <h4 className="font-serif text-xs font-semibold text-charcoal dark:text-cream flex items-center space-x-1.5">
                <Trophy className="w-4 h-4 text-lavender" />
                <span>Rituals Tracker</span>
              </h4>
              <button
                onClick={() => onQuickNavigate('habit')}
                className="text-[10px] text-[#9E8AC9] hover:underline font-bold"
              >
                Edit →
              </button>
            </div>

            {habits.length === 0 ? (
              <p className="text-center text-[10px] text-charcoal/40 dark:text-cream/40 py-4 italic">No rituals initialized.</p>
            ) : (
              <div className="space-y-3.5">
                {habits.slice(0, 3).map((hab) => (
                  <div key={hab.id} className="flex justify-between items-center text-xs group hover:bg-neutral-50/50 dark:hover:bg-neutral-900 duration-150 p-1 rounded-lg">
                    <span className="font-semibold text-charcoal/80 dark:text-cream/80 text-[11px] truncate max-w-32">{hab.name}</span>
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-lavender/10 text-dusty-lilac whitespace-nowrap">
                      {hab.streaks}d streak
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Elegant Quick Add floating trigger widget (Floating Bento Button) */}
      <div className="fixed bottom-6 right-6 z-40 no-print">
        <button
          onClick={() => setShowQuickAddFloating(!showQuickAddFloating)}
          id="quick-add-floating-trigger"
          className="w-12 h-12 rounded-full bg-charcoal dark:bg-lavender text-cream dark:text-white hover:opacity-90 hover:scale-105 active:scale-95 transition-all shadow-xl shadow-charcoal/20 flex items-center justify-center cursor-pointer"
        >
          <Plus className={`w-6 h-6 transition-transform duration-300 ${showQuickAddFloating ? 'rotate-45' : ''}`} />
        </button>

        <AnimatePresence>
          {showQuickAddFloating && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="absolute bottom-16 right-0 bg-white dark:bg-[#201D24] rounded-2xl border border-soft-beige/35 dark:border-white/5 p-5 shadow-2xl w-72 space-y-4"
            >
              <div className="border-b border-soft-beige/25 dark:border-white/5 pb-2 mb-2">
                <h4 className="font-serif text-xs font-bold text-charcoal dark:text-cream">Quick Add Node</h4>
                <p className="text-[9px] text-charcoal/40 dark:text-cream/40 mt-0.5">Publish a high-priority task node to schedule deck</p>
              </div>

              <form onSubmit={handleQuickAdd} className="space-y-3">
                <input
                  type="text"
                  value={quickTaskText}
                  onChange={(e) => setQuickTaskText(e.target.value)}
                  placeholder="e.g. Refresh visual presets list"
                  autoFocus
                  className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl pl-3 pr-3 py-2 border border-soft-beige/40 focus:border-lavender focus:outline-hidden"
                />

                <div className="flex justify-between gap-1 grid grid-cols-3 text-center">
                  <button
                    type="button"
                    onClick={() => setQuickPriority('low')}
                    className={`py-1 rounded-lg text-[9px] font-bold ${quickPriority === 'low' ? 'bg-[#E9DCCF] text-charcoal' : 'bg-neutral-50 dark:bg-neutral-800 border border-neutral-100 dark:border-neutral-900 text-charcoal/60 dark:text-cream/50'}`}
                  >
                    Low
                  </button>
                  <button
                    type="button"
                    onClick={() => setQuickPriority('medium')}
                    className={`py-1 rounded-lg text-[9px] font-bold ${quickPriority === 'medium' ? 'bg-cream text-charcoal' : 'bg-neutral-50 dark:bg-neutral-800 border border-neutral-100 dark:border-neutral-900 text-charcoal/60 dark:text-cream/50'}`}
                  >
                    Med
                  </button>
                  <button
                    type="button"
                    onClick={() => setQuickPriority('high')}
                    className={`py-1 rounded-lg text-[9px] font-bold ${quickPriority === 'high' ? 'bg-[#B79CED] text-white' : 'bg-neutral-50 dark:bg-neutral-800 border border-neutral-100 dark:border-neutral-900 text-charcoal/60'}`}
                  >
                    High
                  </button>
                </div>

                <button
                  type="submit"
                  className="w-full py-2 bg-charcoal dark:bg-lavender text-cream dark:text-white text-[10px] font-bold rounded-lg cursor-pointer hover:opacity-95"
                >
                  Inject Node
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
