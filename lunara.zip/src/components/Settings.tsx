import React, { useState } from 'react';
import { Sparkles, Settings, Eye, RefreshCw, Layers, Shield, Volume2, Cloud, Download, Smile, Printer } from 'lucide-react';
import { UserProfile } from '../types';

interface SettingsProps {
  profile: UserProfile;
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
  onExportBackup: () => void;
  onTriggerSync: () => void;
  syncLoading: boolean;
  showToast?: (text: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
}

export default function SettingsView({
  profile,
  onUpdateProfile,
  onExportBackup,
  onTriggerSync,
  syncLoading,
  showToast
}: SettingsProps) {
  const [name, setName] = useState(profile.name);
  const [themePreset, setThemePreset] = useState(profile.theme);
  const [soundToggled, setSoundToggled] = useState(true);

  const themeOptions = [
    { id: 'soft-light', label: '奶油金 ｜ Creamy Ivory', color: 'bg-[#F7F3EE]' },
    { id: 'lavender-mist', label: '燕麦紫 ｜ Lavender Mist', color: 'bg-[#B79CED]/20' },
    { id: 'minimal-ivory', label: '极简白 ｜ Sand Dune', color: 'bg-[#E9DCCF]/20' },
    { id: 'charcoal-night', label: '黑曜岩 ｜ Obsidian Charcoal', color: 'bg-[#3A3640]/20' }
  ];

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({ name, theme: themePreset });
  };

  const handlePrintTrigger = () => {
    window.print();
  };

  return (
    <div id="settings-page" className="space-y-6">
      {/* Header section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-soft-beige/30 pb-6">
        <div>
          <h2 className="font-serif text-3xl font-medium text-charcoal flex items-center space-x-2">
            <Settings className="w-7 h-7 text-lavender" />
            <span>Sanctuary Settings</span>
          </h2>
          <p className="text-xs text-charcoal/60">Configure your aesthetics, connection nodes, and local memory engines</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Columns: Profile and aesthetics configs */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-2xl p-6 border border-soft-beige/35 shadow-xs">
            <h3 className="font-serif text-base font-semibold text-charcoal mb-4 flex items-center space-x-2">
              <Smile className="w-4 h-4 text-lavender" />
              <span>Personal Node details</span>
            </h3>

            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 mb-1.5">
                    Your Core Persona Signature
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-cream/30 text-xs text-charcoal rounded-xl pl-4 pr-4 py-3 border border-soft-beige/40 focus:border-lavender focus:outline-hidden font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 mb-1.5">
                    Email Authority
                  </label>
                  <input
                    type="text"
                    disabled
                    value={profile.email}
                    className="w-full bg-neutral-100 text-xs text-charcoal/40 rounded-xl pl-4 pr-4 py-3 border border-soft-beige/25 focus:outline-hidden cursor-not-allowed font-medium"
                  />
                </div>
              </div>

              {/* Theme custom picker */}
              <div className="space-y-2">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50">
                  Select Accent Atmosphere Grid
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {themeOptions.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setThemePreset(opt.id as any)}
                      className={`p-3 rounded-xl border text-left text-xs flex items-center space-x-3 transition-all cursor-pointer ${
                        themePreset === opt.id
                          ? 'border-lavender bg-lavender/5 shadow-xs'
                          : 'border-soft-beige/30 hover:border-lavender'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded-full ${opt.color} border border-soft-beige`} />
                      <span className="font-semibold text-charcoal/80 text-[11px]">{opt.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Save changes */}
              <button
                type="submit"
                id="save-settings-anchor"
                className="py-3 px-6 rounded-xl bg-charcoal text-cream text-xs font-semibold hover:opacity-90 transition-all shadow-xs cursor-pointer"
              >
                Engrave Customizations
              </button>
            </form>
          </div>

          {/* Export and PRINT actions */}
          <div className="bg-white rounded-2xl p-6 border border-soft-beige/35 shadow-xs">
            <h3 className="font-serif text-base font-semibold text-charcoal mb-4 flex items-center space-x-2">
              <Printer className="w-4 h-4 text-lavender" />
              <span>Export as High-Res PDF or Print</span>
            </h3>
            <p className="text-xs text-charcoal/60 leading-relaxed mb-4">
              Lunara includes an optimized, custom-styled media print layout. Pressing the button immediately transforms your current active schedule and notes into a clean, borderless document preview which you can save directly as a vector PDF.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={handlePrintTrigger}
                id="print-planner-pdf"
                className="flex-1 py-3 px-4 rounded-xl border border-lavender text-dusty-lilac hover:bg-lavender/5 text-xs font-bold transition-all flex items-center justify-center space-x-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4 text-lavender" />
                <span>Launch PDF Printing Dialogue</span>
              </button>
              <button
                onClick={onExportBackup}
                id="export-json-backup"
                className="flex-1 py-3 px-4 rounded-xl bg-cream text-charcoal hover:opacity-90 text-xs font-bold transition-all flex items-center justify-center space-x-1.5 cursor-pointer"
              >
                <Download className="w-4 h-4 text-charcoal/60" />
                <span>Download Local JSON Registry</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Connection Hub and memory engines */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white rounded-2xl p-6 border border-soft-beige/35 shadow-xs text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-lavender/10 text-lavender flex items-center justify-center mx-auto">
              <Cloud className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-serif text-sm font-semibold text-charcoal">Celestial Sync Hub</h3>
              <p className="text-[10px] text-charcoal/40 uppercase tracking-widest font-bold mt-1">Cross-device Handshake</p>
            </div>

            <div className="bg-cream/45 p-3.5 rounded-xl text-left border border-soft-beige/25">
              <div className="flex justify-between items-center text-[10px] font-bold mb-2 text-charcoal/70 uppercase">
                <span>Gate Authority status</span>
                <span className={profile.isLoggedIn ? 'text-emerald-700' : 'text-amber-700'}>
                  {profile.isLoggedIn ? '• Linked Secure' : '• Guest Sandbox'}
                </span>
              </div>
              <p className="text-[10px] text-charcoal/60 leading-relaxed">
                {profile.isLoggedIn
                  ? `Authenticated session under ${profile.email}. Real-time cloud writing stream active.`
                  : 'Unlocked inside offline sandboxed browser workspace. Sync is suspended.'}
              </p>
            </div>

            <button
              onClick={onTriggerSync}
              disabled={syncLoading}
              className="w-full py-3 rounded-xl bg-charcoal text-cream text-xs font-semibold hover:opacity-90 disabled:opacity-50 transition-all flex items-center justify-center space-x-2 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${syncLoading ? 'animate-spin' : ''}`} />
              <span>{syncLoading ? 'Harmonizing databases...' : 'Request Sync Handshake'}</span>
            </button>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-soft-beige/35 shadow-xs space-y-4">
            <h4 className="font-serif text-xs font-semibold text-charcoal">Security Checklist</h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-2 text-[11px] text-charcoal/70">
                <Shield className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Cookies are sandboxed inside local state tokens.</span>
              </div>
              <div className="flex items-start space-x-2 text-[11px] text-charcoal/70">
                <Volume2 className="w-4 h-4 text-charcoal/45 shrink-0 mt-0.5" />
                <span>Haptic sounds play nicely on scheduling events.</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
