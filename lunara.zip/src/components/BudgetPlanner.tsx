import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  DollarSign,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  Heart,
  Award,
  Trash2,
} from 'lucide-react';
import { BarChart, Bar, Cell, Tooltip, ResponsiveContainer, XAxis, YAxis } from 'recharts';
import { BudgetItem, SavingGoal, BudgetCategory } from '../types';

interface BudgetPlannerProps {
  budgetItems: BudgetItem[];
  savingGoals: SavingGoal[];
  onAddBudgetItem: (item: Omit<BudgetItem, 'id'>) => void;
  onDeleteBudgetItem: (id: string) => void;
  onAddSavingGoal: (title: string, target: number, current: number, category: string) => void;
  onDeleteSavingGoal: (id: string) => void;
  onUpdateSavingGoalProgress: (id: string, newAmount: number) => void;
  selectedDate: string;
  showToast?: (text: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
}

export default function BudgetPlanner({
  budgetItems,
  savingGoals,
  onAddBudgetItem,
  onDeleteBudgetItem,
  onAddSavingGoal,
  onDeleteSavingGoal,
  onUpdateSavingGoalProgress,
  selectedDate,
  showToast,
}: BudgetPlannerProps) {
  // Budget Form States
  const [desc, setDesc] = useState('');
  const [amountStr, setAmountStr] = useState('');
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [category, setCategory] = useState<BudgetCategory | 'Salary' | 'Freelance' | 'Allowance' | 'Dividends'>('Food');

  // Saving Goal Form States
  const [goalTitle, setGoalTitle] = useState('');
  const [goalTargetStr, setGoalTargetStr] = useState('');
  const [goalCategory, setGoalCategory] = useState('Travel');
  const [activeTab, setActiveTab] = useState<'ledger' | 'savings'>('ledger');
  const [isLoading, setIsLoading] = useState(true);

  // Briefly mimic loading sequence for absolute fluid feeling
  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 450);
    return () => clearTimeout(timer);
  }, []);

  const handleAddBudget = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(amountStr);
    if (!desc.trim() || isNaN(amount) || amount <= 0) {
      showToast?.('Please review fields. Input valid positive weights.', 'warning');
      return;
    }

    onAddBudgetItem({
      description: desc.trim(),
      amount,
      type,
      category,
      date: selectedDate,
    });

    setDesc('');
    setAmountStr('');
    showToast?.('Transaction ledger item written securely.', 'success');
  };

  const handleCreateSavingsGoal = (e: React.FormEvent) => {
    e.preventDefault();
    const target = parseFloat(goalTargetStr);
    if (!goalTitle.trim() || isNaN(target) || target <= 0) {
      showToast?.('Input a valid name/goal size.', 'warning');
      return;
    }

    onAddSavingGoal(goalTitle.trim(), target, 0, goalCategory);
    setGoalTitle('');
    setGoalTargetStr('');
    showToast?.('Savings target capsule seeded with grace.', 'success');
  };

  // Calculations
  const calculatedIncome = budgetItems
    .filter((b) => b.type === 'income')
    .reduce((sum, b) => sum + b.amount, 0);

  const calculatedExpenses = budgetItems
    .filter((b) => b.type === 'expense')
    .reduce((sum, b) => sum + b.amount, 0);

  const currentSurplus = calculatedIncome - calculatedExpenses;

  // Render chart representing category spends
  const expenseCategories = Array.from(new Set(budgetItems.filter(b => b.type === 'expense').map(b => b.category)));
  const barChartData = expenseCategories.map((cat) => {
    const total = budgetItems
      .filter((b) => b.type === 'expense' && b.category === cat)
      .reduce((sum, b) => sum + b.amount, 0);
    return {
      name: cat,
      Spent: total,
    };
  });

  // Recharts custom colors list
  const COLORS = ['#B79CED', '#9E8AC9', '#E9DCCF', '#F87171', '#60A5FA', '#34D399'];

  return (
    <div id="budget-planner-page" className="space-y-6">
      {/* Exquisite Budget Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-soft-beige/30 dark:border-white/5 pb-6">
        <div>
          <h2 className="font-serif text-3xl font-medium text-charcoal dark:text-cream flex items-center space-x-2">
            <DollarSign className="w-7 h-7 text-lavender" />
            <span>Atmosphere Ledger Board</span>
          </h2>
          <p className="text-xs text-charcoal/60 dark:text-[#E9DCCF]/65 mt-1">
            Map financial surplus flowing across categories and save for long-term target capsules
          </p>
        </div>

        {/* Floating Subtabs */}
        <div className="flex bg-[#F7F3EE]/60 dark:bg-white/5 p-1 rounded-2xl border border-soft-beige/25 no-print">
          <button
            onClick={() => setActiveTab('ledger')}
            className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'ledger'
                ? 'bg-charcoal dark:bg-lavender text-cream dark:text-white shadow-xs'
                : 'text-charcoal/40 dark:text-[#E9DCCF]/65 hover:text-charcoal'
            }`}
          >
            Transactions Ledger
          </button>
          <button
            onClick={() => setActiveTab('savings')}
            className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'savings'
                ? 'bg-charcoal dark:bg-lavender text-cream dark:text-white shadow-xs'
                : 'text-charcoal/40 dark:text-[#E9DCCF]/65 hover:text-charcoal'
            }`}
          >
            Savings Capsules
          </button>
        </div>
      </div>

      {/* Ledger Stats bento grid cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 bg-white dark:bg-[#201D24] border border-soft-beige/35 dark:border-white/5 rounded-3xl shadow-2xs">
          <div className="flex items-center justify-between text-charcoal/40 dark:text-[#E9DCCF]/50 text-[10px] uppercase font-bold tracking-widest">
            <span>Cumulative Inflow</span>
            <ArrowUpRight className="w-4 h-4 text-emerald-600 animate-bounce" />
          </div>
          <p className="font-serif text-2xl font-bold mt-2 text-emerald-700 dark:text-emerald-500">
            ${calculatedIncome.toFixed(2)}
          </p>
        </div>

        <div className="p-6 bg-white dark:bg-[#201D24] border border-soft-beige/35 dark:border-white/5 rounded-3xl shadow-2xs">
          <div className="flex items-center justify-between text-charcoal/40 dark:text-[#E9DCCF]/50 text-[10px] uppercase font-bold tracking-widest">
            <span>Cumulative Outflow</span>
            <ArrowDownRight className="w-4 h-4 text-red-500" />
          </div>
          <p className="font-serif text-2xl font-bold mt-2 text-rose-700 dark:text-rose-500">
            ${calculatedExpenses.toFixed(2)}
          </p>
        </div>

        <div className="p-6 bg-white dark:bg-[#201D24] border border-soft-beige/35 dark:border-white/5 rounded-3xl shadow-2xs">
          <div className="flex items-center justify-between text-charcoal/40 dark:text-[#E9DCCF]/50 text-[10px] uppercase font-bold tracking-widest">
            <span>Surplus Balance</span>
            <Sparkles className="w-4 h-4 text-lavender" />
          </div>
          <p className="font-serif text-2xl font-bold mt-2 text-[#9E8AC9] dark:text-[#B79CED]">
            ${currentSurplus.toFixed(2)}
          </p>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'ledger' ? (
          <motion.div
            key="ledger-tab"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="grid grid-cols-1 lg:grid-cols-5 gap-8"
          >
            {/* Left Ledger Column: Compose item */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white dark:bg-[#201D24] rounded-3xl p-6 border border-soft-beige/35 dark:border-white/5 shadow-xs">
                <h3 className="font-serif text-base font-semibold text-charcoal dark:text-cream mb-4 flex items-center space-x-2">
                  <Sparkles className="w-4.5 h-4.5 text-lavender" />
                  <span>Record Transaction</span>
                </h3>

                <form onSubmit={handleAddBudget} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                      Transaction Description
                    </label>
                    <input
                      type="text"
                      value={desc}
                      onChange={(e) => setDesc(e.target.value)}
                      placeholder="e.g. Lavender botanical watercolor set"
                      className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl px-4 py-3 border border-soft-beige/40 dark:border-white/10 focus:border-lavender focus:outline-hidden font-semibold"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                        Amount Weight ($)
                      </label>
                      <input
                        type="text"
                        value={amountStr}
                        onChange={(e) => setAmountStr(e.target.value)}
                        placeholder="e.g. 58.00"
                        className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl px-4 py-3 border border-soft-beige/40 dark:border-white/10 focus:border-lavender focus:outline-hidden font-semibold"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                        Ledger Category
                      </label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value as any)}
                        className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl p-3 border border-soft-beige/40 dark:border-white/10 dark:text-cream font-semibold cursor-pointer"
                      >
                        {type === 'expense' ? (
                          <>
                            <option value="Food">🍽️ Food</option>
                            <option value="Transport">🚕 Transport</option>
                            <option value="Creativity">🎨 Creativity</option>
                            <option value="Academics">📚 Academics</option>
                            <option value="Wellness">🧘 Wellness</option>
                          </>
                        ) : (
                          <>
                            <option value="Salary">💼 Salary</option>
                            <option value="Freelance">🎨 Freelance</option>
                            <option value="Allowance">🎁 Allowance</option>
                            <option value="Dividends">📈 Dividends</option>
                          </>
                        )}
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40">
                      Transaction Mode
                    </label>
                    <div className="flex bg-[#F7F3EE]/65 dark:bg-white/5 p-1 rounded-xl">
                      <button
                        type="button"
                        onClick={() => {
                          setType('expense');
                          setCategory('Food');
                        }}
                        className={`flex-1 text-[10px] py-2 rounded-lg font-bold uppercase tracking-wider transition-all duration-150 cursor-pointer ${
                          type === 'expense'
                            ? 'bg-charcoal dark:bg-lavender text-cream dark:text-white shadow-xs'
                            : 'text-charcoal/40 dark:text-[#E9DCCF]/65'
                        }`}
                      >
                        Outflow Expense
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setType('income');
                          setCategory('Salary');
                        }}
                        className={`flex-1 text-[10px] py-1.5 rounded-lg font-bold uppercase tracking-wider transition-all duration-150 cursor-pointer ${
                          type === 'income'
                            ? 'bg-charcoal dark:bg-lavender text-cream dark:text-white shadow-xs'
                            : 'text-charcoal/40 dark:text-[#E9DCCF]/65'
                        }`}
                      >
                        Inflow Income
                      </button>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-xl bg-charcoal dark:bg-lavender text-cream dark:text-white text-xs font-semibold hover:opacity-90 transition-all flex items-center justify-center space-x-2 shadow-xs cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Engrave Transaction</span>
                  </button>
                </form>
              </div>
            </div>

            {/* Right Ledger Column: Row details and distribution chart */}
            <div className="lg:col-span-3 space-y-6">
              {/* Category distribution visual chart */}
              {barChartData.length > 0 && (
                <div className="bg-white dark:bg-[#201D24] p-6 border border-soft-beige/35 dark:border-white/5 rounded-3xl shadow-xs">
                  <h4 className="font-serif text-xs font-bold text-charcoal dark:text-cream mb-4">Outflow Volume Distribution</h4>
                  <div className="h-32 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={barChartData}>
                        <XAxis dataKey="name" tick={{ fontSize: 9, fill: '#7D756C' }} axisLine={false} tickLine={false} />
                        <YAxis tick={{ fontSize: 9, fill: '#7D756C' }} axisLine={false} tickLine={false} />
                        <Tooltip contentStyle={{ borderRadius: '12px', fontSize: '10px' }} />
                        <Bar dataKey="Spent">
                          {barChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

              <div className="bg-white dark:bg-[#201D24] rounded-3xl p-6 border border-soft-beige/35 dark:border-white/5 shadow-xs">
                <h3 className="font-serif text-base font-semibold text-charcoal dark:text-cream mb-4">Active Ledger Records</h3>

                {budgetItems.length === 0 ? (
                  <p className="text-center py-16 text-charcoal/40 dark:text-cream/40 font-serif italic text-xs">No ledger records active for this timeframe.</p>
                ) : (
                  <div className="space-y-3.5 max-h-[400px] overflow-y-auto pr-1">
                    <AnimatePresence initial={false}>
                      {budgetItems.map((item, ind) => (
                        <motion.div
                          key={item.id}
                          initial={{ opacity: 0, y: 15 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, x: -20 }}
                          transition={{ duration: 0.25, delay: ind * 0.05 }}
                          className="p-4 border border-soft-beige/25 dark:border-white/5 rounded-2xl bg-white dark:bg-[#201D24] flex items-center justify-between hover:border-lavender/35 group duration-150"
                        >
                          <div>
                            <h4 className="text-xs font-bold text-charcoal dark:text-cream">{item.description}</h4>
                            <div className="flex items-center space-x-2.5 text-[9px] text-charcoal/40 dark:text-[#E9DCCF]/50 font-bold uppercase tracking-wider mt-1">
                              <span>{item.category}</span>
                              <span>•</span>
                              <span>{item.date}</span>
                            </div>
                          </div>

                          <div className="flex items-center space-x-4">
                            <span className={`text-xs font-bold leading-none ${item.type === 'income' ? 'text-emerald-700 dark:text-emerald-500' : 'text-rose-700 dark:text-rose-500'}`}>
                              {item.type === 'income' ? '+' : '-'}${item.amount.toFixed(2)}
                            </span>
                            <button
                              onClick={() => {
                                onDeleteBudgetItem(item.id);
                                showToast?.('Transaction ledger item erased.', 'info');
                              }}
                              className="p-1 hover:bg-neutral-50 dark:hover:bg-neutral-900 text-charcoal/20 hover:text-red-650 rounded-lg opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
                              title="Tear log item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="savings-tab"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="grid grid-cols-1 lg:grid-cols-5 gap-8"
          >
            {/* Compound Left Column: Compose Savings Goal */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white dark:bg-[#201D24] rounded-3xl p-6 border border-soft-beige/35 dark:border-white/5 shadow-xs">
                <h3 className="font-serif text-base font-semibold text-charcoal dark:text-cream mb-4 flex items-center space-x-2">
                  <Heart className="w-4 h-4 text-lavender" />
                  <span>Seed Savings Capsule</span>
                </h3>

                <form onSubmit={handleCreateSavingsGoal} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                      Target Capsule Identifier
                    </label>
                    <input
                      type="text"
                      value={goalTitle}
                      onChange={(e) => setGoalTitle(e.target.value)}
                      placeholder="e.g. Kyoto Cherry Blossom Voyage"
                      className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl px-4 py-3 border border-soft-beige/40 dark:border-white/10 focus:border-lavender focus:outline-hidden font-semibold"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                        Target Sum ($)
                      </label>
                      <input
                        type="text"
                        value={goalTargetStr}
                        onChange={(e) => setGoalTargetStr(e.target.value)}
                        placeholder="e.g. 5000"
                        className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl px-4 py-3 border border-soft-beige/40 dark:border-white/10 focus:border-lavender focus:outline-hidden font-semibold"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5 font-bold">
                        Capsule Tag
                      </label>
                      <select
                        value={goalCategory}
                        onChange={(e) => setGoalCategory(e.target.value)}
                        className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl p-3 border border-soft-beige/45 dark:border-white/10 dark:text-cream font-semibold cursor-pointer"
                      >
                        <option value="Travel">✈️ Travel</option>
                        <option value="Tech Node">💻 Tech Node</option>
                        <option value="Sustenance">🏛️ Sanctuary</option>
                        <option value="Education">📚 Education</option>
                        <option value="Aesthetics">🎨 Aesthetics</option>
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-xl bg-charcoal dark:bg-lavender text-cream dark:text-white text-xs font-semibold hover:opacity-90 transition-all flex items-center justify-center space-x-2 shadow-xs cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Engrave Capsule</span>
                  </button>
                </form>
              </div>
            </div>

            {/* Compound Right Column: Savings goal capsules detailing progress sliders */}
            <div className="lg:col-span-3 space-y-6">
              <div className="bg-white dark:bg-[#201D24] p-6 border border-soft-beige/35 dark:border-white/5 rounded-3xl shadow-xs">
                <h3 className="font-serif text-base font-semibold text-charcoal dark:text-cream mb-4">Seeded Savings Capsules</h3>

                {savingGoals.length === 0 ? (
                  <p className="text-center py-16 text-charcoal/40 dark:text-cream/40 font-serif italic text-xs">No active savings capsules seeded.</p>
                ) : (
                  <div className="space-y-6 max-h-[500px] overflow-y-auto pr-1">
                    <AnimatePresence initial={false}>
                      {savingGoals.map((goal, ind) => {
                        const pct = Math.min(Math.round((goal.currentAmount / goal.targetAmount) * 100), 100);
                        return (
                          <motion.div
                            key={goal.id}
                            initial={{ opacity: 0, y: 15 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            transition={{ duration: 0.28, delay: ind * 0.05 }}
                            className="p-5 border border-soft-beige/25 dark:border-white/5 rounded-2xl space-y-4 hover:border-lavender/35 group relative bg-white dark:bg-[#201D24]"
                          >
                            <div className="flex justify-between items-start">
                              <div>
                                <span className="text-[10px] bg-[#E9DCCF]/35 text-charcoal/60 dark:text-cream px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">{goal.category}</span>
                                <h4 className="font-serif text-sm font-bold text-charcoal dark:text-cream mt-1.5">{goal.title}</h4>
                              </div>
                              <button
                                onClick={() => {
                                  onDeleteSavingGoal(goal.id);
                                  showToast?.('Savings goal deleted.', 'info');
                                }}
                                className="p-1 hover:bg-neutral-50 dark:hover:bg-neutral-900 text-charcoal/20 hover:text-red-650 rounded-lg cursor-pointer opacity-0 group-hover:opacity-100 transition-all shrink-0"
                                title="Delete Goal"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            {/* Contribution slider bar gauge */}
                            <div className="space-y-2">
                              <div className="flex justify-between text-[11px] font-semibold text-charcoal/80 dark:text-[#E9DCCF]/90">
                                <span>${goal.currentAmount} saved</span>
                                <span>of ${goal.targetAmount} ({pct}%)</span>
                              </div>
                              <div className="w-full bg-[#E9DCCF]/30 rounded-full h-2 overflow-hidden relative">
                                <div
                                  className="bg-lavender h-full rounded-full transition-all duration-300"
                                  style={{ width: `${pct}%` }}
                                />
                              </div>

                              {/* Miniature input slider for rapid updates */}
                              <div className="flex items-center space-x-3 pt-2.5">
                                <label className="text-[9px] font-bold uppercase tracking-wider text-charcoal/40 dark:text-cream/50">Update weight:</label>
                                <input
                                  type="range"
                                  min="0"
                                  max={goal.targetAmount}
                                  value={goal.currentAmount}
                                  onChange={(e) => {
                                    onUpdateSavingGoalProgress(goal.id, parseFloat(e.target.value));
                                  }}
                                  className="flex-1 accent-lavender cursor-ew-resize"
                                />
                              </div>
                            </div>
                          </motion.div>
                        );
                      })}
                    </AnimatePresence>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
