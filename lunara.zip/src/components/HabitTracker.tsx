import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Trophy, Plus, Check, Star, Trash2 } from 'lucide-react';
import { Habit } from '../types';

interface HabitTrackerProps {
  habits: Habit[];
  onToggleHabit: (id: string, date: string) => void;
  onAddHabit: (name: string, category: string, frequency: 'daily' | 'weekly') => void;
  onDeleteHabit: (id: string) => void;
  selectedDate: string; // YYYY-MM-DD
  showToast?: (text: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
}

export default function HabitTracker({
  habits,
  onToggleHabit,
  onAddHabit,
  onDeleteHabit,
  selectedDate,
  showToast,
}: HabitTrackerProps) {
  const [habitName, setHabitName] = useState('');
  const [category, setCategory] = useState('Wellness');
  const [frequency, setFrequency] = useState<'daily' | 'weekly'>('daily');
  const [isLoading, setIsLoading] = useState(true);

  // Trigger loading screen mimic
  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 350);
    return () => clearTimeout(timer);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!habitName.trim()) return;
    onAddHabit(habitName.trim(), category, frequency);
    setHabitName('');
    showToast?.('Habit ritual established successfully.', 'success');
  };

  // Generate the last 7 days including today beautifully
  const getPastSevenDays = () => {
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(selectedDate);
      d.setDate(d.getDate() - i);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      days.push({
        dateStr: `${yyyy}-${mm}-${dd}`,
        label: d.toLocaleDateString('en-US', { weekday: 'narrow' }),
        num: d.getDate(),
      });
    }
    return days;
  };

  const lastSevenDays = getPastSevenDays();

  // Evaluate luxury total streaks achievement score
  const totalStreaks = habits.reduce((sum, h) => sum + (h.streaks || 0), 0);
  const totalHabitsCompletedToday = habits.filter((h) => h.completedDates?.includes(selectedDate)).length;

  return (
    <div id="habit-tracker-page" className="space-y-6">
      {/* Exquisite Habit Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-soft-beige/30 dark:border-white/5 pb-6">
        <div>
          <h2 className="font-serif text-3xl font-medium text-charcoal dark:text-cream flex items-center space-x-2">
            <Trophy className="w-7 h-7 text-lavender" />
            <span>Habit Ritual Stream</span>
          </h2>
          <p className="text-xs text-charcoal/60 dark:text-[#E9DCCF]/65 mt-1">
            Build compounding consistency through minimal daily commitments & ritual milestones
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left column: compose field & trophy shelf */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-[#201D24] p-6 border border-soft-beige/35 dark:border-white/5 rounded-3xl shadow-xs">
            <h3 className="font-serif text-base font-semibold text-charcoal dark:text-cream mb-4 flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-lavender" />
              <span>Initiate New Ritual</span>
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                  Ritual Identifier
                </label>
                <input
                  type="text"
                  value={habitName}
                  onChange={(e) => setHabitName(e.target.value)}
                  placeholder="e.g. 15 mins of Morning Calm Writing"
                  className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl px-4 py-3 border border-soft-beige/40 dark:border-white/10 focus:border-lavender focus:outline-hidden font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                    Category Sphere
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl p-3 border border-soft-[#E9DCCF] dark:border-white/10 dark:text-cream font-semibold cursor-pointer"
                  >
                    <option value="Wellness">🧬 Wellness</option>
                    <option value="Intellectual">🧠 Minds</option>
                    <option value="Artistry">🎨 Artistry</option>
                    <option value="Structure">🏛️ Structure</option>
                    <option value="Social Node">🕊️ Social</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5 font-bold">
                    Cadence Focus
                  </label>
                  <div className="flex bg-[#F7F3EE]/60 dark:bg-white/5 p-1 rounded-xl">
                    <button
                      type="button"
                      onClick={() => setFrequency('daily')}
                      className={`flex-1 text-[10px] py-1.5 rounded-lg font-bold uppercase tracking-wider transition-all duration-150 cursor-pointer ${
                        frequency === 'daily'
                          ? 'bg-charcoal dark:bg-lavender text-cream dark:text-white shadow-xs'
                          : 'text-charcoal/40 dark:text-cream/55'
                      }`}
                    >
                      Daily
                    </button>
                    <button
                      type="button"
                      onClick={() => setFrequency('weekly')}
                      className={`flex-1 text-[10px] py-1.5 rounded-lg font-bold uppercase tracking-wider transition-all duration-150 cursor-pointer ${
                        frequency === 'weekly'
                          ? 'bg-charcoal dark:bg-lavender text-cream dark:text-white shadow-xs'
                          : 'text-charcoal/40 dark:text-cream/55'
                      }`}
                    >
                      Weekly
                    </button>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-charcoal dark:bg-lavender text-cream dark:text-white text-xs font-semibold hover:opacity-90 transition-all flex items-center justify-center space-x-2 shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Establish Ritual</span>
              </button>
            </form>
          </div>

          {/* Achievement Trophy Vault */}
          <div className="bg-gradient-to-br from-[#9E8AC9]/10 to-transparent dark:from-[#201D24] p-6 border border-[#9E8AC9]/20 rounded-3xl space-y-4">
            <h4 className="font-serif text-sm font-semibold text-charcoal dark:text-cream flex items-center space-x-1.5">
              <Trophy className="w-4 h-4 text-[#B79CED]" />
              <span>Sanctuary Achievement Vault</span>
            </h4>
            <p className="text-[10px] text-charcoal/60 dark:text-[#E9DCCF]/65 leading-relaxed">
              As your streaks extend, your private sanctuary unlocks custom aesthetic markers.
            </p>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className={`p-3 rounded-2xl border text-center space-y-2 transition-all ${totalStreaks >= 5 ? 'border-[#B79CED] bg-white dark:bg-[#201D24]' : 'border-dashed border-soft-beige dark:border-white/5 opacity-50'}`}>
                <div className="text-2xl">🌱</div>
                <div className="text-[9px] font-bold uppercase tracking-wider dark:text-cream">Sprout Seed</div>
                <div className="text-[8px] text-charcoal/40 dark:text-[#E9DCCF]/40 font-semibold">{totalStreaks >= 5 ? 'Active' : 'Need 5 streaks'}</div>
              </div>

              <div className={`p-3 rounded-2xl border text-center space-y-2 transition-all ${totalStreaks >= 15 ? 'border-amber-500 bg-white dark:bg-[#201D24]' : 'border-dashed border-soft-beige dark:border-white/5 opacity-50'}`}>
                <div className="text-2xl">💎</div>
                <div className="text-[9px] font-bold uppercase tracking-wider dark:text-cream">Diamond Core</div>
                <div className="text-[8px] text-charcoal/40 dark:text-[#E9DCCF]/40 font-semibold">{totalStreaks >= 15 ? 'Active' : 'Need 15 streaks'}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right column: Active rituals grid and tracking calendars */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-[#201D24] p-6 border border-soft-beige/35 dark:border-white/5 rounded-3xl shadow-xs">
            <div className="flex justify-between items-center pb-4 border-b border-soft-beige/20 dark:border-white/5 mb-4">
              <div>
                <h3 className="font-serif text-base font-semibold text-charcoal dark:text-cream">Core Ritual Decks</h3>
                <p className="text-[10px] text-charcoal/40 dark:text-[#E9DCCF]/40 uppercase tracking-widest font-bold">
                  {totalHabitsCompletedToday} resolved today
                </p>
              </div>
            </div>

            {isLoading ? (
              <div className="space-y-4 py-8">
                {[1, 2].map((ind) => (
                  <div key={ind} className="h-20 w-full bg-cream/15 dark:bg-white/5 animate-pulse rounded-2xl border border-soft-beige/10" />
                ))}
              </div>
            ) : habits.length === 0 ? (
              <div className="text-center py-20 text-charcoal/40 dark:text-cream/40">
                <Star className="w-10 h-10 mx-auto opacity-35 mb-3" />
                <p className="font-serif italic text-xs">No active commitments seeded yet.</p>
              </div>
            ) : (
              <div className="space-y-4 max-h-[550px] overflow-y-auto pr-1">
                <AnimatePresence initial={false}>
                  {habits.map((hab, ind) => (
                    <motion.div
                      key={hab.id}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95, filter: 'blur(3px)' }}
                      transition={{ duration: 0.28, delay: ind * 0.05 }}
                      className="p-5 border border-soft-beige/30 dark:border-white/5 bg-white dark:bg-[#201D24] rounded-2xl space-y-4 relative group hover:border-lavender/35"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center space-x-2">
                            <h4 className="font-serif text-[13px] font-bold text-charcoal dark:text-cream">
                              {hab.name}
                            </h4>
                            <span className="text-[9px] bg-lavender/10 text-dusty-lilac px-2 py-0.5 rounded-full font-bold">
                              {hab.category}
                            </span>
                          </div>
                          <span className="text-[9px] text-charcoal/40 dark:text-[#E9DCCF]/45 font-bold uppercase tracking-wide">
                            🔥 {hab.streaks || 0}d current streak count
                          </span>
                        </div>

                        {/* Trash icon layout */}
                        <button
                          onClick={() => {
                            onDeleteHabit(hab.id);
                            showToast?.('Ritual eliminated from registry database.', 'info');
                          }}
                          className="p-1 hover:bg-neutral-50 dark:hover:bg-neutral-900 text-charcoal/20 hover:text-red-650 rounded-lg transition-colors cursor-pointer opacity-0 group-hover:opacity-100 shrink-0"
                          title="Erase ritual"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* past 7 days check circles calendar timeline */}
                      <div className="grid grid-cols-7 gap-2.5 pt-1.5 border-t border-cream dark:border-white/5">
                        {lastSevenDays.map((day) => {
                          const isDone = hab.completedDates?.includes(day.dateStr);
                          return (
                            <button
                              key={day.dateStr}
                              onClick={() => {
                                onToggleHabit(hab.id, day.dateStr);
                                showToast?.(
                                  isDone
                                    ? 'Restoring checkpoint state.'
                                    : 'Aesthetic commitment locked for this day. Superb!',
                                  'success'
                                );
                              }}
                              className={`flex flex-col items-center p-2 rounded-xl border transition-all cursor-pointer ${
                                isDone
                                  ? 'bg-emerald-500/15 border-emerald-500 text-emerald-600 font-semibold scale-102 shadow-xs'
                                  : 'bg-white dark:bg-[#252129] border-soft-[#E9DCCF]/45 dark:border-white/5 text-charcoal/50 dark:text-cream/50 hover:border-lavender/40'
                              }`}
                            >
                              <span className="text-[8px] font-bold uppercase block mb-1">{day.label}</span>
                              <div className="w-5 h-5 rounded-full flex items-center justify-center">
                                {isDone ? (
                                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                                ) : (
                                  <span className="text-[9px] font-bold">{day.num}</span>
                                )}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
