import React, { useState } from 'react';
import { Sparkles, ArrowRight, Compass, Heart, GraduationCap, Video } from 'lucide-react';
import { UserProfile } from '../types';

interface OnboardingProps {
  onComplete: (name: string, lifestyle: string) => void;
}

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [selectedLifestyle, setSelectedLifestyle] = useState('creator');

  const lifestyles = [
    {
      id: 'creator',
      icon: <Video className="w-5 h-5 text-lavender" />,
      label: 'Digital Creator',
      desc: 'Focused on publishing schedules, gear investments, and brand story creation.',
    },
    {
      id: 'professional',
      icon: <Compass className="w-5 h-5 text-lavender" />,
      label: 'Young Professional',
      desc: 'Optimized for high-impact consulting specs, client reviews, and emergency shields.',
    },
    {
      id: 'student',
      icon: <GraduationCap className="w-5 h-5 text-lavender" />,
      label: 'Academic Student',
      desc: 'Centered around chapter study blocks, thesis milestones, and strict budget caps.',
    },
    {
      id: 'holistic',
      icon: <Heart className="w-5 h-5 text-lavender" />,
      label: 'Holistic Nomad',
      desc: 'Nurtured around morning yoga intervals, self-care routines, and travel retreats.',
    },
  ];

  const handleNext = () => {
    if (step === 1 && !name.trim()) {
      return; // force name entry
    }
    if (step === 2) {
      onComplete(name, selectedLifestyle);
    } else {
      setStep(2);
    }
  };

  return (
    <div className="fixed inset-0 bg-charcoal/30 backdrop-blur-md z-50 flex items-center justify-center p-6">
      <div className="w-full max-w-lg bg-white rounded-2xl border border-soft-beige/40 p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-[150px] bg-linear-to-b from-lavender/10 to-transparent pointer-events-none" />

        {/* Top badge */}
        <div className="flex items-center space-x-2 text-xs text-[#9E8AC9] font-bold tracking-widest uppercase mb-6">
          <Sparkles className="w-4 h-4 text-lavender" />
          <span>Step {step} of 2 • Lunara Portal</span>
        </div>

        {step === 1 ? (
          <div>
            <h2 className="font-serif text-3xl text-charcoal tracking-tight font-medium mb-4">
              Whom shall we address <br />
              <span className="italic text-dusty-lilac">this digital shelf to?</span>
            </h2>
            <p className="text-xs text-charcoal/60 leading-relaxed mb-6">
              Welcome to your personal productivity dashboard. We will engrave your name into your daily scheduler and morning reflection space.
            </p>

            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/60 mb-2">
                  Your Signature Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Marie Sterling"
                  autoFocus
                  className="w-full bg-cream/40 text-sm text-charcoal rounded-xl pl-4 pr-4 py-3.5 border border-soft-beige/50 focus:border-lavender focus:outline-hidden font-medium transition-all"
                />
              </div>
            </div>
          </div>
        ) : (
          <div>
            <h2 className="font-serif text-3xl text-charcoal tracking-tight font-medium mb-4">
              Select your <br />
              <span className="italic text-dusty-lilac">dominant lifestyle rhythm</span>
            </h2>
            <p className="text-xs text-charcoal/60 leading-relaxed mb-6">
              This helps pre-tune your budget categories, daily goal trackers, and reflection triggers for immediate visual guidance.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {lifestyles.map((style) => (
                <div
                  key={style.id}
                  onClick={() => setSelectedLifestyle(style.id)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    selectedLifestyle === style.id
                      ? 'border-lavender bg-lavender/5 shadow-xs'
                      : 'border-soft-beige/30 bg-neutral-50 hover:bg-neutral-100'
                  }`}
                >
                  <div className="flex items-center space-x-2 mb-2">
                    {style.icon}
                    <h4 className="text-xs font-bold text-charcoal">{style.label}</h4>
                  </div>
                  <p className="text-[10px] text-charcoal/60 leading-relaxed">{style.desc}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mt-8 pt-6 border-t border-soft-beige/20 flex items-center justify-between">
          <div className="flex space-x-1">
            <div className={`w-6 h-1 rounded-full ${step === 1 ? 'bg-lavender' : 'bg-soft-beige/50'}`} />
            <div className={`w-6 h-1 rounded-full ${step === 2 ? 'bg-lavender' : 'bg-soft-beige/50'}`} />
          </div>

          <button
            onClick={handleNext}
            className="px-6 py-3 rounded-full bg-charcoal text-cream text-xs font-semibold hover:opacity-90 flex items-center space-x-2 shadow-md cursor-pointer"
          >
            <span>{step === 1 ? 'Continue' : 'Enter Sanctuary'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
