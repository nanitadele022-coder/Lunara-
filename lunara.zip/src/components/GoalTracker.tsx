import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  Target,
  Plus,
  CheckSquare,
  Square,
  Trash2,
  Calendar,
  ChevronRight,
} from 'lucide-react';
import { SMARTGoal, Milestone } from '../types';

interface GoalTrackerProps {
  goals: SMARTGoal[];
  onAddGoal: (goal: Omit<SMARTGoal, 'id' | 'progress'>) => void;
  onDeleteGoal: (id: string) => void;
  onToggleMilestone: (goalId: string, milestoneId: string) => void;
  showToast?: (text: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
}

export default function GoalTracker({
  goals,
  onAddGoal,
  onDeleteGoal,
  onToggleMilestone,
  showToast,
}: GoalTrackerProps) {
  // Goal Creator states
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [category, setCategory] = useState('Creator');
  const [targetDate, setTargetDate] = useState('');
  const [visionImage, setVisionImage] = useState('');
  const [milestonesText, setMilestonesText] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // Briefly mock layout load for smooth flow
  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 350);
    return () => clearTimeout(timer);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      showToast?.('Objective title is required.', 'warning');
      return;
    }

    // Parse comma-separated milestones
    const parsedMilestones: Milestone[] = milestonesText
      .split('\n')
      .filter((line) => line.trim().length > 0)
      .map((line, ind) => ({
        id: `ms-p-${Date.now()}-${ind}`,
        text: line.trim(),
        completed: false,
      }));

    onAddGoal({
      title: title.trim(),
      description: desc.trim(),
      category,
      targetDate: targetDate || new Date().toISOString().split('T')[0],
      milestones: parsedMilestones,
      visionBoardImage: visionImage.trim() || undefined,
    });

    setTitle('');
    setDesc('');
    setMilestonesText('');
    setVisionImage('');
    showToast?.('Target objective seeded successfully.', 'success');
  };

  return (
    <div id="goal-tracker-page" className="space-y-6">
      {/* Exquisite Goal Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-soft-beige/30 dark:border-white/5 pb-6">
        <div>
          <h2 className="font-serif text-3xl font-medium text-charcoal dark:text-cream flex items-center space-x-2">
            <Target className="w-7 h-7 text-lavender" />
            <span>Vision Target Board</span>
          </h2>
          <p className="text-xs text-charcoal/60 dark:text-[#E9DCCF]/65 mt-1">
            Map out long-term SMART metrics and record milestones for private growth
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        {/* Left Column: Seed Objective Form */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-[#201D24] p-6 border border-soft-beige/35 dark:border-white/5 rounded-3xl shadow-xs">
            <h3 className="font-serif text-base font-semibold text-charcoal dark:text-cream mb-4 flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-lavender animate-pulse" />
              <span>Compose Target Capsule</span>
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5 font-bold">
                  Target Name
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Master Three Advanced UI Blueprints"
                  className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl px-4 py-3 border border-soft-beige/40 dark:border-white/10 focus:border-lavender focus:outline-hidden font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                    Category Sphere
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl p-3 border border-soft-beige/40 dark:border-white/10 dark:text-cream font-semibold cursor-pointer"
                  >
                    <option value="Creator">🎨 Creator</option>
                    <option value="Academics">📚 Academics</option>
                    <option value="Finance">🏛️ Ledger</option>
                    <option value="Ritual">💆 Ritual</option>
                    <option value="Nomad">✈️ Nomad</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                    Target Horizon Date
                  </label>
                  <input
                    type="date"
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                    className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl px-4 py-3 border border-soft-beige/45 dark:border-white/10 focus:border-lavender focus:outline-hidden font-semibold cursor-pointer"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                  Vision Board Reference Image URL (Optional)
                </label>
                <input
                  type="url"
                  value={visionImage}
                  onChange={(e) => setVisionImage(e.target.value)}
                  placeholder="https://images.unsplash.com/photo-example..."
                  className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl px-4 py-3 border border-soft-beige/45 dark:border-white/10 focus:border-lavender focus:outline-hidden font-semibold"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                  Supplemental Description / Core Vision
                </label>
                <textarea
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  placeholder="Outline the qualitative feeling of completing this goal..."
                  rows={3}
                  className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl p-4 border border-soft-beige/45 dark:border-white/10 focus:border-lavender focus:outline-hidden resize-none leading-relaxed font-semibold font-serif"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                  Action Checklist Milestones (One per line)
                </label>
                <textarea
                  value={milestonesText}
                  onChange={(e) => setMilestonesText(e.target.value)}
                  placeholder="e.g. Sketch layouts
Review motion variables
Build code logic deck"
                  rows={4}
                  className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl p-4 border border-soft-beige/45 dark:border-white/10 focus:border-lavender focus:outline-hidden resize-none leading-relaxed font-semibold"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-charcoal dark:bg-lavender text-cream dark:text-white text-xs font-semibold hover:opacity-90 transition-all flex items-center justify-center space-x-1.5 shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Seed Objective</span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Active Targets Details list */}
        <div className="lg:col-span-3 space-y-6">
          <div className="bg-white dark:bg-[#201D24] p-6 border border-soft-beige/35 dark:border-white/5 rounded-3xl shadow-xs">
            <h3 className="font-serif text-base font-semibold text-charcoal dark:text-cream mb-4">Seeded Objectives</h3>

            {isLoading ? (
              <div className="space-y-4 py-8">
                {[1, 2].map((ind) => (
                  <div key={ind} className="h-44 w-full bg-cream/15 dark:bg-white/5 animate-pulse rounded-2xl border border-soft-beige/10" />
                ))}
              </div>
            ) : goals.length === 0 ? (
              <div className="text-center py-24 text-charcoal/40 dark:text-cream/40">
                <Target className="w-12 h-12 mx-auto opacity-35 mb-3" />
                <p className="font-serif italic text-sm">Vision Board sits blank.</p>
              </div>
            ) : (
              <div className="space-y-6 max-h-[600px] overflow-y-auto pr-1">
                <AnimatePresence initial={false}>
                  {goals.map((goal, ind) => {
                    const completedMilestones = goal.milestones.filter((m) => m.completed).length;
                    const pct = goal.milestones.length > 0 ? Math.round((completedMilestones / goal.milestones.length) * 100) : 0;
                    return (
                      <motion.div
                        key={goal.id}
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ duration: 0.28, delay: ind * 0.05 }}
                        className="border border-soft-beige/30 dark:border-white/5 rounded-2xl overflow-hidden hover:border-lavender/35 group relative bg-white dark:bg-[#201D24]"
                      >
                        {/* Optional Vision Board image reference card */}
                        {goal.visionBoardImage && (
                          <div className="h-28 w-full overflow-hidden relative">
                            <img
                              src={goal.visionBoardImage}
                              alt="Vision Board Capsule"
                              className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute inset-0 bg-linear-to-t from-[#201D24] to-transparent opacity-65" />
                          </div>
                        )}

                        <div className="p-5 space-y-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <span className="text-[9px] bg-lavender/10 text-dusty-lilac px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">{goal.category}</span>
                              <h4 className="font-serif text-[14px] font-bold text-charcoal dark:text-cream mt-1.5">{goal.title}</h4>
                            </div>

                            <button
                              onClick={() => {
                                onDeleteGoal(goal.id);
                                showToast?.('Goal capsule erased.', 'info');
                              }}
                              className="p-1 hover:bg-neutral-50 dark:hover:bg-[#2F2B35] text-charcoal/20 hover:text-red-650 rounded-lg cursor-pointer opacity-0 group-hover:opacity-100 transition-colors"
                              title="Delete goal"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {goal.description && (
                            <p className="text-xs text-charcoal/70 dark:text-[#E9DCCF]/70 font-serif leading-relaxed italic border-l-2 border-lavender/35 pl-3">
                              "{goal.description}"
                            </p>
                          )}

                          {/* Progress indicators */}
                          <div className="space-y-1.5 pt-1">
                            <div className="flex justify-between text-[10px] font-bold text-charcoal/50 dark:text-[#E9DCCF]/50 uppercase tracking-widest leading-none">
                              <span>Milestone Completion Progress</span>
                              <span>{pct}%</span>
                            </div>
                            <div className="w-full bg-[#E9DCCF]/35 rounded-full h-1.5 overflow-hidden">
                              <div
                                className="bg-lavender h-full rounded-full transition-all duration-300"
                                style={{ width: `${pct}%` }}
                              />
                            </div>
                          </div>

                          {/* Action milestones list checkboxes */}
                          {goal.milestones.length > 0 && (
                            <div className="space-y-2 pt-2 border-t border-cream dark:border-white/5">
                              {goal.milestones.map((ms) => (
                                <button
                                  key={ms.id}
                                  onClick={() => {
                                    onToggleMilestone(goal.id, ms.id);
                                    showToast?.(
                                      ms.completed
                                        ? 'Milestone returned to active review status.'
                                        : 'Aesthetic target milestone checked out!',
                                      'success'
                                    );
                                  }}
                                  className="w-full flex items-center space-x-3 text-left p-2 rounded-xl border border-soft-beige/15 hover:bg-neutral-50/50 dark:hover:bg-neutral-900 transition-all cursor-pointer"
                                >
                                  {ms.completed ? (
                                    <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                                  ) : (
                                    <Square className="w-4 h-4 text-charcoal/30 shrink-0 hover:scale-110 active:scale-90" />
                                  )}
                                  <span className={`text-[11px] font-semibold leading-relaxed ${ms.completed ? 'line-through text-charcoal/40 dark:text-cream/30' : 'text-charcoal/80 dark:text-cream/80'}`}>
                                    {ms.text}
                                  </span>
                                </button>
                              ))}
                            </div>
                          )}

                          {/* Target Horizon slot */}
                          <div className="flex items-center space-x-1 text-[9px] text-charcoal/40 dark:text-cream/40 font-bold uppercase tracking-wider pt-2 border-t border-cream dark:border-white/5">
                            <Calendar className="w-3 h-3 text-lavender" />
                            <span>Target Horizon: {goal.targetDate}</span>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
