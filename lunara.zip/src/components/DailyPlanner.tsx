import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Calendar,
  Trash2,
  CheckCircle2,
  Circle,
  Plus,
  Sparkles,
  BookOpen,
  Clock,
  ChevronRight,
  ChevronLeft,
} from 'lucide-react';
import { Task, PriorityType } from '../types';

interface DailyPlannerProps {
  tasks: Task[];
  onAddTask: (task: Omit<Task, 'id'>) => void;
  onToggleTask: (id: string) => void;
  onDeleteTask: (id: string) => void;
  selectedDate: string;
  onChangeDate: (date: string) => void;
  showToast?: (text: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
}

export default function DailyPlanner({
  tasks,
  onAddTask,
  onToggleTask,
  onDeleteTask,
  selectedDate,
  onChangeDate,
  showToast,
}: DailyPlannerProps) {
  // Task input states
  const [text, setText] = useState('');
  const [priority, setPriority] = useState<PriorityType>('medium');
  const [timeSlot, setTimeSlot] = useState('');
  const [note, setNote] = useState('');
  const [category, setCategory] = useState('Creator');
  const [isLoading, setIsLoading] = useState(true);

  // Briefly mock layout state for elegant skeletons
  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 450);
    return () => clearTimeout(timer);
  }, [selectedDate]);

  const filteredTasks = tasks.filter((task) => task.date === selectedDate);
  const completedCount = filteredTasks.filter((t) => t.completed).length;
  const progressPercent = filteredTasks.length > 0 ? Math.round((completedCount / filteredTasks.length) * 100) : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;

    onAddTask({
      text: text.trim(),
      completed: false,
      priority,
      timeSlot: timeSlot || undefined,
      note: note || undefined,
      date: selectedDate,
      category,
    });

    // Reset inputs
    setText('');
    setNote('');
    setTimeSlot('');
    showToast?.('Checkpoint added with grace.', 'success');
  };

  const shiftDate = (days: number) => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + days);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    onChangeDate(`${yyyy}-${mm}-${dd}`);
  };

  const getPriorityBadgeColor = (p: PriorityType) => {
    switch (p) {
      case 'high':
        return 'bg-red-500/10 text-red-600 border border-red-500/15';
      case 'medium':
        return 'bg-lavender/10 text-dusty-lilac border border-lavender/15';
      default:
        return 'bg-[#E9DCCF]/20 text-charcoal/60 border border-[#E9DCCF]/30';
    }
  };

  return (
    <div id="planner-page" className="space-y-6">
      {/* Exquisite Planner Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-soft-beige/30 dark:border-white/5 pb-6">
        <div>
          <h2 className="font-serif text-3xl font-medium text-charcoal dark:text-cream flex items-center space-x-2">
            <Calendar className="w-7 h-7 text-lavender" />
            <span>Daily Block Scheduler</span>
          </h2>
          <p className="text-xs text-charcoal/60 dark:text-[#E9DCCF]/65 mt-1">
            Map out linear focus streams and design precise daily milestones
          </p>
        </div>

        {/* Dynamic Navigation Toolbar */}
        <div className="flex items-center space-x-2 bg-white dark:bg-[#201D24] px-4 py-2 border border-soft-beige/35 dark:border-white/5 rounded-full shadow-2xs no-print">
          <button
            onClick={() => shiftDate(-1)}
            className="p-1 hover:bg-neutral-50 dark:hover:bg-neutral-900 rounded-lg text-charcoal/60 cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-xs font-serif italic text-charcoal dark:text-cream px-2">
            {new Date(selectedDate).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
          </span>
          <button
            onClick={() => shiftDate(1)}
            className="p-1 hover:bg-neutral-50 dark:hover:bg-neutral-900 rounded-lg text-charcoal/60 cursor-pointer"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        {/* Left Grid: Block Composer */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-[#201D24] rounded-3xl p-6 border border-soft-beige/35 dark:border-white/5 shadow-xs">
            <h3 className="font-serif text-base font-semibold text-charcoal dark:text-cream mb-4 flex items-center space-x-2">
              <Sparkles className="w-4.5 h-4.5 text-lavender animate-pulse" />
              <span>Block Composer</span>
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="dp-checkpoint-name" className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                  Checkpoint Name
                </label>
                <input
                  id="dp-checkpoint-name"
                  type="text"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="e.g. Design aesthetic landing layout details"
                  className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl px-4 py-3 border border-soft-beige/45 dark:border-white/10 focus:border-lavender focus:outline-hidden font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="dp-stream-slot" className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                    Stream Slot
                  </label>
                  <input
                    id="dp-stream-slot"
                    type="text"
                    value={timeSlot}
                    onChange={(e) => setTimeSlot(e.target.value)}
                    placeholder="e.g. 09:00 - 10:30"
                    className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl px-4 py-3 border border-soft-beige/45 dark:border-white/10 focus:border-lavender focus:outline-hidden font-medium"
                  />
                </div>

                <div>
                  <label htmlFor="dp-context-category" className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5 font-bold">
                    Context Category
                  </label>
                  <select
                    id="dp-context-category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl px-4 py-3 border border-soft-beige/45 dark:border-white/10 focus:border-lavender focus:outline-hidden font-semibold cursor-pointer"
                  >
                    <option value="Creator">🎨 Creator</option>
                    <option value="Ritual">☕ Ritual</option>
                    <option value="Academics">📚 Academics</option>
                    <option value="Ledger">💼 Ledger</option>
                    <option value="Serene">🧘 Serene</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-2 font-bold">
                  Focus Priority Tier
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['low', 'medium', 'high'] as PriorityType[]).map((p) => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setPriority(p)}
                      className={`py-2 rounded-xl border text-center text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer ${
                        priority === p
                          ? 'bg-lavender text-white border-lavender shadow-xs'
                          : 'bg-cream/20 dark:bg-white/5 border-soft-beige/30 dark:border-white/5 text-charcoal/50 dark:text-cream/40 hover:border-lavender'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label htmlFor="dp-private-scribbles" className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/50 dark:text-cream/40 mb-1.5">
                  Private Scribbles / Notes
                </label>
                <textarea
                  id="dp-private-scribbles"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Supplementary thoughts or resources link..."
                  rows={3}
                  className="w-full bg-cream/30 dark:bg-white/5 text-xs text-charcoal dark:text-cream rounded-xl p-4 border border-soft-beige/45 dark:border-white/10 focus:border-lavender focus:outline-hidden font-medium resize-none leading-relaxed"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-charcoal dark:bg-lavender text-cream dark:text-white text-xs font-semibold hover:opacity-90 transition-all flex items-center justify-center space-x-1.5 shadow-sm cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Inject Schedule Block</span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Grid: Focus Stream Board */}
        <div className="lg:col-span-3 space-y-6">
          <div className="bg-white dark:bg-[#201D24] rounded-3xl p-6 border border-soft-beige/35 dark:border-white/5 shadow-xs">
            {/* Completion Analytics banner */}
            <div className="flex items-center justify-between border-b border-soft-beige/25 dark:border-white/5 pb-4 mb-4">
              <div>
                <h3 className="font-serif text-base font-semibold text-charcoal dark:text-cream">Focus Stream</h3>
                <p className="text-[10px] text-charcoal/40 dark:text-[#E9DCCF]/40 uppercase tracking-wider font-semibold mt-0.5">
                  Checkpoint progression gauge
                </p>
              </div>

              <div className="flex items-center space-x-3.5">
                <span className="text-xs font-bold text-charcoal dark:text-cream">{progressPercent}% resolved</span>
                <div className="w-16 bg-[#E9DCCF]/35 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-lavender h-full rounded-full transition-all duration-500"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>
            </div>

            {isLoading ? (
              <div className="space-y-4 py-8">
                {[1, 2, 3].map((ind) => (
                  <div key={ind} className="h-16 w-full bg-cream/15 dark:bg-neutral-850 animate-pulse rounded-2xl border border-soft-beige/10" />
                ))}
              </div>
            ) : filteredTasks.length === 0 ? (
              <div className="py-20 text-center text-charcoal/40 dark:text-[#E9DCCF]/45">
                <BookOpen className="w-12 h-12 mx-auto opacity-35 mb-4 animate-bounce" />
                <p className="font-serif italic text-sm">Your linear calendar sits blank.</p>
                <p className="text-[10px] uppercase font-bold tracking-widest text-[#9E8AC9] mt-1.5">compose dynamic nodes above</p>
              </div>
            ) : (
              <div className="space-y-4 max-h-[550px] overflow-y-auto pr-1">
                <AnimatePresence initial={false}>
                  {filteredTasks.map((task, ind) => (
                    <motion.div
                      key={task.id}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -20, filter: 'blur(3px)' }}
                      transition={{ duration: 0.28, delay: ind * 0.05 }}
                      className="p-5 border border-soft-beige/30 dark:border-white/5 rounded-2xl bg-white dark:bg-[#201D24] shadow-2xs group flex items-start space-x-4 relative hover:border-lavender/30 transition-all"
                    >
                      {/* Checkbox trigger button */}
                      <button
                        onClick={() => {
                          onToggleTask(task.id);
                          showToast?.(task.completed ? 'Node returned to pending stream.' : 'Task completed! Keep shining.', 'success');
                        }}
                        className="mt-0.5 shrink-0 text-charcoal/30 hover:text-lavender transition-all"
                        title={task.completed ? 'Mark pending' : 'Mark complete'}
                      >
                        {task.completed ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-600 animate-pulse" />
                        ) : (
                          <Circle className="w-5 h-5 hover:scale-110 active:scale-95 duration-100" />
                        )}
                      </button>

                      {/* Content block representing task detail */}
                      <div className="flex-1 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <h4 className={`text-xs font-bold leading-relaxed ${task.completed ? 'line-through text-charcoal/40 dark:text-cream/30 font-medium' : 'text-charcoal dark:text-cream'}`}>
                            {task.text}
                          </h4>
                          <span className={`px-2 py-0.5 text-[8px] font-bold rounded-full ${getPriorityBadgeColor(task.priority)}`}>
                            {task.priority.toUpperCase()}
                          </span>
                        </div>

                        {/* Optional Sub-text info slots */}
                        {(task.timeSlot || task.category) && (
                          <div className="flex items-center space-x-3 text-[9px] text-[#9E8AC9] font-semibold tracking-wide">
                            {task.timeSlot && (
                              <span className="flex items-center space-x-1">
                                <Clock className="w-3 h-3 text-lavender" />
                                <span>{task.timeSlot}</span>
                              </span>
                            )}
                            {task.category && (
                              <span className="bg-lavender/5 px-2 py-0.5 rounded-full border border-lavender/10">
                                {task.category}
                              </span>
                            )}
                          </div>
                        )}

                        {task.note && (
                          <p className="text-[10px] text-charcoal/60 dark:text-[#E9DCCF]/60 font-serif leading-relaxed pt-1.5 border-t border-cream dark:border-white/5 whitespace-pre-wrap">
                            {task.note}
                          </p>
                        )}
                      </div>

                      {/* Tear/delete trigger */}
                      <button
                        onClick={() => {
                          onDeleteTask(task.id);
                          showToast?.('Checkpoint deleted.', 'info');
                        }}
                        className="p-1 hover:bg-neutral-50 dark:hover:bg-neutral-900 text-charcoal/20 hover:text-red-650 rounded-lg transition-all cursor-pointer opacity-0 group-hover:opacity-100 duration-150 shrink-0"
                        title="Tear task sheet"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
