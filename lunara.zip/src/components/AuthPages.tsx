import React, { useState } from 'react';
import { Mail, Lock, Sparkles, LogIn, ArrowLeft, ShieldCheck, User, RefreshCw, KeyRound, AlertTriangle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface AuthPagesProps {
  onBackToLanding: () => void;
  // onLoginSuccess is handled dynamically by our context listener in App.tsx!
}

export default function AuthPages({ onBackToLanding }: AuthPagesProps) {
  const {
    loginWithEmail,
    registerWithEmail,
    loginWithGoogle,
    resetPassword,
    error: authError,
    isFirebaseActive,
  } = useAuth();

  const [isLogin, setIsLogin] = useState(true);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  
  const [localError, setLocalError] = useState('');
  const [infoMessage, setInfoMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError('');
    setInfoMessage('');

    if (isForgotPassword) {
      if (!email) {
        setLocalError('Please insert your associated email address.');
        return;
      }
      setLoading(true);
      try {
        await resetPassword(email);
        setInfoMessage('Secure passcode retrieval link dispatched to your email.');
      } catch (err: any) {
        setLocalError(err.message || 'Error occurred during passcode recovery.');
      } finally {
        setLoading(false);
      }
      return;
    }

    if (!email || !password) {
      setLocalError('Please fill in check credentials.');
      return;
    }
    if (!isLogin && !name) {
      setLocalError('Please provide your name for workflow personalization.');
      return;
    }

    setLoading(true);
    try {
      if (isLogin) {
        await loginWithEmail(email, password);
      } else {
        await registerWithEmail(email, password, name);
      }
    } catch (err: any) {
      setLocalError(err.message || 'Handshake authorisation rejected.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLocalError('');
    setInfoMessage('');
    setLoading(true);
    try {
      await loginWithGoogle();
    } catch (err: any) {
      setLocalError(err.message || 'Google pop-up trigger was cancelled or offline.');
    } finally {
      setLoading(false);
    }
  };

  const activeError = localError || authError;

  return (
    <div className="min-h-screen bg-[#F7F3EE] flex flex-col justify-between py-12 px-6 relative selection:bg-lavender/30">
      <div className="absolute top-0 left-0 w-full h-[350px] bg-linear-to-b from-lavender/10 to-transparent pointer-events-none" />
      <div className="absolute top-1/4 right-[25%] w-72 h-72 rounded-full bg-lavender/5 blur-3xl pointer-events-none" />

      {/* Header back button */}
      <div className="max-w-md mx-auto w-full mb-6 z-10">
        <button
          onClick={onBackToLanding}
          className="inline-flex items-center space-x-2 text-xs text-charcoal/60 hover:text-charcoal transition-colors font-semibold bg-white/40 px-3.5 py-2 rounded-full border border-soft-beige/20 backdrop-blur-xs cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return Home</span>
        </button>
      </div>

      {/* Dynamic Authentication Sandboxing Widget Info Banner */}
      <div className="max-w-md mx-auto w-full mb-4 z-10">
        {!isFirebaseActive ? (
          <div className="p-4 bg-amber-500/10 border border-amber-500/20 text-[#78350F] rounded-2xl text-[11px] flex items-start space-x-3 shadow-xs">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Sandbox Mode is Currently Active</p>
              <p className="opacity-80 mt-1 leading-relaxed">
                The database has not yet been bound to an active Firebase project. You may enter any simulated account details or press 'Safe Offline Guest Mode' below to preview the application instantly!
              </p>
            </div>
          </div>
        ) : (
          <div className="p-4 bg-emerald-500/10 border border-emerald-500/25 text-[#065F46] rounded-2xl text-[11px] flex items-start space-x-3 shadow-xs">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Celestial Sync Activated</p>
              <p className="opacity-80 mt-1 leading-relaxed">
                Your application is successfully bound to Firebase. All account credentials, display profiles, and customizations route securely through the live cloud servers.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Main card */}
      <div className="max-w-md mx-auto w-full bg-white/80 backdrop-blur-md rounded-2xl p-8 border border-soft-beige/40 shadow-xl shadow-charcoal/5 z-10 my-auto">
        <div className="text-center mb-8">
          <div className="w-10 h-10 rounded-full bg-lavender flex items-center justify-center mx-auto mb-4 shadow-md shadow-lavender/10">
            <span className="font-serif text-white font-bold text-base">L</span>
          </div>
          <h2 className="font-serif text-2xl text-charcoal font-medium tracking-tight mb-2">
            {isForgotPassword
              ? 'Recover your portal'
              : isLogin
              ? 'Welcome back to Lunara'
              : 'Compose your digital shelf'}
          </h2>
          <p className="text-xs text-charcoal/50">
            {isForgotPassword
              ? 'A sanctuary link will allow password reset'
              : isLogin
              ? 'Enter your quiet focus sanctuary'
              : 'Start your soft luxury planner journey'}
          </p>
        </div>

        {activeError && (
          <div className="p-3 bg-red-400/10 border border-red-200/50 text-red-700 text-xs rounded-lg mb-6 text-center">
            {activeError}
          </div>
        )}

        {infoMessage && (
          <div className="p-3 bg-emerald-550/10 border border-emerald-200/30 text-emerald-800 text-xs rounded-lg mb-6 text-center font-medium">
            {infoMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Sign Up Name option */}
          {!isLogin && !isForgotPassword && (
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/60 mb-1.5">
                Preferred Display Name
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Marie Sterling"
                  className="w-full bg-white/60 text-xs text-charcoal rounded-xl pl-10 pr-4 py-3 border border-soft-beige/40 focus:border-lavender focus:outline-hidden transition-all text-sm"
                />
                <User className="absolute left-3.5 top-3.5 w-4 h-4 text-charcoal/30" />
              </div>
            </div>
          )}

          {/* Email Address */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/60 mb-1.5">
              Email Address / Account Node
            </label>
            <div className="relative">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. Marie@domain.com"
                className="w-full bg-white/60 text-xs text-charcoal rounded-xl pl-10 pr-4 py-3 border border-soft-beige/40 focus:border-lavender focus:outline-hidden transition-all text-sm"
              />
              <Mail className="absolute left-3.5 top-3.5 w-4 h-4 text-charcoal/30" />
            </div>
          </div>

          {/* Secret Password Passcode */}
          {!isForgotPassword && (
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-charcoal/60">
                  Secret Passcode
                </label>
                {isLogin && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsForgotPassword(true);
                      setLocalError('');
                      setInfoMessage('');
                    }}
                    className="text-[10px] text-lavender hover:underline font-bold tracking-wide"
                  >
                    Forgot passcode?
                  </button>
                )}
              </div>
              <div className="relative">
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-white/60 text-xs text-charcoal rounded-xl pl-10 pr-4 py-3 border border-soft-beige/40 focus:border-lavender focus:outline-hidden transition-all text-sm"
                />
                <Lock className="absolute left-3.5 top-3.5 w-4 h-4 text-charcoal/30" />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-4 py-3.5 rounded-xl bg-charcoal text-cream text-xs font-semibold hover:opacity-90 disabled:opacity-50 transition-all shadow-md shadow-charcoal/10 flex items-center justify-center space-x-2 cursor-pointer"
          >
            {loading ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : isForgotPassword ? (
              <KeyRound className="w-3.5 h-3.5" />
            ) : (
              <LogIn className="w-3.5 h-3.5" />
            )}
            <span>
              {loading
                ? 'Authorising secure session...'
                : isForgotPassword
                ? 'Send Secure Password Reset'
                : isLogin
                ? 'Access Sync Sanctuary'
                : 'Engrave New Account'}
            </span>
          </button>
        </form>

        {isForgotPassword ? (
          <div className="mt-6 text-center">
            <button
              onClick={() => {
                setIsForgotPassword(false);
                setLocalError('');
                setInfoMessage('');
              }}
              className="text-xs text-lavender hover:underline font-semibold focus:outline-hidden cursor-pointer flex items-center justify-center mx-auto space-x-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Authenticate login</span>
            </button>
          </div>
        ) : (
          <>
            <div className="relative my-6 flex items-center justify-center">
              <div className="w-full border-t border-soft-beige/30" />
              <span className="absolute px-3 bg-white text-[10px] text-charcoal/40 font-bold uppercase tracking-widest">
                or harmonized sync
              </span>
            </div>

            {/* Google Authentication popup and offline triggers */}
            <div className="space-y-2">
              <button
                onClick={handleGoogleLogin}
                disabled={loading}
                className="w-full py-3 rounded-xl bg-white text-charcoal hover:bg-neutral-50 border border-soft-beige/40 text-xs font-semibold transition-all flex items-center justify-center space-x-2 shadow-xs cursor-pointer"
              >
                <svg className="w-4 h-4 mr-1" viewBox="0 0 24 24">
                  <path
                    fill="#EA4335"
                    d="M12.24 10.285V14.4h6.887c-.648 2.41-2.519 4.114-5.136 4.114A5.714 5.714 0 0 1 8.24 12.8a5.714 5.714 0 0 1 5.751-5.714c1.373 0 2.624.488 3.61 1.295l3.056-3.056A9.9 9.9 0 0 0 13.991 3C8.473 3 4 7.388 4 12.8S8.473 22.6 13.991 22.6c5.752 0 10.009-3.963 10.009-9.8 0-.616-.068-1.144-.196-1.515H12.24Z"
                  />
                </svg>
                <span>Authorize Google Account</span>
              </button>
            </div>

            {/* Screen Switch button */}
            <div className="mt-6 text-center">
              <button
                onClick={() => {
                  setIsLogin(!isLogin);
                  setLocalError('');
                  setInfoMessage('');
                }}
                className="text-xs text-lavender hover:underline font-semibold focus:outline-hidden cursor-pointer"
              >
                {isLogin
                  ? "New to luxury planning? Create a companion state"
                  : 'Already have an engraving? Sync now'}
              </button>
            </div>
          </>
        )}
      </div>

      <div className="text-center text-[10px] text-charcoal/40 max-w-sm mx-auto z-10 mt-6 md:mt-12 select-none leading-relaxed">
        By continuing, you agree with Lunara's offline-secure encryption standard. Sync requires active SSL and secure cookies standard.
      </div>
    </div>
  );
}
