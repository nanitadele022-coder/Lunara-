import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  signInWithPopup,
  GoogleAuthProvider,
  sendPasswordResetEmail,
  onAuthStateChanged,
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { UserProfile } from '../types';
import firebaseConfig from '../firebase-applet-config.json';

// Detect if Firebase has been fully provisioned by the AI Studio Workspace
export const isFirebaseConfigured =
  firebaseConfig.apiKey &&
  firebaseConfig.apiKey !== 'placeholder-api-key' &&
  firebaseConfig.projectId !== 'placeholder';

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  error: string | null;
  isFirebaseActive: boolean;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (email: string, pass: string, name: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logoutUser: () => Promise<void>;
  updateProfileOnboardState: (name: string, lifestyle: string) => Promise<void>;
  updateProfileTheme: (theme: UserProfile['theme']) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => {
    // Load local cache during initial boot-up
    const cached = localStorage.getItem('lunara_profile_active');
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        return null;
      }
    }
    return null;
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Sync profile cache to localStorage
  useEffect(() => {
    if (userProfile) {
      localStorage.setItem('lunara_profile_active', JSON.stringify(userProfile));
    } else {
      localStorage.removeItem('lunara_profile_active');
    }
  }, [userProfile]);

  useEffect(() => {
    if (!isFirebaseConfigured) {
      console.log('Firebase remains in Sandbox Simulator Mode. Complete configuration in AI Studio panel.');
      setLoading(false);
      return;
    }

    // Attach native Firebase listener
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setLoading(true);
      setError(null);
      if (firebaseUser) {
        setCurrentUser(firebaseUser);
        try {
          const userDocRef = doc(db, 'users', firebaseUser.uid);
          let userSnap;
          try {
            userSnap = await getDoc(userDocRef);
          } catch (fetchErr) {
            handleFirestoreError(fetchErr, OperationType.GET, `users/${firebaseUser.uid}`);
          }

          if (userSnap && userSnap.exists()) {
            const data = userSnap.data();
            setUserProfile({
              email: firebaseUser.email || '',
              name: data.name || 'Graceful Planner',
              avatarUrl: data.avatarUrl || firebaseUser.photoURL || undefined,
              isLoggedIn: true,
              onboarded: data.onboarded !== false,
              syncEnabled: true,
              theme: data.theme || 'soft-light',
            });
          } else {
            // Document does not exist yet, construct profile from provider credentials
            const initialProfile: UserProfile = {
              email: firebaseUser.email || '',
              name: firebaseUser.displayName || 'Graceful Planner',
              avatarUrl: firebaseUser.photoURL || undefined,
              isLoggedIn: true,
              onboarded: false, // will require onboarding
              syncEnabled: true,
              theme: 'soft-light',
            };
            
            try {
              await setDoc(userDocRef, {
                email: initialProfile.email,
                name: initialProfile.name,
                avatarUrl: initialProfile.avatarUrl || null,
                onboarded: initialProfile.onboarded,
                syncEnabled: initialProfile.syncEnabled,
                theme: initialProfile.theme,
              });
            } catch (createErr) {
              handleFirestoreError(createErr, OperationType.WRITE, `users/${firebaseUser.uid}`);
            }
            
            setUserProfile(initialProfile);
          }
        } catch (err: any) {
          console.error('Error synchronizing active user profile node:', err);
          setError(err.message || 'Error occurred loading your user profile info.');
        }
      } else {
        setCurrentUser(null);
        setUserProfile(null);
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  // Sandbox Mode helper fallbacks
  const generateSandboxProfile = (email: string, name: string): UserProfile => ({
    email,
    name,
    isLoggedIn: true,
    onboarded: true,
    syncEnabled: false,
    theme: 'soft-light',
  });

  const loginWithEmail = async (email: string, pass: string) => {
    setError(null);
    setLoading(true);
    try {
      if (!isFirebaseConfigured) {
        // Handle Sandbox simulated fallback login
        const simulatedName = email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1);
        setUserProfile(generateSandboxProfile(email, simulatedName));
        setLoading(false);
        return;
      }
      await signInWithEmailAndPassword(auth, email, pass);
    } catch (err: any) {
      setError(err.message || 'Failed to authenticate securely.');
      setLoading(false);
      throw err;
    }
  };

  const registerWithEmail = async (email: string, pass: string, name: string) => {
    setError(null);
    setLoading(true);
    try {
      if (!isFirebaseConfigured) {
        // Handle Sandbox simulated register
        const simulatedProfile = generateSandboxProfile(email, name);
        simulatedProfile.onboarded = false; // direct them to Onboarding screen
        setUserProfile(simulatedProfile);
        setLoading(false);
        return;
      }
      const userCredential = await createUserWithEmailAndPassword(auth, email, pass);
      const u = userCredential.user;
      
      const userDocRef = doc(db, 'users', u.uid);
      const newProfile = {
        email,
        name,
        onboarded: false,
        syncEnabled: true,
        theme: 'soft-light',
        avatarUrl: null,
      };

      try {
        await setDoc(userDocRef, newProfile);
      } catch (writeErr) {
        handleFirestoreError(writeErr, OperationType.WRITE, `users/${u.uid}`);
      }

      setUserProfile({
        email,
        name,
        isLoggedIn: true,
        onboarded: false,
        syncEnabled: true,
        theme: 'soft-light',
      });
    } catch (err: any) {
      setError(err.message || 'Failed to create accounts registry.');
      setLoading(false);
      throw err;
    }
  };

  const loginWithGoogle = async () => {
    setError(null);
    setLoading(true);
    try {
      if (!isFirebaseConfigured) {
        // Simulated Google Account Authentication
        const simulatedProfile: UserProfile = {
          email: 'celestial.creative@lunara.private',
          name: 'Evelyn Choi',
          avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150',
          isLoggedIn: true,
          onboarded: true,
          syncEnabled: false,
          theme: 'soft-light',
        };
        setUserProfile(simulatedProfile);
        setLoading(false);
        return;
      }

      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      setError(err.message || 'Google Auth flow interrupted.');
      setLoading(false);
      throw err;
    }
  };

  const resetPassword = async (email: string) => {
    setError(null);
    try {
      if (!isFirebaseConfigured) {
        alert(`[Sandbox Simulator] Passcode recovery email dispatched to: ${email}`);
        return;
      }
      await sendPasswordResetEmail(auth, email);
    } catch (err: any) {
      setError(err.message || 'Forgot password request failed.');
      throw err;
    }
  };

  const logoutUser = async () => {
    setError(null);
    setLoading(true);
    try {
      if (isFirebaseConfigured) {
        await signOut(auth);
      }
      setCurrentUser(null);
      setUserProfile(null);
      localStorage.removeItem('lunara_profile_active');
    } catch (err: any) {
      setError(err.message || 'Session separation failed.');
    } finally {
      setLoading(false);
    }
  };

  const updateProfileOnboardState = async (name: string, lifestyle: string) => {
    if (!userProfile) return;
    const updatedProfile = { ...userProfile, name, onboarded: true };
    setUserProfile(updatedProfile);

    if (isFirebaseConfigured && currentUser) {
      try {
        const userDocRef = doc(db, 'users', currentUser.uid);
        await updateDoc(userDocRef, {
          name,
          onboarded: true,
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${currentUser.uid}`);
      }
    }
  };

  const updateProfileTheme = async (theme: UserProfile['theme']) => {
    if (!userProfile) return;
    setUserProfile({ ...userProfile, theme });

    if (isFirebaseConfigured && currentUser) {
      try {
        const userDocRef = doc(db, 'users', currentUser.uid);
        await updateDoc(userDocRef, { theme });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${currentUser.uid}`);
      }
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        loading,
        error,
        isFirebaseActive: isFirebaseConfigured,
        loginWithEmail,
        registerWithEmail,
        loginWithGoogle,
        resetPassword,
        logoutUser,
        updateProfileOnboardState,
        updateProfileTheme,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be called inside an AuthProvider scope.');
  }
  return context;
}
