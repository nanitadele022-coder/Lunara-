import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
  query,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  Task,
  Habit,
  JournalEntry,
  BudgetItem,
  SavingGoal,
  SMARTGoal,
  INITIAL_TASKS,
  INITIAL_HABITS,
  INITIAL_JOURNAL,
  INITIAL_BUDGET,
  INITIAL_SAVING_GOALS,
  INITIAL_GOALS,
} from '../types';
import { isFirebaseConfigured } from '../context/AuthContext';

// Safe check if we are allowed to use live Firestore calls
export const isSyncEnabled = (userId: string | null | undefined): boolean => {
  return !!(isFirebaseConfigured && userId);
};

// --- TASKS ---
export const syncTasks = (
  userId: string,
  onUpdate: (tasks: Task[]) => void
): (() => void) => {
  if (!isSyncEnabled(userId)) return () => {};
  
  const path = `users/${userId}/tasks`;
  const colRef = collection(db, 'users', userId, 'tasks');
  
  return onSnapshot(
    colRef,
    async (snapshot) => {
      if (snapshot.empty) {
        // First-time setup: Seed preloaded values
        try {
          // Verify it's still empty before writing to avoid race condition
          const checkSnap = await getDocs(query(colRef));
          if (checkSnap.empty) {
            for (const t of INITIAL_TASKS) {
              await setDoc(doc(db, 'users', userId, 'tasks', t.id), t);
            }
          }
        } catch (err) {
          console.warn('Silent warning during tasks seeding:', err);
        }
      } else {
        const tasks: Task[] = [];
        snapshot.forEach((doc) => {
          tasks.push(doc.data() as Task);
        });
        // Sort tasks optionally to keep consistent visual orders
        onUpdate(tasks);
      }
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    }
  );
};

export const saveTask = async (userId: string, task: Task): Promise<void> => {
  if (!isSyncEnabled(userId)) return;
  const path = `users/${userId}/tasks/${task.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'tasks', task.id), task);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
};

export const deleteTask = async (userId: string, taskId: string): Promise<void> => {
  if (!isSyncEnabled(userId)) return;
  const path = `users/${userId}/tasks/${taskId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'tasks', taskId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
};

// --- HABITS ---
export const syncHabits = (
  userId: string,
  onUpdate: (habits: Habit[]) => void
): (() => void) => {
  if (!isSyncEnabled(userId)) return () => {};

  const path = `users/${userId}/habits`;
  const colRef = collection(db, 'users', userId, 'habits');

  return onSnapshot(
    colRef,
    async (snapshot) => {
      if (snapshot.empty) {
        try {
          const checkSnap = await getDocs(query(colRef));
          if (checkSnap.empty) {
            for (const h of INITIAL_HABITS) {
              await setDoc(doc(db, 'users', userId, 'habits', h.id), h);
            }
          }
        } catch (err) {
          console.warn('Silent warning during habits seeding:', err);
        }
      } else {
        const habits: Habit[] = [];
        snapshot.forEach((doc) => {
          habits.push(doc.data() as Habit);
        });
        onUpdate(habits);
      }
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    }
  );
};

export const saveHabit = async (userId: string, habit: Habit): Promise<void> => {
  if (!isSyncEnabled(userId)) return;
  const path = `users/${userId}/habits/${habit.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'habits', habit.id), habit);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
};

export const deleteHabit = async (userId: string, habitId: string): Promise<void> => {
  if (!isSyncEnabled(userId)) return;
  const path = `users/${userId}/habits/${habitId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'habits', habitId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
};

// --- JOURNAL ---
export const syncJournals = (
  userId: string,
  onUpdate: (journals: JournalEntry[]) => void
): (() => void) => {
  if (!isSyncEnabled(userId)) return () => {};

  const path = `users/${userId}/journal`;
  const colRef = collection(db, 'users', userId, 'journal');

  return onSnapshot(
    colRef,
    async (snapshot) => {
      if (snapshot.empty) {
        try {
          const checkSnap = await getDocs(query(colRef));
          if (checkSnap.empty) {
            for (const j of INITIAL_JOURNAL) {
              await setDoc(doc(db, 'users', userId, 'journal', j.id), j);
            }
          }
        } catch (err) {
          console.warn('Silent warning during journal seeding:', err);
        }
      } else {
        const journals: JournalEntry[] = [];
        snapshot.forEach((doc) => {
          journals.push(doc.data() as JournalEntry);
        });
        onUpdate(journals);
      }
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    }
  );
};

export const saveJournal = async (userId: string, journal: JournalEntry): Promise<void> => {
  if (!isSyncEnabled(userId)) return;
  const path = `users/${userId}/journal/${journal.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'journal', journal.id), journal);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
};

export const deleteJournal = async (userId: string, journalId: string): Promise<void> => {
  if (!isSyncEnabled(userId)) return;
  const path = `users/${userId}/journal/${journalId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'journal', journalId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
};

// --- BUDGET ITEMS ---
export const syncBudgetItems = (
  userId: string,
  onUpdate: (budgetItems: BudgetItem[]) => void
): (() => void) => {
  if (!isSyncEnabled(userId)) return () => {};

  const path = `users/${userId}/budgetItems`;
  const colRef = collection(db, 'users', userId, 'budgetItems');

  return onSnapshot(
    colRef,
    async (snapshot) => {
      if (snapshot.empty) {
        try {
          const checkSnap = await getDocs(query(colRef));
          if (checkSnap.empty) {
            for (const b of INITIAL_BUDGET) {
              await setDoc(doc(db, 'users', userId, 'budgetItems', b.id), b);
            }
          }
        } catch (err) {
          console.warn('Silent warning during budget items seeding:', err);
        }
      } else {
        const budgetItems: BudgetItem[] = [];
        snapshot.forEach((doc) => {
          budgetItems.push(doc.data() as BudgetItem);
        });
        onUpdate(budgetItems);
      }
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    }
  );
};

export const saveBudgetItem = async (userId: string, item: BudgetItem): Promise<void> => {
  if (!isSyncEnabled(userId)) return;
  const path = `users/${userId}/budgetItems/${item.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'budgetItems', item.id), item);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
};

export const deleteBudgetItem = async (userId: string, itemId: string): Promise<void> => {
  if (!isSyncEnabled(userId)) return;
  const path = `users/${userId}/budgetItems/${itemId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'budgetItems', itemId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
};

// --- SAVING GOALS ---
export const syncSavingGoals = (
  userId: string,
  onUpdate: (savingGoals: SavingGoal[]) => void
): (() => void) => {
  if (!isSyncEnabled(userId)) return () => {};

  const path = `users/${userId}/savingGoals`;
  const colRef = collection(db, 'users', userId, 'savingGoals');

  return onSnapshot(
    colRef,
    async (snapshot) => {
      if (snapshot.empty) {
        try {
          const checkSnap = await getDocs(query(colRef));
          if (checkSnap.empty) {
            for (const sg of INITIAL_SAVING_GOALS) {
              await setDoc(doc(db, 'users', userId, 'savingGoals', sg.id), sg);
            }
          }
        } catch (err) {
          console.warn('Silent warning during saving goals seeding:', err);
        }
      } else {
        const savingGoals: SavingGoal[] = [];
        snapshot.forEach((doc) => {
          savingGoals.push(doc.data() as SavingGoal);
        });
        onUpdate(savingGoals);
      }
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    }
  );
};

export const saveSavingGoal = async (userId: string, goal: SavingGoal): Promise<void> => {
  if (!isSyncEnabled(userId)) return;
  const path = `users/${userId}/savingGoals/${goal.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'savingGoals', goal.id), goal);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
};

export const deleteSavingGoal = async (userId: string, goalId: string): Promise<void> => {
  if (!isSyncEnabled(userId)) return;
  const path = `users/${userId}/savingGoals/${goalId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'savingGoals', goalId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
};

// --- SMART GOALS ---
export const syncSMARTGoals = (
  userId: string,
  onUpdate: (goals: SMARTGoal[]) => void
): (() => void) => {
  if (!isSyncEnabled(userId)) return () => {};

  const path = `users/${userId}/goals`;
  const colRef = collection(db, 'users', userId, 'goals');

  return onSnapshot(
    colRef,
    async (snapshot) => {
      if (snapshot.empty) {
        try {
          const checkSnap = await getDocs(query(colRef));
          if (checkSnap.empty) {
            for (const g of INITIAL_GOALS) {
              await setDoc(doc(db, 'users', userId, 'goals', g.id), g);
            }
          }
        } catch (err) {
          console.warn('Silent warning during goals seeding:', err);
        }
      } else {
        const goals: SMARTGoal[] = [];
        snapshot.forEach((doc) => {
          goals.push(doc.data() as SMARTGoal);
        });
        onUpdate(goals);
      }
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    }
  );
};

export const saveSMARTGoal = async (userId: string, goal: SMARTGoal): Promise<void> => {
  if (!isSyncEnabled(userId)) return;
  const path = `users/${userId}/goals/${goal.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'goals', goal.id), goal);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
};

export const deleteSMARTGoal = async (userId: string, goalId: string): Promise<void> => {
  if (!isSyncEnabled(userId)) return;
  const path = `users/${userId}/goals/${goalId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'goals', goalId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
};
