/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  onboardingCompleted: boolean;
  themePreference?: 'light' | 'dark';
  createdAt?: string;
}

export type TaskPriority = 'high' | 'medium' | 'low';

export interface PlannerTask {
  id: string;
  userId: string;
  title: string;
  notes?: string;
  priority: TaskPriority;
  completed: boolean;
  date: string; // YYYY-MM-DD
  timeBlock?: string; // e.g. "09:00 - 10:30"
  createdAt?: string;
  updatedAt?: string;
}

export type HabitFrequency = 'daily' | 'weekly';

export interface Habit {
  id: string;
  userId: string;
  name: string;
  frequency: HabitFrequency;
  streak: number;
  history: string[]; // dates of completion YYYY-MM-DD
  createdAt?: string;
}

export interface BudgetItem {
  id: string;
  userId: string;
  type: 'income' | 'expense';
  amount: number;
  category: string;
  date: string; // YYYY-MM-DD
  notes?: string;
  createdAt?: string;
}

export type JournalMood = 'calm' | 'inspired' | 'focused' | 'tired' | 'anxious' | 'excited' | 'grateful';

export interface JournalEntry {
  id: string;
  userId: string;
  content: string;
  mood: JournalMood;
  prompt?: string;
  date: string; // YYYY-MM-DD
  createdAt?: string;
}

export interface Milestone {
  id: string;
  title: string;
  completed: boolean;
}

export type GoalCategory = 'career' | 'personal' | 'wellness' | 'finance' | 'creative';

export interface SMARTGoal {
  id: string;
  userId: string;
  title: string;
  description: string;
  category: GoalCategory;
  targetDate: string; // YYYY-MM-DD
  progress: number; // 0 to 100
  milestones: Milestone[];
  visionBoardUrls?: string[];
  createdAt?: string;
}
