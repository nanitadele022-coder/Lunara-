/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  deleteDoc, 
  doc 
} from 'firebase/firestore';
import { db, auth } from '../firebase';
import { JournalEntry, JournalMood } from '../types';
import { 
  Plus, 
  Trash2, 
  BookOpen, 
  Search, 
  Sparkles, 
  RefreshCw, 
  Calendar, 
  AlertCircle,
  PenTool
} from 'lucide-react';

export default function Journal() {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [content, setContent] = useState('');
  const [mood, setMood] = useState<JournalMood>('calm');
  const [searchQuery, setSearchQuery] = useState('');
  const [activePrompt, setActivePrompt] = useState('What micro goal brought you quiet focus this morning?');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const COLLECTION_PATH = 'journalEntries';

  const prompts = [
    "What micro goal brought you quiet focus this morning?",
    "Describe a small challenge and a gentle milestone configuration that eases it.",
    "Which element of nature inspired your sense of wellness today?",
    "Acknowledge three humble elements of your lifestyle that you are grateful for.",
    "Reflect on a creative project you want to nurture over the next week."
  ];

  const moodEmojis: { [key in JournalMood]: { emoji: string; color: string; label: string } } = {
    calm: { emoji: '🌸', color: 'bg-emerald-500/15 text-emerald-600', label: 'Calm' },
    inspired: { emoji: '✨', color: 'bg-lavender/30 text-lilac', label: 'Inspired' },
    focused: { emoji: '🧠', color: 'bg-indigo-500/10 text-indigo-500', label: 'Focused' },
    tired: { emoji: '💤', color: 'bg-slate-500/10 text-slate-500', label: 'Tired' },
    anxious: { emoji: '🌊', color: 'bg-blue-500/10 text-blue-500', label: 'Anxious' },
    excited: { emoji: '🌟', color: 'bg-amber-500/10 text-amber-500', label: 'Excited' },
    grateful: { emoji: '🙏', color: 'bg-pink-500/10 text-pink-500', label: 'Grateful' },
  };

  useEffect(() => {
    if (!auth.currentUser) return;
    const userId = auth.currentUser.uid;

    setIsLoading(true);
    const q = query(
      collection(db, COLLECTION_PATH),
      where('userId', '==', userId)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const records: JournalEntry[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        records.push({
          id: docSnap.id,
          userId: data.userId,
          content: data.content,
          mood: data.mood,
          prompt: data.prompt,
          date: data.date
        });
      });
      // Sort newest date first
      records.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      
      setEntries(records);
      setIsLoading(false);
    }, (err) => {
      console.error(err);
      setError('Failed to securely synchronize diary logs.');
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleRandomizePrompt = () => {
    const unfiltered = prompts.filter(p => p !== activePrompt);
    const rand = unfiltered[Math.floor(Math.random() * unfiltered.length)];
    setActivePrompt(rand);
  };

  const handleSaveEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    if (!content.trim()) return;

    try {
      const payload = {
        userId: auth.currentUser.uid,
        content: content.trim(),
        mood,
        prompt: activePrompt,
        date,
        createdAt: new Date().toISOString()
      };

      await addDoc(collection(db, COLLECTION_PATH), payload);
      
      setContent('');
      setError(null);
    } catch (err) {
      console.error(err);
      setError('Could not write journal document in cloud.');
    }
  };

  const handleDeleteEntry = async (id: string) => {
    try {
      await deleteDoc(doc(db, COLLECTION_PATH, id));
    } catch (err) {
      console.error(err);
      setError('Could not remove entry.');
    }
  };

  // Filter entry stream by search query
  const filteredEntries = entries.filter(e => {
    const q = searchQuery.toLowerCase();
    return (
      e.content.toLowerCase().includes(q) ||
      (e.prompt && e.prompt.toLowerCase().includes(q)) ||
      e.mood.toLowerCase().includes(q)
    );
  });

  return (
    <div id="journal-module" className="max-w-5xl mx-auto px-4 md:px-6 py-6 space-y-8">
      
      {/* Header Deck */}
      <div className="pb-4 border-b border-beige/35 dark:border-dark-border flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="font-serif text-3xl font-bold tracking-tight text-charcoal dark:text-white flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-lilac/10 text-lilac block">✍️</span>
            Reflective Journal
          </h1>
          <p className="text-gray-500 font-light text-sm mt-1">Settle your thoughts, select your emotional frequency, and write freely.</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        
        {/* Input Column (Left) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white/75 dark:bg-dark-panel/65 border border-beige/35 dark:border-dark-border p-6 rounded-3xl backdrop-blur-md space-y-6">
            
            {/* Prompt component */}
            <div className="p-4 bg-lavender/5 border border-lavender/35 rounded-2xl relative overflow-hidden space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-[9px] font-mono font-bold text-lilac uppercase tracking-wider flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  Mindful Prompt Guidance
                </span>
                <button
                  type="button"
                  id="btn-random-prompt"
                  onClick={handleRandomizePrompt}
                  className="text-gray-400 hover:text-lilac transition duration-150 p-1"
                  title="Randomize Intentions Prompt"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              </div>

              <p className="font-serif italic text-xs text-charcoal/85 dark:text-gray-200 leading-relaxed font-semibold">
                "{activePrompt}"
              </p>
            </div>

            <form onSubmit={handleSaveEntry} className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Select Current Mood</label>
                <div className="flex flex-wrap gap-2">
                  {(Object.keys(moodEmojis) as JournalMood[]).map((key) => {
                    const active = mood === key;
                    const meta = moodEmojis[key];
                    return (
                      <button
                        key={key}
                        id={`mood-select-${key}`}
                        type="button"
                        onClick={() => setMood(key)}
                        className={`px-3 py-2 text-xs rounded-xl border flex items-center gap-1.5 transition ${
                          active 
                            ? `${meta.color} border-lilac/60 font-semibold shadow-inner` 
                            : 'bg-white/40 dark:bg-dark-bg/40 border-beige/30 text-gray-500 hover:bg-beige/10'
                        }`}
                      >
                        <span>{meta.emoji}</span>
                        <span>{meta.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2 space-y-1.5">
                  <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Date Logged</label>
                  <input
                    id="journal-date-input"
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-4 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none bg-white dark:bg-dark-bg text-charcoal dark:text-white"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Diary Content</label>
                <textarea
                  id="journal-content-textarea"
                  required
                  rows={6}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Record your experiences, breathing pace, and plans..."
                  className="w-full px-4 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-lilac bg-white dark:bg-dark-bg text-charcoal dark:text-white leading-relaxed font-serif"
                />
              </div>

              <button
                id="journal-submit-btn"
                type="submit"
                className="w-full py-3.5 px-4 bg-charcoal text-white dark:bg-white dark:text-charcoal rounded-xl text-xs font-mono font-bold uppercase tracking-wide hover:opacity-90 transition shadow flex items-center justify-center gap-1.5"
              >
                <PenTool className="w-3.5 h-3.5" />
                Commit to Diary
              </button>
            </form>
          </div>
        </div>

        {/* List Entries (Right) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Search bar */}
          <div className="relative rounded-2xl shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              id="journal-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search past logs, moods, or prompt targets..."
              className="block w-full pl-10 pr-4 py-3 bg-white/70 dark:bg-dark-panel border border-beige/45 dark:border-dark-border rounded-2xl text-xs focus:outline-none focus:ring-1 focus:ring-lilac text-charcoal dark:text-white placeholder-gray-400"
            />
          </div>

          {/* List entries layout */}
          <div className="space-y-4 max-h-[580px] overflow-y-auto pr-1">
            {isLoading ? (
              <div className="text-center py-12 text-sm text-gray-400 italic">Unlocking cloud diary...</div>
            ) : filteredEntries.length === 0 ? (
              <div className="p-12 text-center rounded-3xl border border-dashed border-beige/35 bg-white/20">
                <p className="text-gray-400 text-sm font-light italic">No matching journal logs found.</p>
                <p className="text-[10px] text-gray-400 font-mono mt-1">Clean slate. Write down a new entry.</p>
              </div>
            ) : (
              filteredEntries.map((entry) => {
                const meta = moodEmojis[entry.mood];
                return (
                  <div 
                    key={entry.id}
                    className="bg-white dark:bg-dark-panel border border-beige/35 dark:border-dark-border rounded-3xl p-6 shadow-sm space-y-4"
                  >
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{meta.emoji}</span>
                        <div>
                          <span className="text-xs font-bold text-charcoal dark:text-white capitalize">{meta.label} Mood</span>
                          <span className="text-[9px] font-mono text-gray-400 block mt-0.5">{entry.date}</span>
                        </div>
                      </div>

                      <button
                        id={`journal-delete-${entry.id}`}
                        onClick={() => handleDeleteEntry(entry.id)}
                        className="text-gray-300 hover:text-red-500 p-1.5 transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {entry.prompt && (
                      <div className="p-3 bg-beige/10 dark:bg-dark-bg/60 border-l-2 border-lavender rounded-r-xl">
                        <p className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">PROMPT SOURCE</p>
                        <p className="text-xs text-charcoal/80 dark:text-gray-300 font-light italic font-serif leading-relaxed mt-0.5">"{entry.prompt}"</p>
                      </div>
                    )}

                    <p className="text-xs md:text-sm text-charcoal/90 dark:text-gray-200 font-serif leading-relaxed whitespace-pre-wrap font-light p-1">
                      {entry.content}
                    </p>
                  </div>
                );
              })
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
