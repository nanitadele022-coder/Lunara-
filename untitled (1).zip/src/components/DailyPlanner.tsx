/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  Timestamp 
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { PlannerTask, TaskPriority } from '../types';
import { 
  Plus, 
  Check, 
  Trash2, 
  Clock, 
  Calendar, 
  Flag, 
  AlertCircle, 
  CheckSquare, 
  Square,
  Sparkles
} from 'lucide-react';

export default function DailyPlanner() {
  const [tasks, setTasks] = useState<PlannerTask[]>([]);
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [timeBlock, setTimeBlock] = useState('');
  const [notes, setNotes] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Firestore path
  const COLLECTION_PATH = 'tasks';

  useEffect(() => {
    if (!auth.currentUser) return;
    const userId = auth.currentUser.uid;
    
    setIsLoading(true);
    const q = query(
      collection(db, COLLECTION_PATH), 
      where('userId', '==', userId)
    );

    // Set up Real-time Synchronized Listener
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items: PlannerTask[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        items.push({
          id: docSnap.id,
          userId: data.userId,
          title: data.title,
          notes: data.notes,
          priority: data.priority,
          completed: data.completed,
          date: data.date,
          timeBlock: data.timeBlock,
          createdAt: data.createdAt,
          updatedAt: data.updatedAt
        });
      });

      // Sort: Completed tasks to bottom, sort uncompleted by priority & date
      const sorted = items.sort((a, b) => {
        if (a.completed !== b.completed) return a.completed ? 1 : -1;
        const priomap = { high: 0, medium: 1, low: 2 };
        return priomap[a.priority] - priomap[b.priority];
      });

      setTasks(sorted);
      setIsLoading(false);
    }, (err) => {
      console.error(err);
      setError('A secure data fetch issue occurred. Real-time updates paused.');
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleAddTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    if (!title.trim()) return;

    try {
      const payload = {
        userId: auth.currentUser.uid,
        title: title.trim(),
        notes: notes.trim() || undefined,
        priority,
        completed: false,
        date,
        timeBlock: timeBlock.trim() || undefined,
        createdAt: new Date().toISOString()
      };

      await addDoc(collection(db, COLLECTION_PATH), payload);
      
      // Clean form inputs
      setTitle('');
      setTimeBlock('');
      setNotes('');
      setError(null);
    } catch (err) {
      console.error(err);
      setError('Failed to securely register your task in cloud.');
    }
  };

  const handleToggleTask = async (task: PlannerTask) => {
    try {
      const docRef = doc(db, COLLECTION_PATH, task.id);
      await updateDoc(docRef, {
        completed: !task.completed,
        updatedAt: new Date().toISOString()
      });
    } catch (err) {
      console.error(err);
      setError('Failed to update task completion.');
    }
  };

  const handleDeleteTask = async (id: string) => {
    try {
      await deleteDoc(doc(db, COLLECTION_PATH, id));
    } catch (err) {
      console.error(err);
      setError('Failed to delete transaction log.');
    }
  };

  // Stats
  const selectedDayTasks = tasks.filter(t => t.date === date);
  const totalCount = selectedDayTasks.length;
  const completedCount = selectedDayTasks.filter(t => t.completed).length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return (
    <div id="planner-module" className="max-w-5xl mx-auto px-4 md:px-6 py-6 space-y-8">
      
      {/* Header Deck */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-4 border-b border-beige/35 dark:border-dark-border">
        <div>
          <h1 className="font-serif text-3xl font-bold tracking-tight text-charcoal dark:text-white flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-lilac/10 text-lilac block">📅</span>
            Digital Scheduler
          </h1>
          <p className="text-gray-500 font-light text-sm mt-1">Plan your day-to-day focus points with luxury absolute parameters.</p>
        </div>

        {/* Date Selector */}
        <div className="flex items-center gap-2.5 bg-white/75 dark:bg-dark-panel p-2 rounded-2xl border border-beige/45 dark:border-dark-border shadow-sm">
          <Calendar className="w-4 h-4 text-lilac" />
          <input
            id="planner-date-input"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="text-xs font-mono font-medium focus:outline-none bg-transparent"
          />
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-600 dark:text-red-400 text-xs font-medium flex items-center gap-2">
          <AlertCircle className="w-4 h-4" />
          <span>{error}</span>
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-8">
        
        {/* Form Column */}
        <div className="lg:col-span-1">
          <div className="bg-white/75 dark:bg-dark-panel/65 border border-beige/35 dark:border-dark-border p-6 rounded-3xl backdrop-blur-md space-y-6">
            <h2 className="font-serif text-xl font-bold text-charcoal dark:text-white flex items-center gap-1.5">
              <Sparkles className="w-4.5 h-4.5 text-lilac" />
              Manifest Intention
            </h2>

            <form onSubmit={handleAddTask} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Activity Title</label>
                <input
                  id="task-form-title"
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Wellness Meditation Session"
                  className="w-full px-4 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-lilac/45 bg-white dark:bg-dark-bg text-charcoal dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Time Block</label>
                  <div className="relative">
                    <Clock className="w-3.5 h-3.5 text-lilac absolute left-3 top-3.5" />
                    <input
                      id="task-form-time"
                      type="text"
                      value={timeBlock}
                      onChange={(e) => setTimeBlock(e.target.value)}
                      placeholder="e.g. 08:00 - 08:30"
                      className="w-full pl-9 pr-3 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-lilac/45 bg-white dark:bg-dark-bg text-charcoal dark:text-white"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Priority Level</label>
                  <div className="relative">
                    <Flag className="w-3.5 h-3.5 text-lilac absolute left-3 top-3.5 pointer-events-none" />
                    <select
                      id="task-form-priority"
                      value={priority}
                      onChange={(e) => setPriority(e.target.value as TaskPriority)}
                      className="w-full pl-9 pr-3 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-lilac/45 bg-white dark:bg-dark-bg text-charcoal dark:text-white appearance-none"
                    >
                      <option value="high">High priority</option>
                      <option value="medium">Medium priority</option>
                      <option value="low">Low priority</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Aesthetic Notes</label>
                <textarea
                  id="task-form-notes"
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Focus on absolute breathing control..."
                  className="w-full px-4 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-lilac/45 bg-white dark:bg-dark-bg text-charcoal dark:text-white"
                />
              </div>

              <button
                id="task-form-submit"
                type="submit"
                className="w-full py-3 px-4 bg-charcoal text-white dark:bg-white dark:text-charcoal rounded-xl text-xs font-mono font-bold uppercase tracking-wide shadow hover:translate-y-[-0.5px] transition flex items-center justify-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Daily Step
              </button>
            </form>
          </div>
        </div>

        {/* Live List Column */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Daily Status Card */}
          <div className="p-5 rounded-3xl bg-white/60 dark:bg-dark-panel/40 border border-beige/45 dark:border-dark-border block flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <p className="text-xs font-mono font-bold text-lilac uppercase tracking-wider">HARMONY METRIC FOR {date}</p>
              <h3 className="font-serif text-2xl font-bold mt-1 text-charcoal dark:text-white">
                {totalCount === 0 
                  ? "A serene clean slate today" 
                  : progressPercent === 100 
                    ? "Peak harmony attained!" 
                    : `${completedCount} of ${totalCount} steps finalized`}
              </h3>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="relative w-14 h-14 rounded-full border-4 border-beige/25 flex items-center justify-center">
                <span className="text-xs font-mono font-bold text-lilac">{progressPercent}%</span>
                {/* Visual Circle Meter */}
                <div 
                  className="absolute inset-[-4px] rounded-full border-4 border-lilac transition duration-500" 
                  style={{ clipPath: `polygon(0 0, 100% 0, 100% 100%, 0 ${progressPercent}%)`, opacity: progressPercent > 0 ? 0.8 : 0 }}
                ></div>
              </div>
            </div>
          </div>

          {/* Core Tasks Flow */}
          <div className="space-y-3">
            {isLoading ? (
              <div className="text-center py-12 text-sm text-gray-400 font-light italic">Refining sync nodes...</div>
            ) : selectedDayTasks.length === 0 ? (
              <div className="p-12 text-center rounded-3xl border-2 border-dashed border-beige/35 dark:border-dark-border/40 bg-white/20">
                <p className="text-gray-400 text-sm font-light italic">No planner tasks registered for this date.</p>
                <p className="text-[11px] text-gray-400 font-mono mt-1">Set actions to build daily structures.</p>
              </div>
            ) : (
              <AnimatePresence>
                {selectedDayTasks.map((t) => (
                  <motion.div
                    key={t.id}
                    layoutId={t.id}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className={`p-4 rounded-2xl border transition-all flex items-start justify-between gap-4 ${
                      t.completed 
                        ? 'bg-beige/10 dark:bg-dark-bg/40 border-beige/20 opacity-60' 
                        : 'bg-white dark:bg-dark-panel border-beige/35 dark:border-dark-border shadow-sm'
                    }`}
                  >
                    <div className="flex gap-3.5 items-start">
                      <button
                        id={`task-toggle-${t.id}`}
                        onClick={() => handleToggleTask(t)}
                        className="mt-1 text-lilac hover:opacity-80 transition"
                      >
                        {t.completed 
                          ? <CheckSquare className="w-5.5 h-5.5 fill-lavender/30" /> 
                          : <Square className="w-5.5 h-5.5" />
                        }
                      </button>
                      
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className={`text-sm font-semibold transition ${
                            t.completed 
                              ? 'line-through text-gray-400' 
                              : 'text-charcoal dark:text-white'
                          }`}>
                            {t.title}
                          </h4>
                          <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase ${
                            t.priority === 'high' 
                              ? 'bg-red-500/10 text-red-600' 
                              : t.priority === 'medium'
                                ? 'bg-amber-500/10 text-amber-600'
                                : 'bg-slate-500/10 text-slate-500'
                          }`}>
                            {t.priority}
                          </span>
                        </div>

                        {t.timeBlock && (
                          <div className="flex items-center gap-1.5 text-[10px] text-gray-400 font-mono mt-1">
                            <Clock className="w-3 h-3 text-lilac" />
                            <span>{t.timeBlock}</span>
                          </div>
                        )}

                        {t.notes && (
                          <p className="text-xs text-gray-500 font-light leading-relaxed mt-2 italic bg-beige/15 dark:bg-dark-bg/30 p-2.5 rounded-xl border border-beige/15 dark:border-dark-border/40">
                            {t.notes}
                          </p>
                        )}
                      </div>
                    </div>

                    <button
                      id={`task-delete-${t.id}`}
                      onClick={() => handleDeleteTask(t.id)}
                      className="text-gray-400 hover:text-red-500 p-1.5 rounded-lg transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
