/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, addDoc, updateDoc, doc } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { PlannerTask, Habit, BudgetItem } from '../types';
import { 
  Sparkles, 
  Calendar, 
  CheckSquare, 
  Square, 
  TrendingUp, 
  Flame, 
  Plus, 
  Clock, 
  PlusCircle,
  TrendingDown,
  Compass,
  DollarSign,
  Check
} from 'lucide-react';

interface DashboardProps {
  onNavClick: (tab: 'planner' | 'habits' | 'budget' | 'journal' | 'goals' | 'settings') => void;
  userIntention: string;
}

export default function Dashboard({ onNavClick, userIntention }: DashboardProps) {
  const [tasks, setTasks] = useState<PlannerTask[]>([]);
  const [habits, setHabits] = useState<Habit[]>([]);
  const [budgets, setBudgets] = useState<BudgetItem[]>([]);
  
  // Quick task input
  const [quickTitle, setQuickTitle] = useState('');
  const [quickPriority, setQuickPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [isAddingTask, setIsAddingTask] = useState(false);

  // Motivational quote picker
  const quotes = [
    { text: "Simplicity is the ultimate sophistication.", author: "Leonardo da Vinci" },
    { text: "He who has a why to live for can bear almost any how.", author: "Friedrich Nietzsche" },
    { text: "Concentrate every minute like a Roman and a man on doing what's in front of you.", author: "Marcus Aurelius" },
    { text: "The soul is dyed the color of its thoughts.", author: "Marcus Aurelius" },
    { text: "Nature does not hurry, yet everything is accomplished.", author: "Lao Tzu" }
  ];

  const [activeQuote, setActiveQuote] = useState({ text: '', author: '' });

  const todayStr = new Date().toISOString().split('T')[0];

  useEffect(() => {
    // Pick daily quote on Mount
    const rand = quotes[Math.floor(Math.random() * quotes.length)];
    setActiveQuote(rand);
  }, []);

  // Sync tasks, habits & budget lists concurrently
  useEffect(() => {
    if (!auth.currentUser) return;
    const userId = auth.currentUser.uid;

    const tasksQuery = query(collection(db, 'tasks'), where('userId', '==', userId));
    const tasksUnsubscribe = onSnapshot(tasksQuery, (snap) => {
      const list: PlannerTask[] = [];
      snap.forEach(d => list.push({ id: d.id, ...d.data() } as any));
      setTasks(list.filter(t => t.date === todayStr));
    });

    const habitsQuery = query(collection(db, 'habits'), where('userId', '==', userId));
    const habitsUnsubscribe = onSnapshot(habitsQuery, (snap) => {
      const list: Habit[] = [];
      snap.forEach(d => list.push({ id: d.id, ...d.data() } as any));
      setHabits(list); // Get all active habits
    });

    const budgetsQuery = query(collection(db, 'budgets'), where('userId', '==', userId));
    const budgetsUnsubscribe = onSnapshot(budgetsQuery, (snap) => {
      const list: BudgetItem[] = [];
      snap.forEach(d => list.push({ id: d.id, ...d.data() } as any));
      setBudgets(list);
    });

    return () => {
      tasksUnsubscribe();
      habitsUnsubscribe();
      budgetsUnsubscribe();
    };
  }, []);

  // Time-based greeting generator
  const getGreeting = () => {
    const hours = new Date().getHours();
    if (hours < 12) return 'Good Morning';
    if (hours < 18) return 'Good Afternoon';
    return 'Good Evening';
  };

  // Quick Scheduler tasks toggle
  const handleToggleTask = async (task: PlannerTask) => {
    try {
      await updateDoc(doc(db, 'tasks', task.id), {
        completed: !task.completed,
        updatedAt: new Date().toISOString()
      });
    } catch (err) {
      console.error(err);
    }
  };

  // Quick Habit Toggler
  const handleToggleHabit = async (habit: Habit) => {
    try {
      const isDone = habit.history.includes(todayStr);
      let updatedHistory: string[];

      if (isDone) {
        updatedHistory = habit.history.filter(d => d !== todayStr);
      } else {
        updatedHistory = [...habit.history, todayStr];
      }

      // Quick streak recounter
      let streak = habit.streak;
      if (!isDone) {
        // If successfully toggled true today, check if yesterday was also completed to increment
        streak++;
      } else {
        streak = Math.max(0, streak - 1);
      }

      await updateDoc(doc(db, 'habits', habit.id), {
        history: updatedHistory,
        streak
      });
    } catch (err) {
      console.error(err);
    }
  };

  // Quick Add Task form helper
  const handleQuickAddTaskSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser || !quickTitle.trim()) return;

    try {
      await addDoc(collection(db, 'tasks'), {
        userId: auth.currentUser.uid,
        title: quickTitle.trim(),
        completed: false,
        priority: quickPriority,
        date: todayStr,
        createdAt: new Date().toISOString()
      });
      setQuickTitle('');
      setIsAddingTask(false);
    } catch (err) {
      console.error(err);
    }
  };

  // Calculations
  const tasksCompleted = tasks.filter(t => t.completed).length;
  const totalTasks = tasks.length;
  const taskProgress = totalTasks > 0 ? Math.round((tasksCompleted / totalTasks) * 100) : 0;

  const totalIncome = budgets.filter(b => b.type === 'income').reduce((sum, b) => sum + b.amount, 0);
  const totalExpense = budgets.filter(b => b.type === 'expense').reduce((sum, b) => sum + b.amount, 0);
  const netBalance = totalIncome - totalExpense;

  const peakStreak = habits.length > 0 ? Math.max(...habits.map(h => h.streak), 0) : 0;

  return (
    <div id="dashboard-view" className="max-w-6xl mx-auto px-4 md:px-6 py-6 space-y-8">
      
      {/* 1. Greeting Card banner */}
      <div className="p-6 md:p-8 rounded-3xl bg-charcoal text-white dark:bg-dark-panel border border-neutral-800 relative overflow-hidden shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-3 relative z-10">
          <span className="text-[10px] font-mono font-bold tracking-widest text-[#B79CED] uppercase bg-white/5 border border-white/10 px-3 py-1 rounded-full">
            ✨ Intended Frequency: {userIntention || 'Flow'}
          </span>
          <h1 className="font-serif text-3xl md:text-5xl font-semibold tracking-tight">
            {getGreeting()}, <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-lavender to-violet-300">
              {auth.currentUser?.displayName || 'Aesthetic Achiever'}
            </span>
          </h1>
          <p className="text-gray-400 font-serif italic font-light text-sm text-balance max-w-lg leading-relaxed">
            "{activeQuote.text}" — {activeQuote.author}
          </p>
        </div>

        {/* Mini Calendar block on greeting */}
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md text-center shrink-0 w-32 relative z-10">
          <span className="text-[10px] font-mono uppercase tracking-widest text-lavender font-bold">TODAY</span>
          <p className="font-serif text-4xl font-black text-white mt-1">
            {new Date().getDate()}
          </p>
          <p className="text-[10px] font-mono text-gray-400 mt-1 uppercase">
            {new Date().toLocaleDateString('en-US', { month: 'short', weekday: 'short' })}
          </p>
        </div>

        {/* Ambient subtle background glow */}
        <div className="absolute top-[-50%] right-[-10%] w-[400px] h-[350px] rounded-full bg-lavender/10 blur-[100px] pointer-events-none"></div>
      </div>

      {/* 2. Key Stats Grid */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        
        {/* Stat: Tasks completion */}
        <div className="p-5 rounded-2xl border border-beige/40 dark:border-dark-border bg-white dark:bg-dark-panel flex items-center gap-4">
          <div className="w-11 h-11 rounded-xl bg-lilac/10 text-lilac flex items-center justify-center">
            <CheckSquare className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-[9px] font-mono font-bold uppercase text-gray-400 tracking-wider">Today's Schedule Progress</p>
            <h4 className="font-serif text-xl font-bold mt-0.5">{taskProgress}% Completed</h4>
            <p className="text-[10px] text-gray-400 font-mono mt-0.5">{tasksCompleted} of {totalTasks} steps</p>
          </div>
        </div>

        {/* Stat: Max streak */}
        <div className="p-5 rounded-2xl border border-beige/40 dark:border-dark-border bg-white dark:bg-dark-panel flex items-center gap-4">
          <div className="w-11 h-11 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
            <Flame className="w-5.5 h-5.5 fill-amber-500 text-amber-500" />
          </div>
          <div>
            <p className="text-[9px] font-mono font-bold uppercase text-gray-400 tracking-wider">Peak Habit Streak</p>
            <h4 className="font-serif text-xl font-bold mt-0.5">{peakStreak} Days Active</h4>
            <p className="text-[10px] text-gray-400 font-mono mt-0.5">Continuous routine locks</p>
          </div>
        </div>

        {/* Stat: Wealth balance */}
        <div className="p-5 rounded-2xl border border-beige/40 dark:border-dark-border bg-white dark:bg-dark-panel flex items-center gap-4">
          <div className="w-11 h-11 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center">
            <TrendingUp className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-[9px] font-mono font-bold uppercase text-gray-400 tracking-wider">Net Wallet Ledger</p>
            <h4 className={`font-serif text-xl font-bold mt-0.5 ${netBalance >= 0 ? 'text-charcoal dark:text-white' : 'text-red-500'}`}>
              ${netBalance.toFixed(2)}
            </h4>
            <p className="text-[10px] text-gray-400 font-mono mt-0.5">Total registered flows</p>
          </div>
        </div>

      </section>

      {/* 3. Scheduler Deck and Habit Checklist */}
      <div className="grid lg:grid-cols-2 gap-8">
        
        {/* Today's schedule preview widget with Quick Add task */}
        <div className="bg-white/75 dark:bg-dark-panel/65 border border-beige/35 dark:border-dark-border rounded-3xl p-6 backdrop-blur-md flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <span className="text-[10px] font-mono font-bold text-lilac uppercase tracking-wider block">CHRONOLOGICAL GRID</span>
                <h3 className="font-serif text-xl font-bold text-charcoal dark:text-white">Today's Focus Tasks</h3>
              </div>

              {!isAddingTask && (
                <button
                  id="btn-quick-add-task-open"
                  onClick={() => setIsAddingTask(true)}
                  className="p-2 bg-lavender/20 hover:bg-lavender/30 text-lilac rounded-xl flex items-center gap-1 text-[11px] font-mono font-bold leading-none transition"
                >
                  <Plus className="w-3.5 h-3.5" /> Quick Task
                </button>
              )}
            </div>

            {/* Quick Add Inline Form */}
            {isAddingTask && (
              <form onSubmit={handleQuickAddTaskSubmit} className="p-4 bg-beige/10 dark:bg-dark-bg/60 border border-beige/35 dark:border-dark-border rounded-2xl space-y-3">
                <input
                  id="quick-task-title-input"
                  type="text"
                  required
                  value={quickTitle}
                  onChange={(e) => setQuickTitle(e.target.value)}
                  placeholder="Task title e.g. Sketch landing mockup"
                  className="w-full px-3.5 py-2.5 border border-beige/35 dark:border-dark-border rounded-xl text-xs focus:outline-none bg-white dark:bg-dark-panel text-charcoal dark:text-white"
                />

                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] font-mono font-semibold uppercase text-gray-400">Select priority:</span>
                    <div className="flex gap-1.5">
                      {['high', 'medium', 'low'].map(p => (
                        <button
                          key={p}
                          type="button"
                          id={`quick-prio-btn-${p}`}
                          onClick={() => setQuickPriority(p as any)}
                          className={`px-2 py-1 rounded text-[9px] font-mono uppercase font-bold text-xs ${
                            quickPriority === p 
                              ? 'bg-lilac text-white' 
                              : 'bg-beige/25 text-gray-400 hover:bg-beige/50'
                          }`}
                        >
                          {p}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      id="btn-quick-add-cancel"
                      onClick={() => setIsAddingTask(false)}
                      className="text-xs text-gray-400 hover:text-lilac px-2"
                    >
                      Cancel
                    </button>
                    <button
                      id="btn-quick-add-submit"
                      type="submit"
                      className="px-3.5 py-2 bg-charcoal text-white dark:bg-white dark:text-charcoal rounded-lg text-xs font-mono font-bold uppercase tracking-wider"
                    >
                      Log Step
                    </button>
                  </div>
                </div>
              </form>
            )}

            {/* Daily tasks feed list */}
            <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
              {tasks.length === 0 ? (
                <div className="py-12 text-center border border-dashed border-beige/30 rounded-2xl">
                  <p className="text-gray-400 text-sm font-light italic">Calendar schedules clean today.</p>
                  <p className="text-[10px] text-gray-400 font-mono mt-1">Add tasks to set structures.</p>
                </div>
              ) : (
                tasks.map((t) => (
                  <div 
                    key={t.id} 
                    className={`p-3 rounded-xl border flex items-center justify-between gap-4 transition-all ${
                      t.completed 
                        ? 'bg-beige/10 dark:bg-dark-bg/20 border-beige/10 opacity-55' 
                        : 'bg-white dark:bg-dark-panel border-beige/30 dark:border-dark-border shadow-sm'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <button
                        id={`dash-task-toggle-${t.id}`}
                        onClick={() => handleToggleTask(t)}
                        className="text-lilac hover:opacity-85"
                      >
                        {t.completed 
                          ? <CheckSquare className="w-5 h-5 fill-lavender/30" /> 
                          : <Square className="w-5 h-5" />
                        }
                      </button>

                      <div>
                        <span className={`text-xs font-semibold ${t.completed ? 'line-through text-gray-400' : 'text-charcoal dark:text-white'}`}>
                          {t.title}
                        </span>
                        {t.timeBlock && (
                          <span className="text-[9px] font-mono text-gray-400 block mt-0.5">{t.timeBlock}</span>
                        )}
                      </div>
                    </div>

                    <span className={`px-2 py-0.5 rounded text-[8px] font-mono font-bold uppercase ${
                      t.priority === 'high' 
                        ? 'bg-red-500/10 text-red-600' 
                        : t.priority === 'medium'
                          ? 'bg-amber-500/10 text-amber-600'
                          : 'bg-slate-500/10 text-slate-500'
                    }`}>
                      {t.priority}
                    </span>
                  </div>
                ))
              )}
            </div>

          </div>

          <button
            id="dash-nav-to-planner"
            onClick={() => onNavClick('planner')}
            className="w-full text-center py-2.5 bg-beige/15 hover:bg-beige/25 border border-beige/30 dark:border-dark-border rounded-xl text-xs font-mono font-bold text-gray-500 uppercase tracking-wider block"
          >
            Manage Daily Scheduler Details
          </button>
        </div>

        {/* 4. Habits Quick Tick Widget list */}
        <div className="bg-white/75 dark:bg-dark-panel/65 border border-beige/35 dark:border-dark-border rounded-3xl p-6 backdrop-blur-md flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div>
              <span className="text-[10px] font-mono font-bold text-lilac uppercase tracking-wider block">DAILY INTEGRATIONS</span>
              <h3 className="font-serif text-xl font-bold text-charcoal dark:text-white">Active Habit Streaks Grid</h3>
            </div>

            <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
              {habits.length === 0 ? (
                <div className="py-12 text-center border border-dashed border-beige/30 rounded-2xl">
                  <p className="text-gray-400 text-sm font-light italic">No habit streak configurations active.</p>
                  <p className="text-[10px] text-gray-400 font-mono mt-1">Initiate tracking in the Habits tab.</p>
                </div>
              ) : (
                habits.map((h) => {
                  const isDoneToday = h.history.includes(todayStr);
                  return (
                    <div 
                      key={h.id} 
                      className="p-3.5 bg-white dark:bg-dark-panel border border-beige/30 dark:border-dark-border rounded-xl flex items-center justify-between gap-4 shadow-sm"
                    >
                      <div className="flex items-center gap-3">
                        <button
                          id={`dash-habit-toggle-${h.id}`}
                          onClick={() => handleToggleHabit(h)}
                          className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                            isDoneToday 
                              ? 'bg-lilac border-lilac text-white scale-105 shadow-inner' 
                              : 'border-beige hover:border-lilac/50'
                          }`}
                        >
                          {isDoneToday && <Check className="w-3.5 h-3.5" />}
                        </button>

                        <div>
                          <span className={`text-xs font-semibold ${isDoneToday ? 'text-gray-400 line-through' : 'text-charcoal dark:text-white'}`}>
                            {h.name}
                          </span>
                          <span className="text-[9px] font-mono text-gray-400 block mt-0.5 uppercase tracking-wider">Routine: {h.frequency}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 text-[10px] font-mono font-bold text-amber-600 bg-amber-500/10 px-2 py-1 rounded-full">
                        <Flame className="w-3 h-3 fill-amber-500 text-amber-500" />
                        <span>{h.streak} Days</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <button
            id="dash-nav-to-habits"
            onClick={() => onNavClick('habits')}
            className="w-full text-center py-2.5 bg-beige/15 hover:bg-beige/25 border border-beige/30 dark:border-dark-border rounded-xl text-xs font-mono font-bold text-gray-500 uppercase tracking-wider block"
          >
            Refine Routine Streaks
          </button>
        </div>

      </div>

    </div>
  );
}
