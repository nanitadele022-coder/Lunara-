/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc 
} from 'firebase/firestore';
import { db, auth } from '../firebase';
import { SMARTGoal, Milestone, GoalCategory } from '../types';
import { 
  Plus, 
  Check, 
  Trash2, 
  Target, 
  CheckSquare, 
  Square, 
  Calendar, 
  PlusCircle, 
  Sparkles, 
  AlertCircle,
  Image as ImageIcon
} from 'lucide-react';

export default function GoalTracker() {
  const [goals, setGoals] = useState<SMARTGoal[]>([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<GoalCategory>('personal');
  const [targetDate, setTargetDate] = useState(() => new Date().toISOString().split('T')[0]);
  
  // Milestones input builder
  const [milestoneInputs, setMilestoneInputs] = useState<string[]>(['', '']);
  // Vision board custom picture
  const [imgUrl, setImgUrl] = useState('');
  
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const COLLECTION_PATH = 'goals';

  const defaultAestheticPhotos = {
    career: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=600",
    personal: "https://images.unsplash.com/photo-1490730141103-6cac27aaab94?auto=format&fit=crop&q=80&w=600",
    wellness: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&q=80&w=600",
    finance: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&q=80&w=600",
    creative: "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?auto=format&fit=crop&q=80&w=600"
  };

  useEffect(() => {
    if (!auth.currentUser) return;
    const userId = auth.currentUser.uid;

    setIsLoading(true);
    const q = query(
      collection(db, COLLECTION_PATH),
      where('userId', '==', userId)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const records: SMARTGoal[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        records.push({
          id: docSnap.id,
          userId: data.userId,
          title: data.title,
          description: data.description,
          category: data.category,
          targetDate: data.targetDate,
          progress: data.progress || 0,
          milestones: data.milestones || [],
          visionBoardUrls: data.visionBoardUrls || []
        });
      });
      setGoals(records);
      setIsLoading(false);
    }, (err) => {
      console.error(err);
      setError('Secure SMART Goals Sync issue. Records offline.');
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleAddMilestoneField = () => {
    setMilestoneInputs([...milestoneInputs, '']);
  };

  const handleMilestoneValueChange = (index: number, val: string) => {
    const updated = [...milestoneInputs];
    updated[index] = val;
    setMilestoneInputs(updated);
  };

  const handleAddGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    if (!title.trim()) return;

    try {
      // Filter out empty milestones
      const milestones: Milestone[] = milestoneInputs
        .filter(m => m.trim() !== '')
        .map((m, i) => ({
          id: `m-${Date.now()}-${i}`,
          title: m.trim(),
          completed: false
        }));

      // Vision Board URL fallback
      const photo = imgUrl.trim() || defaultAestheticPhotos[category];

      const payload = {
        userId: auth.currentUser.uid,
        title: title.trim(),
        description: description.trim(),
        category,
        targetDate,
        progress: 0,
        milestones,
        visionBoardUrls: [photo],
        createdAt: new Date().toISOString()
      };

      await addDoc(collection(db, COLLECTION_PATH), payload);
      
      // Clean inputs
      setTitle('');
      setDescription('');
      setMilestoneInputs(['', '']);
      setImgUrl('');
      setError(null);
    } catch (err) {
      console.error(err);
      setError('Could not register SMART Goal package.');
    }
  };

  const handleToggleMilestone = async (goal: SMARTGoal, milestoneId: string) => {
    try {
      const updatedMilestones = goal.milestones.map((m) => {
        if (m.id === milestoneId) {
          return { ...m, completed: !m.completed };
        }
        return m;
      });

      const completedCount = updatedMilestones.filter(m => m.completed).length;
      const progress = updatedMilestones.length > 0 
        ? Math.round((completedCount / updatedMilestones.length) * 100) 
        : 0;

      await updateDoc(doc(db, COLLECTION_PATH, goal.id), {
        milestones: updatedMilestones,
        progress
      });
    } catch (err) {
      console.error(err);
      setError('Failed to toggle milestone state.');
    }
  };

  const handleDeleteGoal = async (id: string) => {
    try {
      await deleteDoc(doc(db, COLLECTION_PATH, id));
    } catch (err) {
      console.error(err);
      setError('Failed to discard goal.');
    }
  };

  return (
    <div id="goals-module" className="max-w-5xl mx-auto px-4 md:px-6 py-6 space-y-8">
      
      {/* Header Deck */}
      <div className="pb-4 border-b border-beige/35 dark:border-dark-border flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="font-serif text-3xl font-bold tracking-tight text-charcoal dark:text-white flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-lilac/10 text-lilac block">🎯</span>
            SMART Goal Sanctuary
          </h1>
          <p className="text-gray-500 font-light text-sm mt-1">Deconstruct monumental aspirations into structured, bite-size daily milestones.</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        
        {/* Form Panel (Left) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white/75 dark:bg-dark-panel/65 border border-beige/35 dark:border-dark-border p-6 rounded-3xl backdrop-blur-md">
            <h2 className="font-serif text-xl font-bold mb-4 text-charcoal dark:text-white flex items-center gap-1.5">
              <PlusCircle className="w-4.5 h-4.5 text-lilac" />
              Formulate SMART Goal
            </h2>

            <form onSubmit={handleAddGoal} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Goal Vision title</label>
                <input
                  id="goal-form-title"
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Design Creative Brand Identity"
                  className="w-full px-4 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-lilac bg-white dark:bg-dark-bg text-charcoal dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Class Category</label>
                  <select
                    id="goal-form-category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value as GoalCategory)}
                    className="w-full px-3 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none bg-white dark:bg-dark-bg text-charcoal dark:text-white"
                  >
                    <option value="career">💻 Career</option>
                    <option value="personal">👨‍👩‍👧 Personal</option>
                    <option value="wellness">🌿 Wellness</option>
                    <option value="finance">💰 Finance</option>
                    <option value="creative">🎨 Creative</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Target Date</label>
                  <input
                    id="goal-form-date"
                    type="date"
                    required
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                    className="w-full px-4 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs bg-white dark:bg-dark-bg text-charcoal dark:text-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Description / Details</label>
                <textarea
                  id="goal-form-desc"
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Establish the premium color palette and guidelines..."
                  className="w-full px-4 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-lilac bg-white dark:bg-dark-bg text-charcoal dark:text-white"
                />
              </div>

              {/* Milestones dynamic list inputs */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Milestones Checklist</label>
                  <button
                    type="button"
                    onClick={handleAddMilestoneField}
                    className="text-[10px] text-lilac flex items-center gap-0.5 hover:underline"
                  >
                    <Plus className="w-3 h-3" /> Add milestone
                  </button>
                </div>
                
                <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                  {milestoneInputs.map((m, index) => (
                    <input
                      key={index}
                      id={`milestone-input-${index}`}
                      type="text"
                      value={m}
                      onChange={(e) => handleMilestoneValueChange(index, e.target.value)}
                      placeholder={`Milestone step #${index + 1}`}
                      className="w-full px-3 py-2 border border-beige/40 dark:border-dark-border rounded-lg text-xs focus:outline-none bg-white dark:bg-dark-bg text-charcoal"
                    />
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Aesthetic Vision Photo URL (Optional)</label>
                <div className="relative">
                  <ImageIcon className="w-3.5 h-3.5 text-lilac absolute left-3 top-3.5" />
                  <input
                    id="goal-form-img"
                    type="text"
                    value={imgUrl}
                    onChange={(e) => setImgUrl(e.target.value)}
                    placeholder="https://images.unsplash.com/..."
                    className="w-full pl-9 pr-3 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none bg-white dark:bg-dark-bg text-charcoal dark:text-white"
                  />
                </div>
              </div>

              <button
                id="goal-form-submit"
                type="submit"
                className="w-full py-3.5 px-4 bg-charcoal text-white dark:bg-white dark:text-charcoal rounded-xl text-xs font-mono font-bold uppercase tracking-wide hover:opacity-90 transition shadow flex items-center justify-center gap-1.5"
              >
                Launch SMART Goal
              </button>
            </form>
          </div>
        </div>

        {/* Live List Section (Right) */}
        <div className="lg:col-span-8">
          
          <div className="grid md:grid-cols-2 gap-6">
            {isLoading ? (
              <div className="col-span-2 text-center py-12 text-sm text-gray-400 italic">Translating dream boards...</div>
            ) : goals.length === 0 ? (
              <div className="col-span-2 p-12 text-center rounded-3xl border-2 border-dashed border-beige/35 dark:border-dark-border/40 bg-white/20">
                <p className="text-gray-400 text-sm font-light italic">Sanctuary goals empty.</p>
                <p className="text-[10px] text-gray-400 font-mono mt-1">Formulate a goal vector to track milestones.</p>
              </div>
            ) : (
              goals.map((g) => (
                <div 
                  key={g.id} 
                  className="bg-white dark:bg-dark-panel border border-beige/35 dark:border-dark-border rounded-3xl overflow-hidden shadow-sm flex flex-col justify-between"
                >
                  
                  {/* Photo cover (Vision Board Card) */}
                  {g.visionBoardUrls && g.visionBoardUrls.length > 0 && (
                    <div className="h-32 w-full overflow-hidden relative">
                      <img 
                        src={g.visionBoardUrls[0]} 
                        alt="Goal vision board context photo" 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover select-none"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
                        <span className="text-[9px] font-mono font-bold uppercase tracking-widest text-[#B79CED] bg-black/40 px-2 py-0.5 rounded backdrop-blur-md">
                          {g.category}
                        </span>
                      </div>
                    </div>
                  )}

                  <div className="p-5 space-y-4 flex-grow flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start gap-4">
                        <h4 className="font-semibold text-charcoal dark:text-white text-base leading-tight">{g.title}</h4>
                        <button
                          id={`goal-delete-${g.id}`}
                          onClick={() => handleDeleteGoal(g.id)}
                          className="text-gray-300 hover:text-red-500 transition px-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <p className="text-xs text-slate-500 font-light mt-1.5 leading-relaxed">{g.description}</p>
                    </div>

                    {/* Milestones Checklist panel */}
                    {g.milestones.length > 0 && (
                      <div className="space-y-2 pt-3 border-t border-beige/15 dark:border-dark-border">
                        <span className="text-[9px] font-mono font-bold text-gray-400 tracking-wider block uppercase">Sub Milestones</span>
                        <div className="space-y-1.5 max-h-24 overflow-y-auto">
                          {g.milestones.map((m) => (
                            <button
                              key={m.id}
                              id={`goal-${g.id}-toggle-m-${m.id}`}
                              onClick={() => handleToggleMilestone(g, m.id)}
                              className="w-full text-left flex items-center gap-2 text-xs text-slate-600 hover:opacity-85 transition p-1"
                            >
                              {m.completed 
                                ? <CheckSquare className="w-4 h-4 text-lilac flex-shrink-0" /> 
                                : <Square className="w-4 h-4 text-gray-300 flex-shrink-0" />
                              }
                              <span className={m.completed ? 'line-through text-gray-400' : 'text-charcoal dark:text-gray-200'}>
                                {m.title}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Progress details */}
                    <div className="space-y-1.5 pt-3 border-t border-beige/10">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-400 font-mono flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          Due {g.targetDate}
                        </span>
                        <span className="text-lilac font-bold font-mono">{g.progress}% Complete</span>
                      </div>
                      <div className="w-full bg-beige/15 rounded-full h-2">
                        <div className="bg-lilac h-2 rounded-full transition-all duration-300" style={{ width: `${g.progress}%` }}></div>
                      </div>
                    </div>

                  </div>

                </div>
              ))
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
