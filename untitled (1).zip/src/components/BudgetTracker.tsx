/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  deleteDoc, 
  doc 
} from 'firebase/firestore';
import { db, auth } from '../firebase';
import { BudgetItem } from '../types';
import { 
  Plus, 
  Trash2, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  PieChart, 
  PlusCircle, 
  MinusCircle, 
  Sparkles, 
  Info,
  ChevronDown
} from 'lucide-react';

export default function BudgetTracker() {
  const [items, setItems] = useState<BudgetItem[]>([]);
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('Housing');
  const [notes, setNotes] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [savingsGoal, setSavingsGoal] = useState('1000');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const COLLECTION_PATH = 'budgets';

  const expenseCategories = ['Housing', 'Food', 'Leisure', 'Business', 'Investment', 'Utilities', 'Wellness'];
  const incomeCategories = ['Freelance', 'Salary', 'Investment Return', 'Gifts', 'Business Sales'];

  useEffect(() => {
    if (!auth.currentUser) return;
    const userId = auth.currentUser.uid;

    setIsLoading(true);
    const q = query(
      collection(db, COLLECTION_PATH),
      where('userId', '==', userId)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const records: BudgetItem[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        records.push({
          id: docSnap.id,
          userId: data.userId,
          type: data.type,
          amount: Number(data.amount) || 0,
          category: data.category,
          date: data.date,
          notes: data.notes
        });
      });
      
      // Sort by date (newest first)
      records.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      
      setItems(records);
      setIsLoading(false);
    }, (err) => {
      console.error(err);
      setError('A secure data fetch issue occurred. Financial sync paused.');
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleLogTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    
    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('Please specify a positive numeric value.');
      return;
    }

    try {
      const payload = {
        userId: auth.currentUser.uid,
        type,
        amount: parsedAmount,
        category,
        date,
        notes: notes.trim() || undefined,
        createdAt: new Date().toISOString()
      };

      await addDoc(collection(db, COLLECTION_PATH), payload);
      
      setAmount('');
      setNotes('');
      setError(null);
    } catch (err) {
      console.error(err);
      setError('Failed to securely register dynamic ledger item.');
    }
  };

  const handleDeleteItem = async (id: string) => {
    try {
      await deleteDoc(doc(db, COLLECTION_PATH, id));
    } catch (err) {
      console.error(err);
      setError('Failed to delete transaction log.');
    }
  };

  // Calculations
  const totalIncome = items
    .filter(i => i.type === 'income')
    .reduce((sum, i) => sum + i.amount, 0);

  const totalExpense = items
    .filter(i => i.type === 'expense')
    .reduce((sum, i) => sum + i.amount, 0);

  const netBalance = totalIncome - totalExpense;
  const parsedGoal = parseFloat(savingsGoal) || 0;
  const savingsProgress = parsedGoal > 0 ? Math.min(Math.round((Math.max(0, netBalance) / parsedGoal) * 100), 100) : 0;

  // Category breakdown for expenses
  const getCategoryBreakdown = () => {
    const map: { [cat: string]: number } = {};
    items.filter(i => i.type === 'expense').forEach(i => {
      map[i.category] = (map[i.category] || 0) + i.amount;
    });

    return Object.keys(map).map(cat => ({
      category: cat,
      amount: map[cat],
      percentage: totalExpense > 0 ? Math.round((map[cat] / totalExpense) * 100) : 0
    })).sort((a, b) => b.amount - a.amount);
  };

  const breakdown = getCategoryBreakdown();

  return (
    <div id="budget-module" className="max-w-5xl mx-auto px-4 md:px-6 py-6 space-y-8">
      
      {/* Header Deck */}
      <div className="pb-4 border-b border-beige/35 dark:border-dark-border flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="font-serif text-3xl font-bold tracking-tight text-charcoal dark:text-white flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-lilac/10 text-lilac block">🧮</span>
            Wealth Ledger
          </h1>
          <p className="text-gray-500 font-light text-sm mt-1">Nurture financial stability and observe conscious outlays.</p>
        </div>
      </div>

      {/* Cards deck (Totalizers) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <div className="p-6 rounded-3xl bg-white dark:bg-dark-panel border border-beige/40 dark:border-dark-border shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">Total Income</p>
            <h3 className="font-serif text-2xl font-bold text-charcoal dark:text-white mt-0.5">${totalIncome.toFixed(2)}</h3>
          </div>
        </div>

        <div className="p-6 rounded-3xl bg-white dark:bg-dark-panel border border-beige/40 dark:border-dark-border shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-red-500/10 text-red-600 flex items-center justify-center">
            <TrendingDown className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">Total Expenses</p>
            <h3 className="font-serif text-2xl font-bold text-charcoal dark:text-white mt-0.5">${totalExpense.toFixed(2)}</h3>
          </div>
        </div>

        <div className="p-6 rounded-3xl bg-white dark:bg-dark-panel border border-beige/40 dark:border-dark-border shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-lavender/20 text-lilac flex items-center justify-center">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">Net Balance</p>
            <h3 className={`font-serif text-2xl font-bold mt-0.5 ${netBalance >= 0 ? 'text-charcoal dark:text-white' : 'text-red-500'}`}>
              ${netBalance.toFixed(2)}
            </h3>
          </div>
        </div>

      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        
        {/* Form Panel Column */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white/75 dark:bg-dark-panel/65 border border-beige/35 dark:border-dark-border p-6 rounded-3xl backdrop-blur-md">
            <h2 className="font-serif text-xl font-bold mb-4 text-charcoal dark:text-white flex items-center gap-1.5 font-serif">
              <PlusCircle className="w-4.5 h-4.5 text-lilac" />
              Log Transaction
            </h2>

            <form onSubmit={handleLogTransaction} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Transaction Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setType('expense');
                      setCategory('Housing');
                    }}
                    className={`p-2.5 rounded-xl text-xs font-semibold border text-center transition ${
                      type === 'expense'
                        ? 'bg-lavender/10 text-lilac border-lavender/50'
                        : 'bg-white/40 dark:bg-dark-panel/20 border-beige/30'
                    }`}
                  >
                    Expense
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setType('income');
                      setCategory('Freelance');
                    }}
                    className={`p-2.5 rounded-xl text-xs font-semibold border text-center transition ${
                      type === 'income'
                        ? 'bg-lavender/10 text-lilac border-lavender/50'
                        : 'bg-white/40 dark:bg-dark-panel/20 border-beige/30'
                    }`}
                  >
                    Income
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Amount ($)</label>
                  <input
                    id="budget-amount-input"
                    type="number"
                    step="0.01"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="e.g. 45.50"
                    className="w-full px-4 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-lilac bg-white dark:bg-dark-bg text-charcoal dark:text-white"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Class Category</label>
                  <div className="relative">
                    <select
                      id="budget-category-select"
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full pl-4 pr-7 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none bg-white dark:bg-dark-bg text-charcoal dark:text-white appearance-none"
                    >
                      {type === 'expense' 
                        ? expenseCategories.map(c => <option key={c} value={c}>{c}</option>)
                        : incomeCategories.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                    <ChevronDown className="w-3.5 h-3.5 text-gray-400 absolute right-3 top-4 pointer-events-none" />
                  </div>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Date Logged</label>
                <input
                  id="budget-date-input"
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-4 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none bg-white dark:bg-dark-bg text-charcoal dark:text-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Description Notes</label>
                <input
                  id="budget-notes-input"
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Lavender coffee beans"
                  className="w-full px-4 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-lilac bg-white dark:bg-dark-bg text-charcoal dark:text-white"
                />
              </div>

              <button
                id="budget-form-submit"
                type="submit"
                className="w-full py-3.5 px-4 bg-charcoal text-white dark:bg-white dark:text-charcoal rounded-xl text-xs font-mono font-bold uppercase tracking-wide hover:opacity-90 transition shadow flex items-center justify-center gap-1.5"
              >
                Assemble Record
              </button>
            </form>
          </div>

          {/* Goal Tracker */}
          <div className="p-6 rounded-3xl bg-white/75 dark:bg-dark-panel/65 border border-beige/35 dark:border-dark-border backdrop-blur-md space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-serif text-lg font-bold text-charcoal dark:text-white flex items-center gap-2">
                <Sparkles className="w-4.5 h-4.5 text-lilac" />
                Savings Intention
              </h3>
            </div>
            
            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-[10px] font-mono text-gray-400 uppercase font-black">Monthly Target ($)</label>
                <input
                  id="budget-savings-goal-input"
                  type="number"
                  value={savingsGoal}
                  onChange={(e) => setSavingsGoal(e.target.value)}
                  className="w-full px-4 py-2 bg-beige/10 dark:bg-dark-bg border border-beige/30 dark:border-dark-border rounded-xl text-xs text-charcoal dark:text-white font-mono"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-gray-400">Savings Rate Progress</span>
                  <span className="text-lilac font-bold">{savingsProgress}%</span>
                </div>
                <div className="w-full bg-beige/15 rounded-full h-2">
                  <div className="bg-lilac h-2 rounded-full transition-all duration-500" style={{ width: `${savingsProgress}%` }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Ledger & Chart List Column */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Analytics progress bar stack */}
          {breakdown.length > 0 && (
            <div className="p-6 rounded-3xl bg-white dark:bg-dark-panel border border-beige/35 dark:border-dark-border shadow-sm space-y-4">
              <h3 className="font-serif text-lg font-bold text-charcoal dark:text-white flex items-center gap-2">
                <PieChart className="w-5 h-5 text-lilac" />
                Category Expense Analytics
              </h3>

              <div className="space-y-3">
                {breakdown.map((b) => (
                  <div key={b.category} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium text-charcoal dark:text-white">{b.category}</span>
                      <span className="text-gray-400 font-mono">${b.amount.toFixed(2)} ({b.percentage}%)</span>
                    </div>
                    <div className="w-full bg-beige/15 rounded-full h-1.5">
                      <div className="bg-lilac h-1.5 rounded-full" style={{ width: `${b.percentage}%` }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Ledger logs */}
          <div className="space-y-3">
            <h3 className="font-serif text-lg font-bold text-gray-500">Transaction History</h3>

            <div className="space-y-2 max-h-[450px] overflow-y-auto pr-1">
              {isLoading ? (
                <div className="text-center py-8 text-sm text-gray-400 italic">Reading financial syncs...</div>
              ) : items.length === 0 ? (
                <div className="p-8 text-center rounded-3xl border border-beige/30 bg-white/20">
                  <p className="text-gray-400 text-sm font-light italic">Ledger ledger empty.</p>
                </div>
              ) : (
                items.map((it) => (
                  <div 
                    key={it.id} 
                    className="p-4 bg-white dark:bg-dark-panel border border-beige/35 dark:border-dark-border rounded-2xl flex items-center justify-between gap-4 shadow-sm"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center border font-serif ${
                        it.type === 'income' 
                          ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-600' 
                          : 'bg-red-500/10 border-red-500/20 text-red-600'
                      }`}>
                        {it.type === 'income' ? '+' : '-'}
                      </div>
                      
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-charcoal dark:text-white">{it.notes || it.category}</h4>
                          <span className="px-2 py-0.5 rounded-full bg-beige/30 dark:bg-dark-bg text-[9px] font-mono text-gray-400 uppercase tracking-widest">{it.category}</span>
                        </div>
                        <p className="text-[10px] text-gray-400 font-mono mt-0.5">{it.date}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <span className={`text-sm font-bold font-mono ${
                        it.type === 'income' ? 'text-emerald-600' : 'text-slate-600 dark:text-gray-200'
                      }`}>
                        {it.type === 'income' ? '+' : '-'}${it.amount.toFixed(2)}
                      </span>

                      <button
                        id={`budget-delete-${it.id}`}
                        onClick={() => handleDeleteItem(it.id)}
                        className="text-gray-300 hover:text-red-500 p-1 rounded-lg transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
