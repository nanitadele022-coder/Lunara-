/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  auth 
} from '../firebase';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  sendPasswordResetEmail 
} from 'firebase/auth';
import { 
  Sparkles, 
  Mail, 
  Lock, 
  ArrowLeft, 
  Eye, 
  EyeOff, 
  AlertCircle, 
  Info 
} from 'lucide-react';

interface AuthProps {
  onBack: () => void;
  onAuthSuccess: () => void;
}

export default function Auth({ onBack, onAuthSuccess }: AuthProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [infoMessage, setInfoMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const cleanInputs = () => {
    setEmail('');
    setPassword('');
    setError(null);
    setInfoMessage(null);
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setIsLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      // Enforce custom behavior: prefer signInWithPopup in preview environments
      await signInWithPopup(auth, provider);
      onAuthSuccess();
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Failed code connection with Google.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmailAction = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfoMessage(null);

    if (!email || !password) {
      setError('Please provide both administrative fields.');
      return;
    }

    setIsLoading(true);
    try {
      if (isSignUp) {
        await createUserWithEmailAndPassword(auth, email, password);
        setInfoMessage('Account registered successfully! Welcome to Lunara.');
        setTimeout(() => onAuthSuccess(), 1200);
      } else {
        await signInWithEmailAndPassword(auth, email, password);
        onAuthSuccess();
      }
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/operation-not-allowed') {
        setError('Email/Password provider is not enabled by default in your Firebase project. Please enable it in your Firebase Authentication console, or sign in using the Google Sign-In button.');
      } else {
        setError(err?.message || 'Auth action failed. Check credentials.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfoMessage(null);

    if (!email) {
      setError('E-mail address is required to reset passwords.');
      return;
    }

    setIsLoading(true);
    try {
      await sendPasswordResetEmail(auth, email);
      setInfoMessage('A luxury password recovery dispatch was sent to your email.');
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Failed to dispatch resetting instructions.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div id="auth-view" className="min-h-screen bg-warm-white dark:bg-dark-bg text-charcoal dark:text-gray-100 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden">
      
      {/* Absolute calming floating blobs */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute top-1/4 left-[-10%] w-[500px] h-[500px] rounded-full bg-lavender/15 dark:bg-lavender/5 blur-[120px] animate-float"></div>
        <div className="absolute bottom-1/4 right-[-10%] w-[450px] h-[450px] rounded-full bg-lilac/15 dark:bg-lilac/5 blur-[120px] animate-float" style={{ animationDelay: '3s' }}></div>
      </div>

      <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10">
        <button
          id="btn-auth-back"
          onClick={onBack}
          className="mx-auto flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-mono font-bold tracking-wider uppercase text-gray-400 hover:text-lilac transition duration-200 mb-8"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to Sanctuary
        </button>

        <div className="flex justify-center items-center gap-2 mb-2">
          <div className="w-10 h-10 rounded-xl bg-lavender/20 flex items-center justify-center border border-lavender/40">
            <Sparkles className="w-5.5 h-5.5 text-lilac" />
          </div>
          <span className="font-serif text-3xl font-bold text-charcoal dark:text-white">Lunara</span>
        </div>
        <p className="text-center text-sm font-light text-gray-500 mb-8">
          {isForgotPassword 
            ? 'Restore harmony to your access keys' 
            : isSignUp 
              ? 'Nurture your potential, secure your space' 
              : 'Log in to your private productivity sanctuary'}
        </p>
      </div>

      <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10 px-4">
        <div className="bg-white/75 dark:bg-dark-panel/65 border border-beige/45 dark:border-dark-border py-8 px-6 shadow-xl rounded-3xl sm:px-10 backdrop-blur-md">
          
          {error && (
            <div id="auth-error-card" className="mb-5 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-600 dark:text-red-400 text-xs font-medium flex items-start gap-2.5 leading-relaxed">
              <AlertCircle className="w-4.5 h-4.5 flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {infoMessage && (
            <div id="auth-info-card" className="mb-5 p-4 rounded-xl bg-lilac/10 border border-lavender/30 text-lilac dark:text-lavender text-xs font-medium flex items-start gap-2.5 leading-relaxed">
              <Info className="w-4.5 h-4.5 flex-shrink-0 mt-0.5" />
              <span>{infoMessage}</span>
            </div>
          )}

          {!isForgotPassword ? (
            <div className="space-y-6">
              {/* Primary Google Login Button */}
              <button
                id="btn-auth-google"
                onClick={handleGoogleSignIn}
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-3 px-5 py-3.5 border border-beige/60 dark:border-dark-border bg-white dark:bg-dark-bg hover:bg-beige/10 dark:hover:bg-dark-bg/60 rounded-xl font-medium text-sm transition-all shadow-sm duration-200"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="#EA4335"
                    d="M12.24 10.285V14.4h6.887c-.275 1.565-1.88 4.604-6.887 4.604-4.33 0-7.859-3.578-7.859-8s3.53-8 7.859-8c2.46 0 4.105 1.025 5.047 1.926l3.258-3.133C18.424 1.154 15.624 0 12.24 0 5.58 0 0 5.37 0 12s5.58 12 12.24 12c6.96 0 11.57-4.89 11.57-11.79 0-.795-.085-1.4-.195-1.925H12.24z"
                  />
                </svg>
                Continue with Google
              </button>

              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                  <div className="w-full border-t border-beige/40 dark:border-dark-border"></div>
                </div>
                <div className="relative flex justify-center text-xs font-mono font-bold uppercase tracking-wider">
                  <span className="bg-white px-3 text-gray-400 dark:bg-dark-panel">Or Email login</span>
                </div>
              </div>

              {/* Email/Password Form */}
              <form onSubmit={handleEmailAction} className="space-y-5">
                <div>
                  <label className="block text-xs font-mono font-semibold uppercase tracking-wider text-gray-400 mb-2">
                    E-mail address
                  </label>
                  <div className="relative rounded-xl shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                      <Mail className="w-4 h-4" />
                    </div>
                    <input
                      id="auth-input-email"
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. harmony@lunara.life"
                      className="block w-full pl-10 pr-4 py-3 border border-beige/50 dark:border-dark-border rounded-xl focus:outline-none focus:ring-1 focus:ring-lilac/50 focus:border-lilac bg-white/50 dark:bg-dark-bg text-sm placeholder-gray-400 dark:placeholder-gray-600 transition"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-xs font-mono font-semibold uppercase tracking-wider text-gray-400">
                      Password Key
                    </label>
                    <button
                      type="button"
                      onClick={() => setIsForgotPassword(true)}
                      className="text-xs text-gray-400 hover:text-lilac transition font-medium"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative rounded-xl shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      id="auth-input-password"
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Your secure secret key"
                      className="block w-full pl-10 pr-10 py-3 border border-beige/50 dark:border-dark-border rounded-xl focus:outline-none focus:ring-1 focus:ring-lilac/50 focus:border-lilac bg-white/50 dark:bg-dark-bg text-sm placeholder-gray-400 dark:placeholder-gray-600 transition"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-lilac"
                    >
                      {showPassword ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                    </button>
                  </div>
                </div>

                {isSignUp && (
                  <div className="p-3.5 rounded-xl bg-beige/10 dark:bg-dark-bg/40 border border-beige/30 dark:border-dark-border text-[10px] text-gray-400 italic">
                    Note: Email/Password login operates seamlessly. Be sure Email Authentication is toggled true in your Firebase Auth suite configuration.
                  </div>
                )}

                <button
                  id="btn-auth-submit"
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3.5 px-4 rounded-xl bg-charcoal text-white dark:bg-white dark:text-charcoal hover:bg-opacity-95 text-sm font-medium shadow-md hover:shadow-lg transition duration-200 block text-center disabled:opacity-50"
                >
                  {isLoading ? 'Processing...' : isSignUp ? 'Establish Free Sanctuary' : 'Unlock Sanctuary Dashboard'}
                </button>
              </form>

              <div className="text-center pt-3 border-t border-beige/25">
                <button
                  id="btn-toggle-signup"
                  onClick={() => {
                    setIsSignUp(!isSignUp);
                    cleanInputs();
                  }}
                  className="text-xs text-charcoal/70 dark:text-gray-400 hover:text-lilac transition font-bold"
                >
                  {isSignUp 
                    ? 'Already established? Access here' 
                    : 'New to Lunara? Build your premium cloud diary today'}
                </button>
              </div>
            </div>
          ) : (
            /* Forgot Password Form */
            <form onSubmit={handlePasswordReset} className="space-y-6">
              <div>
                <label className="block text-xs font-mono font-semibold uppercase tracking-wider text-gray-400 mb-2">
                  E-mail address
                </label>
                <div className="relative rounded-xl shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    id="auth-reset-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. harmony@lunara.life"
                    className="block w-full pl-10 pr-4 py-3 border border-beige/50 dark:border-dark-border rounded-xl focus:outline-none focus:ring-1 focus:ring-lilac/50 focus:border-lilac bg-white/50 dark:bg-warm-white text-sm placeholder-gray-400 transition"
                  />
                </div>
              </div>

              <button
                id="btn-auth-send-reset"
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 px-4 rounded-xl bg-charcoal text-white dark:bg-white dark:text-charcoal font-medium text-sm shadow-md transition duration-200 block text-center"
              >
                {isLoading ? 'Dispatching...' : 'Dispatch Reset Email'}
              </button>

              <div className="text-center pt-3 border-t border-beige/25">
                <button
                  type="button"
                  id="btn-reset-cancel"
                  onClick={() => {
                    setIsForgotPassword(false);
                    cleanInputs();
                  }}
                  className="text-xs text-lilac font-bold"
                >
                  Return to credentials
                </button>
              </div>
            </form>
          )}

        </div>
      </div>
    </div>
  );
}
