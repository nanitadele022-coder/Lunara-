/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { 
  Sparkles, 
  ArrowRight, 
  Compass, 
  Target, 
  Smile, 
  Heart 
} from 'lucide-react';

interface OnboardingProps {
  onComplete: (onboardingData: {
    role: string;
    focusAreas: string[];
    idealMood: string;
  }) => void;
}

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(1);
  const [selectedRole, setSelectedRole] = useState('');
  const [selectedFocus, setSelectedFocus] = useState<string[]>([]);
  const [selectedMood, setSelectedMood] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const roles = [
    { id: 'creator', label: 'Creator / Artist', desc: 'Focus on flow, expression, and ideas' },
    { id: 'entrepreneur', label: 'Entrepreneur / Leader', desc: 'Track outcomes, budget, and SMART aims' },
    { id: 'student', label: 'Student / Scholar', desc: 'Manage time-blocking, class calendars, and habits' },
    { id: 'professional', label: 'Young Professional', desc: 'Maintain work-life balance and active objectives' }
  ];

  const focusOptions = [
    { id: 'planner', label: 'Daily Scheduling', icon: '📅' },
    { id: 'habits', label: 'Continuous Habits & Streaks', icon: '🔥' },
    { id: 'budget', label: 'Mindful Budget Ledger', icon: '🧮' },
    { id: 'journal', label: 'Reflective Visual Journals', icon: '✍️' },
    { id: 'goals', label: 'SMART Milestone Plans', icon: '🎯' }
  ];

  const moods = [
    { id: 'calm', label: 'Calmness & Serenity', subtitle: 'Reduce pacing anxiety' },
    { id: 'focused', label: 'Focus & Productivity', subtitle: 'Finish priority targets' },
    { id: 'inspired', label: 'Inspiration & Creativity', subtitle: 'Unleash expansive mindsets' },
    { id: 'grateful', label: 'Gratitude & Balance', subtitle: 'Acknowledge simple joy' }
  ];

  const toggleFocus = (id: string) => {
    if (selectedFocus.includes(id)) {
      setSelectedFocus(selectedFocus.filter(item => item !== id));
    } else {
      setSelectedFocus([...selectedFocus, id]);
    }
  };

  const handleSubmit = async () => {
    if (!auth.currentUser) return;
    setIsSubmitting(true);
    const userId = auth.currentUser.uid;
    const userEmail = auth.currentUser.email || '';
    const userDisplayName = auth.currentUser.displayName || 'Venerated Planner';

    try {
      // Save profile context to Firestore
      const path = `users/${userId}`;
      await setDoc(doc(db, 'users', userId), {
        uid: userId,
        email: userEmail,
        displayName: userDisplayName,
        onboardingCompleted: true,
        onboardingDetails: {
          role: selectedRole || 'explorer',
          focusAreas: selectedFocus,
          idealMood: selectedMood || 'calm'
        },
        themePreference: 'light',
        createdAt: new Date().toISOString()
      });

      onComplete({
        role: selectedRole,
        focusAreas: selectedFocus,
        idealMood: selectedMood
      });
    } catch (error) {
      console.error('Onboarding Firestore failure: ', error);
      handleFirestoreError(error, OperationType.WRITE, `users/${userId}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div id="onboarding-container" className="min-h-screen bg-warm-white dark:bg-dark-bg text-charcoal dark:text-gray-200 flex flex-col justify-between py-12 px-6 relative overflow-hidden">
      
      {/* Absolute decorative backdrops */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] right-[-10%] w-[600px] h-[600px] rounded-full bg-lavender/10 blur-[130px] animate-float"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-beige/30 dark:bg-lilac/5 blur-[120px] animate-float" style={{ animationDelay: '4s' }}></div>
      </div>

      {/* Progress header */}
      <div className="max-w-2xl mx-auto w-full relative z-10 flex justify-between items-center pb-6 border-b border-beige/30 dark:border-dark-border">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-lavender/20 flex items-center justify-center">
            <Sparkles className="w-4.5 h-4.5 text-lilac" />
          </div>
          <span className="font-serif text-lg font-bold">Lunara Setup</span>
        </div>
        <div className="flex items-center gap-1.5 font-mono text-[10px] uppercase font-bold tracking-wider text-gray-400">
          <span className={step >= 1 ? 'text-lilac' : ''}>Role</span>
          <span className="text-gray-300">•</span>
          <span className={step >= 2 ? 'text-lilac' : ''}>Focus</span>
          <span className="text-gray-300">•</span>
          <span className={step >= 3 ? 'text-lilac' : ''}>Intention</span>
        </div>
      </div>

      {/* Main card carousel */}
      <main className="max-w-xl mx-auto w-full relative z-10 my-auto py-12">
        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step-1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4 }}
              className="space-y-8"
            >
              <div className="space-y-2">
                <Compass className="w-8 h-8 text-lilac" />
                <h1 className="font-serif text-3xl md:text-4xl font-bold tracking-tight text-charcoal dark:text-white">How do you invest your days?</h1>
                <p className="text-gray-500 font-light text-sm">We choose the layout style according to your daily activities and focus.</p>
              </div>

              <div className="space-y-3">
                {roles.map((r) => {
                  const isChosen = selectedRole === r.id;
                  return (
                    <button
                      key={r.id}
                      id={`role-btn-${r.id}`}
                      onClick={() => setSelectedRole(r.id)}
                      className={`w-full p-4 rounded-2xl border text-left flex justify-between items-center transition-all ${
                        isChosen
                          ? 'bg-lavender/10 border-lavender/60 shadow-sm'
                          : 'bg-white/60 dark:bg-dark-panel/40 border-beige/40 dark:border-dark-border hover:bg-beige/10 dark:hover:bg-dark-panel'
                      }`}
                    >
                      <div>
                        <p className="font-semibold text-charcoal dark:text-white text-sm">{r.label}</p>
                        <p className="text-xs text-gray-500 font-light leading-normal mt-0.5">{r.desc}</p>
                      </div>
                      <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                        isChosen ? 'border-lilac bg-lilac' : 'border-gray-300'
                      }`}>
                        {isChosen && <div className="w-2 h-2 rounded-full bg-white"></div>}
                      </div>
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step-2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4 }}
              className="space-y-8"
            >
              <div className="space-y-2">
                <Target className="w-8 h-8 text-lilac" />
                <h1 className="font-serif text-3xl md:text-4xl font-bold tracking-tight">What are your primary areas of focus?</h1>
                <p className="text-gray-500 font-light text-sm">Select as many modules as you intend to integrate in your main workflow.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {focusOptions.map((f) => {
                  const isChosen = selectedFocus.includes(f.id);
                  return (
                    <button
                      key={f.id}
                      id={`focus-btn-${f.id}`}
                      onClick={() => toggleFocus(f.id)}
                      className={`p-4 rounded-2xl border text-left flex flex-col justify-between h-28 transition-all ${
                        isChosen
                          ? 'bg-lavender/10 border-lavender/60 shadow-sm'
                          : 'bg-white/60 dark:bg-dark-panel/40 border-beige/40 dark:border-dark-border hover:bg-beige/10 dark:hover:bg-dark-panel'
                      }`}
                    >
                      <span className="text-2xl">{f.icon}</span>
                      <span className="font-semibold text-xs tracking-tight text-charcoal dark:text-white">{f.label}</span>
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step-3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4 }}
              className="space-y-8"
            >
              <div className="space-y-2">
                <Smile className="w-8 h-8 text-lilac" />
                <h1 className="font-serif text-3xl md:text-4xl font-bold tracking-tight">Set your ideal intention flow</h1>
                <p className="text-gray-500 font-light text-sm">Select an emotional compass point that defines your wellness intentions today.</p>
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                {moods.map((m) => {
                  const isChosen = selectedMood === m.id;
                  return (
                    <button
                      key={m.id}
                      id={`mood-btn-${m.id}`}
                      onClick={() => setSelectedMood(m.id)}
                      className={`p-4 rounded-2xl border text-left flex flex-col justify-between h-32 transition-all ${
                        isChosen
                          ? 'bg-lavender/10 border-lavender/60 shadow-md translate-y-[-1px]'
                          : 'bg-white/60 dark:bg-dark-panel/40 border-beige/40 dark:border-dark-border hover:bg-beige/10 dark:hover:bg-dark-panel'
                      }`}
                    >
                      <span className="font-semibold text-xs tracking-tight text-charcoal dark:text-gray-100">{m.label}</span>
                      <span className="text-[10px] text-gray-400 font-light leading-normal">{m.subtitle}</span>
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Button navigation deck */}
      <footer className="max-w-2xl mx-auto w-full relative z-10 flex justify-between items-center pt-6 border-t border-beige/30 dark:border-dark-border">
        <div>
          {step > 1 && (
            <button
              id="btn-onboarding-back"
              onClick={() => setStep(step - 1)}
              className="px-5 py-2 hover:bg-beige/15 text-charcoal dark:text-gray-300 font-medium text-xs font-mono uppercase tracking-wider rounded-xl transition duration-150"
            >
              Back
            </button>
          )}
        </div>

        <button
          id="btn-onboarding-next"
          onClick={() => {
            if (step === 3) {
              handleSubmit();
            } else {
              setStep(step + 1);
            }
          }}
          disabled={
            (step === 1 && !selectedRole) ||
            (step === 2 && selectedFocus.length === 0) ||
            (step === 3 && !selectedMood) ||
            isSubmitting
          }
          className="px-6 py-3 bg-charcoal text-white dark:bg-white dark:text-charcoal shadow hover:opacity-90 disabled:opacity-40 rounded-xl font-medium text-xs font-mono uppercase tracking-widest flex items-center gap-1.5 transition"
        >
          {isSubmitting ? 'Establishing Space...' : step === 3 ? 'Sync Sanctuary' : 'Next Step'}
          {step < 3 && <ArrowRight className="w-3.5 h-3.5" />}
        </button>
      </footer>
    </div>
  );
}
