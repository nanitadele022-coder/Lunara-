/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  ArrowRight, 
  Check, 
  Calendar, 
  Activity, 
  Heart, 
  TrendingUp, 
  PenTool, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  Star 
} from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
  onLoginClick: () => void;
}

export default function LandingPage({ onGetStarted, onLoginClick }: LandingPageProps) {
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [activeFeatureTab, setActiveFeatureTab] = useState<'planner' | 'tracker' | 'budget' | 'journal' | 'goals'>('planner');

  const faqs = [
    {
      q: "What makes Lunara different from other digital planners?",
      a: "Lunara combines a rich set of features (daily schedule, budget, journal, habits, and goals) with an emotionally calming aesthetic. We focus on premium, distraction-free typography and custom wellness-first interactions to help you stay present and motivated."
    },
    {
      q: "Does my data sync automatically across multiple devices?",
      a: "Yes. Once you sign up with a Lunara account, your planners, trackers, and journals are securely backed up to our cloud and synced in absolute real-time."
    },
    {
      q: "Is Lunara completely free to use?",
      a: "Our core planners and trackers are 100% free with unlimited standard logging. We also offer a premium tier for $8/month that unlocks analytics charts, custom templates, and advanced export features."
    },
    {
      q: "Can I export my journal and planner entries as PDFs?",
      a: "Absolutely. Under the Settings interface, you can generate clean, beautiful PDF documents of any daily notes, schedule, or tracker metrics."
    }
  ];

  const features = {
    planner: {
      title: "Daily & Weekly Schedule",
      desc: "Organize your days with priority tagging, modern progress trackers, and precise hour-by-hour time blocking.",
      benefit: "Reduce decision-paralysis and maintain task focus."
    },
    tracker: {
      title: "Daily Habit Ledger",
      desc: "Establish routine consistency with daily checkbox checks, continuous streak fires, and visual weekly metrics.",
      benefit: "Build permanent, positive lifestyle improvements."
    },
    budget: {
      title: "Mindful Budgeting",
      desc: "Log daily income and expense transactions. Filter by luxury categories and track target savings.",
      benefit: "Develop dynamic financial awareness and comfort."
    },
    journal: {
      title: "Reflective Visual Journal",
      desc: "Log thoughts, select emotional moods, and write freely under thoughtful, randomized daily guiding prompts.",
      benefit: "Prioritize mental clarity and self-expression."
    },
    goals: {
      title: "SMART Goal Engine",
      desc: "Create specific aspirations with interactive step-by-step milestones, progress bars, and custom vision boards.",
      benefit: "Transform massive abstract dreams into daily action."
    }
  };

  return (
    <div id="landing-container" className="min-h-screen bg-warm-white dark:bg-dark-bg text-charcoal dark:text-gray-100 overflow-x-hidden">
      
      {/* Decorative Blur Blobs */}
      <div className="absolute top-0 left-0 w-full h-[500px] overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-100px] left-[15%] w-[450px] h-[450px] rounded-full bg-lavender/25 dark:bg-lavender/10 blur-[130px] animate-float"></div>
        <div className="absolute top-[100px] right-[10%] w-[400px] h-[400px] rounded-full bg-lilac/20 dark:bg-lilac/10 blur-[120px] animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Elegant Header */}
      <header id="landing-header" className="relative z-10 max-w-7xl mx-auto px-6 py-6 flex items-center justify-between border-b border-beige/30 dark:border-dark-border">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-lavender/20 flex items-center justify-center border border-lavender/40">
            <Sparkles className="w-5 h-5 text-lilac" />
          </div>
          <span className="font-serif text-2xl font-bold tracking-tight text-charcoal dark:text-white">Lunara</span>
        </div>
        
        <div className="flex items-center gap-4">
          <button 
            id="btn-login-header"
            onClick={onLoginClick}
            className="px-5 py-2 text-sm font-medium hover:text-lilac transition duration-200"
          >
            Sign In
          </button>
          <button 
            id="btn-cta-header"
            onClick={onGetStarted}
            className="px-5 py-2.5 text-sm font-medium bg-charcoal text-white dark:bg-white dark:text-charcoal rounded-xl shadow-md hover:shadow-lg hover:translate-y-[-1px] transition-all duration-200"
          >
            Access Planner
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section id="hero-section" className="relative z-10 max-w-5xl mx-auto text-center px-6 pt-20 pb-16">
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-beige/30 dark:bg-dark-panel/80 border border-beige/60 dark:border-dark-border text-xs font-medium tracking-wide text-charcoal dark:text-lavender mb-6"
        >
          <Sparkles className="w-3.5 h-3.5 text-lilac" />
          The Calming Digital Sanctuary for Achievers
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="font-serif text-5xl md:text-7xl font-bold tracking-tight text-charcoal dark:text-white leading-[1.15] mb-6"
        >
          Plan your days, <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-lilac to-lavender">
            nurture your mind.
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-lg md:text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto font-light leading-relaxed mb-10"
        >
          An exquisite luxury planner space combining schedules, budgets, habit streaks, SMART goals, and reflective journals into one visually stunning workspace.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center"
        >
          <button 
            id="hero-get-started"
            onClick={onGetStarted}
            className="w-full sm:w-auto px-8 py-4 bg-charcoal text-white dark:bg-white dark:text-charcoal rounded-xl shadow-lg hover:shadow-xl hover:translate-y-[-2px] transition-all duration-200 font-medium flex items-center justify-center gap-2 text-md"
          >
            Begin Your Onboarding
            <ArrowRight className="w-4 h-4 ml-1" />
          </button>
          
          <button 
            id="hero-sign-in"
            onClick={onLoginClick}
            className="w-full sm:w-auto px-8 py-4 bg-white/60 dark:bg-dark-panel/60 border border-beige/50 dark:border-dark-border text-charcoal dark:text-white rounded-xl hover:bg-beige/20 dark:hover:bg-dark-panel transition duration-200 text-md"
          >
            Sign In with Google
          </button>
        </motion.div>
      </section>

      {/* Feature Showcase Tab Section */}
      <section id="features-section" className="relative z-10 max-w-6xl mx-auto px-6 py-20 border-t border-b border-beige/20 dark:border-dark-border">
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl md:text-4xl text-charcoal dark:text-white font-bold mb-4">Master Every Sphere of Focus</h2>
          <p className="text-gray-500 max-w-lg mx-auto font-light">Choose a category to preview how Lunara elegantly organizes your lifestyle metrics.</p>
        </div>

        {/* Feature selection tabs */}
        <div className="flex flex-wrap justify-center gap-3 mb-10">
          {(Object.keys(features) as Array<keyof typeof features>).map((key) => {
            const isActive = activeFeatureTab === key;
            return (
              <button
                key={key}
                id={`tab-feature-${key}`}
                onClick={() => setActiveFeatureTab(key)}
                className={`flex items-center gap-2 px-5 py-3 rounded-2xl border text-sm transition-all duration-300 ${
                  isActive 
                    ? 'bg-lavender/10 text-lilac border-lavender font-medium shadow-sm'
                    : 'bg-white/40 dark:bg-dark-panel/40 border-beige/30 hover:bg-white/80 dark:hover:bg-dark-panel'
                }`}
              >
                {key === 'planner' && <Calendar className="w-4 h-4" />}
                {key === 'tracker' && <Activity className="w-4 h-4" />}
                {key === 'budget' && <TrendingUp className="w-4 h-4" />}
                {key === 'journal' && <PenTool className="w-4 h-4" />}
                {key === 'goals' && <Sparkles className="w-4 h-4" />}
                <span className="capitalize">{key}</span>
              </button>
            );
          })}
        </div>

        {/* Dynamic Showcase Panel */}
        <div className="grid md:grid-cols-2 gap-8 items-center bg-white/40 dark:bg-dark-panel/40 p-8 rounded-3xl border border-beige/20 dark:border-dark-border backdrop-blur-md">
          <motion.div
            key={activeFeatureTab}
            initial={{ opacity: 0, x: -15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-6"
          >
            <span className="text-xs tracking-widest font-mono font-semibold uppercase text-lilac">Interactive Module Preview</span>
            <h3 className="font-serif text-3xl font-bold text-charcoal dark:text-white">{features[activeFeatureTab].title}</h3>
            <p className="text-gray-600 dark:text-gray-300 font-light leading-relaxed text-md">{features[activeFeatureTab].desc}</p>
            
            <div className="p-4 rounded-2xl bg-warm-white dark:bg-dark-bg/60 border border-beige/30 dark:border-dark-border">
              <span className="text-xs font-medium text-gray-400 dark:text-gray-500 block mb-1">Key Psychological Benefit:</span>
              <p className="text-sm font-medium text-charcoal dark:text-gray-200">{features[activeFeatureTab].benefit}</p>
            </div>

            <button 
              id="cta-preview-onboarding"
              onClick={onGetStarted}
              className="px-6 py-3 bg-charcoal text-white dark:bg-white dark:text-charcoal rounded-xl text-sm font-medium hover:opacity-90 flex items-center gap-2 shadow-sm"
            >
              Start Planning Now
              <ArrowRight className="w-4 h-4" />
            </button>
          </motion.div>

          <div className="relative group overflow-hidden rounded-2xl border border-beige/45 dark:border-dark-border h-64 md:h-80 bg-warm-white dark:bg-dark-bg p-6 flex flex-col justify-between shadow-inner">
            {/* Beautiful visual UI mock based on selected feature tab */}
            {activeFeatureTab === 'planner' && (
              <div className="space-y-4 h-full flex flex-col justify-center">
                <div className="flex justify-between items-center pb-2 border-b border-beige/20">
                  <span className="font-serif text-lg font-bold text-charcoal dark:text-white">Daily Planner & Tasks</span>
                  <span className="text-xs font-mono px-2 py-0.5 bg-lavender/20 text-lilac rounded">May 26</span>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-3 p-3 bg-lavender/5 border border-lavender/35 rounded-xl">
                    <div className="w-5 h-5 rounded-full border-2 border-lilac flex items-center justify-center">
                      <div className="w-2.5 h-2.5 rounded-full bg-lilac"></div>
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-charcoal dark:text-white">Morning Reflection & Journaling</p>
                      <p className="text-[10px] text-gray-400 font-mono">08:00 - 08:30 • High priority</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-white/50 dark:bg-dark-panel/50 border border-beige/10 rounded-xl">
                    <div className="w-5 h-5 rounded-full border-2 border-beige flex items-center justify-center"></div>
                    <div>
                      <p className="text-xs font-medium text-gray-500">Entrepreneurship Pitch Deck Draft</p>
                      <p className="text-[10px] text-gray-400 font-mono">09:00 - 11:30 • Medium priority</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeFeatureTab === 'tracker' && (
              <div className="space-y-4 h-full flex flex-col justify-center">
                <div className="flex justify-between items-center pb-2 border-b border-beige/20">
                  <span className="font-serif text-lg font-bold">Daily Habits</span>
                  <span className="text-xs px-2.5 py-1 bg-amber-500/10 text-amber-600 rounded-full font-serif flex items-center gap-1 font-semibold">
                    🔥 12 Day Streak
                  </span>
                </div>
                <div className="grid grid-cols-7 gap-2 text-center text-xs text-gray-400 font-mono py-1">
                  <span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span><span>S</span>
                </div>
                <div className="grid grid-cols-7 gap-2 text-center pb-2">
                  {[true, true, true, true, true, false, false].map((active, i) => (
                    <div key={i} className={`h-8 rounded-lg flex items-center justify-center font-mono ${
                      active ? 'bg-lilac text-white font-bold' : 'bg-beige/20 border border-beige/35 text-gray-300'
                    }`}>
                      {20 + i}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeFeatureTab === 'budget' && (
              <div className="space-y-4 h-full flex flex-col justify-center">
                <div className="flex justify-between items-center pb-2 border-b border-beige/20">
                  <span className="font-serif text-lg font-bold">Aesthetic Ledger</span>
                  <span className="text-xs text-emerald-600 font-semibold font-mono">Balance: +$4,120</span>
                </div>
                <div className="space-y-2 text-xs font-mono">
                  <div className="flex justify-between p-2 bg-emerald-500/5 text-emerald-700 dark:text-emerald-400 rounded-lg">
                    <span>Freelance Dev Invoicing</span>
                    <span className="font-bold">+$1,500.00</span>
                  </div>
                  <div className="flex justify-between p-2 bg-amber-500/5 text-amber-700 dark:text-amber-400 rounded-lg">
                    <span>Co-working Hub Coffee</span>
                    <span className="font-bold">-$12.50</span>
                  </div>
                </div>
              </div>
            )}

            {activeFeatureTab === 'journal' && (
              <div className="space-y-2 h-full flex flex-col justify-center">
                <div className="flex gap-2">
                  <span className="text-xl">✨</span>
                  <div>
                    <h4 className="text-xs font-bold text-lilac font-serif italic">Morning Intention Prompt:</h4>
                    <p className="text-xs text-charcoal dark:text-gray-300 font-light italic mt-1">"What element of nature is inspiring your thoughts today?"</p>
                  </div>
                </div>
                <div className="p-3 bg-warm-white dark:bg-dark-panel border border-beige/30 dark:border-dark-border rounded-xl text-xs text-gray-500 italic font-serif leading-relaxed">
                  "The light breaking through the office lavender orchids feels calming. I want to build things today that echo that absolute focus..."
                </div>
              </div>
            )}

            {activeFeatureTab === 'goals' && (
              <div className="space-y-4 h-full flex flex-col justify-center">
                <div className="flex justify-between items-center">
                  <span className="font-serif text-sm font-bold">🎨 Creative Launch: Portfolio 2.0</span>
                  <span className="text-[10px] font-mono font-medium text-lilac">Category: Creative</span>
                </div>
                <div className="w-full bg-beige/20 rounded-full h-2">
                  <div className="bg-lilac h-2 rounded-full" style={{ width: '70%' }}></div>
                </div>
                <div className="flex justify-between text-[11px] font-mono">
                  <span className="text-gray-400">Progress: 70%</span>
                  <span className="text-lilac font-bold">2/3 Milestones</span>
                </div>
              </div>
            )}

            {/* Glowing background hint inside visual mockup */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-lavender/5 to-transparent z-0 pointer-events-none"></div>
          </div>
        </div>
      </section>

      {/* Social Proof / Testimonials */}
      <section id="testimonials-section" className="relative z-10 max-w-6xl mx-auto px-6 py-20 bg-warm-white dark:bg-dark-bg">
        <div className="text-center mb-16">
          <h2 className="font-serif text-3xl md:text-5xl font-bold mb-4">Adored by Professionals & Creators</h2>
          <p className="text-gray-500 max-w-lg mx-auto font-light leading-relaxed">Hear from those who elevated their focus of mind using our sanctuary workspace.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              text: "Lunara transformed how I start my creative days. The visual lavender color theme immediately reduces my heart rate, and tracking goals alongside financial metrics in one card view is unmatched.",
              user: "Maya Sterling",
              role: "Creative Director"
            },
            {
              text: "Email checklists always stressed me out. Having a clean daily planner with premium typography that operates in local and cloud modes feels like writing in a luxurious leather-bound journal.",
              user: "Dr. Alexander Thorne",
              role: "Research Scientist"
            },
            {
              text: "Entering my incomes, expenses, habits, and mood indexes inside Lunara keeps my mental clarity in peak shape. Its Apple-like luxury aesthetics are a masterclass in modern digital design.",
              user: "Gabriela Vance",
              role: "Software Entrepreneur"
            }
          ].map((test, index) => (
            <div key={index} className="p-8 rounded-3xl bg-white dark:bg-dark-panel border border-beige/40 dark:border-dark-border shadow-sm flex flex-col justify-between space-y-6">
              <div className="flex gap-1 text-amber-500">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-amber-500" />)}
              </div>
              <p className="text-gray-600 dark:text-gray-300 italic font-light text-md text-slate-600">"{test.text}"</p>
              <div>
                <p className="font-serif font-bold text-charcoal dark:text-white">{test.user}</p>
                <p className="text-xs font-mono text-gray-400">{test.role}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Calming Pricing Card Section */}
      <section id="pricing-section" className="relative z-10 max-w-4xl mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <h2 className="font-serif text-3xl md:text-5xl font-bold mb-4">Simple, transparent pricing</h2>
          <p className="text-gray-500 text-sm font-light">Bring peaceful flow to your schedule. Choose an experience.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Card: Standard Planner */}
          <div className="p-8 rounded-3xl bg-white/60 dark:bg-dark-panel/40 border border-beige/40 dark:border-dark-border flex flex-col justify-between space-y-8 backdrop-blur-md">
            <div>
              <span className="text-xs font-mono font-bold tracking-wider uppercase text-gray-400">STANDARD GLOW</span>
              <h3 className="font-serif text-3xl font-bold mt-2">Free</h3>
              <p className="text-gray-500 text-sm font-light mt-3">The essential calming digital journal for standard daily focus.</p>
              
              <ul className="space-y-3.5 mt-8 text-sm">
                <li className="flex items-center gap-3 text-slate-600 dark:text-gray-300">
                  <Check className="w-4 h-4 text-lilac flex-shrink-0" />
                  Unlimited daily scheduler logging
                </li>
                <li className="flex items-center gap-3 text-slate-600 dark:text-gray-300">
                  <Check className="w-4 h-4 text-lilac flex-shrink-0" />
                  Logging of up to 3 active habits
                </li>
                <li className="flex items-center gap-3 text-slate-600 dark:text-gray-300">
                  <Check className="w-4 h-4 text-lilac flex-shrink-0" />
                  Aesthetic ledger & budget records
                </li>
                <li className="flex items-center gap-3 text-slate-600 dark:text-gray-300">
                  <Check className="w-4 h-4 text-lilac flex-shrink-0" />
                  Basic reflection journal prompts
                </li>
              </ul>
            </div>
            
            <button 
              id="pricing-free-btn"
              onClick={onGetStarted}
              className="w-full py-3 px-4 rounded-xl border border-charcoal/30 hover:bg-beige/10 font-medium text-sm transition transition-all duration-200"
            >
              Get Started Free
            </button>
          </div>

          {/* Card: Premium Planner */}
          <div className="p-8 rounded-3xl bg-white dark:bg-dark-panel border-2 border-lavender flex flex-col justify-between space-y-8 relative shadow-lg">
            <div className="absolute top-4 right-4 px-3 py-1 bg-lavender/30 text-lilac rounded-full text-[10px] font-mono font-bold">
              RECOMMENDED
            </div>

            <div>
              <span className="text-xs font-mono font-bold tracking-wider uppercase text-lilac">COSMIC PREMIUM</span>
              <h3 className="font-serif text-3xl font-bold mt-2">$8<span className="text-sm font-light text-gray-500"> / month</span></h3>
              <p className="text-gray-500 text-sm font-light mt-3">Comprehensive metrics sync with robust export tools and infinite capacity.</p>
              
              <ul className="space-y-3.5 mt-8 text-sm">
                <li className="flex items-center gap-3 text-slate-600 dark:text-gray-300">
                  <Check className="w-4 h-4 text-lilac flex-shrink-0" />
                  <strong>Everything in Free</strong> plus:
                </li>
                <li className="flex items-center gap-3 text-slate-600 dark:text-gray-300">
                  <Check className="w-4 h-4 text-lilac flex-shrink-0" />
                  Unlimited habit streak checklists
                </li>
                <li className="flex items-center gap-3 text-slate-600 dark:text-gray-300">
                  <Check className="w-4 h-4 text-lilac flex-shrink-0" />
                  Export schedules & summaries as beautifully styled PDFs
                </li>
                <li className="flex items-center gap-3 text-slate-600 dark:text-gray-300">
                  <Check className="w-4 h-4 text-lilac flex-shrink-0" />
                  SMART Goals & multi-image vision boards
                </li>
                <li className="flex items-center gap-3 text-slate-600 dark:text-gray-300">
                  <Check className="w-4 h-4 text-lilac flex-shrink-0" />
                  Advanced analytics & category statistics
                </li>
                <li className="flex items-center gap-3 text-slate-600 dark:text-gray-300">
                  <Check className="w-4 h-4 text-lilac flex-shrink-0" />
                  Secure Google cloud-sync backup
                </li>
              </ul>
            </div>
            
            <button 
              id="pricing-premium-btn"
              onClick={onGetStarted}
              className="w-full py-4 px-4 rounded-xl bg-charcoal text-white dark:bg-white dark:text-charcoal hover:bg-opacity-90 font-medium text-sm text-center shadow-md transition duration-200"
            >
              Unlock Premium Space
            </button>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq-section" className="relative z-10 max-w-3xl mx-auto px-6 py-20">
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl font-bold">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => {
            const isOpen = activeFaq === index;
            return (
              <div 
                key={index} 
                className="rounded-2xl border border-beige/40 dark:border-dark-border bg-white/40 dark:bg-dark-panel/40 overflow-hidden"
              >
                <button
                  id={`faq-btn-${index}`}
                  onClick={() => setActiveFaq(isOpen ? null : index)}
                  className="w-full p-5 flex items-center justify-between text-left hover:bg-white/40 dark:hover:bg-dark-panel/50 transition duration-200"
                >
                  <span className="font-medium text-charcoal dark:text-white text-base">{faq.q}</span>
                  {isOpen ? <ChevronUp className="w-5 h-5 text-lilac" /> : <ChevronDown className="w-5 h-5 text-lilac" />}
                </button>
                
                <AnimatePresence>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: "auto" }}
                      exit={{ height: 0 }}
                      transition={{ duration: 0.2 }}
                      className="border-t border-beige/10 overflow-hidden"
                    >
                      <div className="p-5 text-sm text-gray-500 dark:text-gray-400 font-light leading-relaxed bg-white/10 dark:bg-dark-panel/10">
                        {faq.a}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </section>

      {/* Beautiful Footer */}
      <footer id="landing-footer" className="relative z-10 border-t border-beige/30 dark:border-dark-border bg-beige/10 dark:bg-dark-bg py-12 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-lavender/20 flex items-center justify-center">
              <Sparkles className="w-4.5 h-4.5 text-lilac" />
            </div>
            <span className="font-serif text-xl font-bold">Lunara</span>
          </div>

          <p className="text-xs text-gray-400 font-light text-center md:text-right">
            © 2026 Lunara digital wellness. All data safely synced in Firestore cloud servers. Crafted for high-fidelity mindfulness.
          </p>
        </div>
      </footer>

    </div>
  );
}
