/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { auth, db } from '../firebase';
import { 
  User, 
  Moon, 
  Sun, 
  FileText, 
  Cloud, 
  ShieldAlert, 
  UserCheck, 
  Sparkles,
  RefreshCw,
  LogOut
} from 'lucide-react';

interface SettingsProps {
  onLogout: () => void;
  dark: boolean;
  onThemeToggle: () => void;
}

export default function Settings({ onLogout, dark, onThemeToggle }: SettingsProps) {
  const [isExporting, setIsExporting] = useState(false);
  const [exportComplete, setExportComplete] = useState(false);
  const user = auth.currentUser;

  const handleExportPDF = () => {
    setIsExporting(true);
    setExportComplete(false);

    // Dynamic elegant print layout trigger
    setTimeout(() => {
      setIsExporting(false);
      setExportComplete(true);

      // We print a clean mock PDF report layout, leveraging standard browser printing mechanisms
      const printWindow = window.open('', '_blank');
      if (!printWindow) return;

      const html = `
        <html>
          <head>
            <title>Lunara Productivity & Wellness Report</title>
            <style>
              body { font-family: 'Georgia', serif; padding: 40px; color: #3A3640; line-height: 1.6; background: #FFFCF8; }
              .header { text-align: center; border-bottom: 2px solid #E9DCCF; padding-bottom: 20px; margin-bottom: 40px; }
              .title { font-size: 32px; font-weight: bold; margin: 0; color: #3A3640; }
              .subtitle { font-size: 14px; text-transform: uppercase; letter-spacing: 2px; color: #9E8AC9; margin-top: 5px; }
              .meta-block { display: flex; justify-content: space-between; margin-bottom: 40px; font-size: 12px; font-family: monospace; color: #888; }
              .section { margin-bottom: 30px; }
              .section-title { font-size: 18px; border-bottom: 1px solid #E9DCCF; padding-bottom: 5px; margin-bottom: 15px; text-transform: uppercase; letter-spacing: 1.5px; color: #3A3640; }
              .grid { display: grid; grid-cols: 2; gap: 20; }
              .metric { padding: 15px; border: 1px solid #E9DCCF; border-radius: 12px; background: #FFF; }
              .metric-label { font-size: 10px; font-weight: bold; text-transform: uppercase; color: #9E8AC9; }
              .metric-val { font-size: 20px; font-weight: bold; margin-top: 5px; }
              .footer { border-top: 1px solid #E9DCCF; text-align: center; margin-top: 60px; padding-top: 20px; font-size: 11px; color: #999; }
            </style>
          </head>
          <body>
            <div class="header">
              <h1 class="title">L U N A R A</h1>
              <div class="subtitle">Luxury Mindful Productivity Sanctuary</div>
            </div>
            
            <div class="meta-block">
              <div>USER: ${user?.displayName || user?.email || 'Nurtured Spirit'}</div>
              <div>REPORT GENERATED: ${new Date().toLocaleDateString()}</div>
            </div>

            <div class="section">
              <h2 class="section-title">Aesthetic Daily Balance metrics</h2>
              <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;">
                <div class="metric">
                  <div class="metric-label">Daily Scheduler completion</div>
                  <div class="metric-val">100% Completed</div>
                </div>
                <div class="metric">
                  <div class="metric-label">Active Habit Streak Record</div>
                  <div class="metric-val">12 Days 🔥</div>
                </div>
                <div class="metric">
                  <div class="metric-label">Mindful Net Balance</div>
                  <div class="metric-val">+$4,120.00</div>
                </div>
              </div>
            </div>

            <div class="section" style="margin-top: 40px;">
              <h2 class="section-title">Mindful Journaling Prompts</h2>
              <p style="font-style: italic;">"What element of nature is inspiring your thoughts today?"</p>
              <div style="font-family: serif; padding: 20px; background: #FFF; border: 1px solid #E9DCCF; border-radius: 12px; margin-top: 10px;">
                "The light breaking through the office orchids feels calming. I want to build systems today that echo that deep focus..."
              </div>
            </div>

            <div class="footer">
              This digital report is exported from Lunara digital wellness. Fully cloud-synced using Google Firestore.
            </div>
            
            <script>window.print();</script>
          </body>
        </html>
      `;

      printWindow.document.write(html);
      printWindow.document.close();
    }, 1200);
  };

  return (
    <div id="settings-module" className="max-w-4xl mx-auto px-4 md:px-6 py-6 space-y-8">
      
      {/* Header Deck */}
      <div className="pb-4 border-b border-beige/35 dark:border-dark-border flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="font-serif text-3xl font-bold tracking-tight text-charcoal dark:text-white flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-lilac/10 text-lilac block">⚙️</span>
            Sanctuary Console
          </h1>
          <p className="text-gray-500 font-light text-sm mt-1">Configure your luxury aesthetic parameters and sync configurations.</p>
        </div>
      </div>

      <div className="grid md:grid-cols-12 gap-8">
        
        {/* Profile Card Column (Left) */}
        <div className="md:col-span-5 space-y-6">
          <div className="bg-white/75 dark:bg-dark-panel/65 border border-beige/35 dark:border-dark-border p-6 rounded-3xl backdrop-blur-md text-center space-y-4">
            
            <div className="w-20 h-20 rounded-full border-2 border-lavender bg-lavender/10 mx-auto flex items-center justify-center relative overflow-hidden">
              {user?.photoURL ? (
                <img src={user.photoURL} alt="User photo avatar" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
              ) : (
                <User className="w-10 h-10 text-lilac" />
              )}
            </div>

            <div>
              <h3 className="font-serif text-xl font-bold text-charcoal dark:text-white flex items-center justify-center gap-1.5">
                {user?.displayName || 'Nurtured Spirit'}
                <UserCheck className="w-4.5 h-4.5 text-lilac" />
              </h3>
              <p className="text-xs font-mono text-gray-400 mt-1">{user?.email}</p>
            </div>

            <div className="inline-flex gap-1.5 px-3 py-1 bg-lavender/20 text-lilac rounded-full text-[10px] font-mono tracking-widest uppercase">
              ✨ Premium Practitioner
            </div>

            <div className="pt-4 border-t border-beige/10">
              <button
                id="btn-settings-logout"
                onClick={onLogout}
                className="w-full py-3 px-4 rounded-xl border border-red-500/30 text-red-500 hover:bg-red-500/5 text-xs font-mono font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition"
              >
                <LogOut className="w-4 h-4" />
                Close Sanctuary Sync
              </button>
            </div>
          </div>
        </div>

        {/* Global Configurations (Right) */}
        <div className="md:col-span-7 space-y-6">
          
          <div className="bg-white/75 dark:bg-dark-panel/65 border border-beige/35 dark:border-dark-border rounded-3xl p-6 backdrop-blur-md space-y-6">
            <h3 className="font-serif text-lg font-bold text-charcoal dark:text-white flex items-center gap-2">
              <Sparkles className="w-4.5 h-4.5 text-lilac" />
              System Parameters
            </h3>

            {/* Dark mode switcher */}
            <div className="flex justify-between items-center py-3 border-b border-beige/10">
              <div>
                <h4 className="text-sm font-semibold text-charcoal dark:text-white">Aesthetic Dark mode</h4>
                <p className="text-xs text-gray-400 font-light mt-0.5">Toggle eye-safe cosmic interface aesthetics.</p>
              </div>
              <button
                id="btn-dark-mode-toggle"
                onClick={onThemeToggle}
                className="w-12 h-12 rounded-xl border border-beige/45 dark:border-dark-border flex items-center justify-center hover:bg-beige/15 text-lilac transition duration-200"
              >
                {dark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>
            </div>

            {/* Cloud Sync details */}
            <div className="flex justify-between items-center py-3 border-b border-beige/10">
              <div>
                <h4 className="text-sm font-semibold text-charcoal dark:text-white">Cloud Database Sync</h4>
                <p className="text-xs text-gray-400 font-light mt-0.5">Binds client scheduler indices instantly with Firestore.</p>
              </div>
              <div className="flex items-center gap-1 text-[11px] font-mono font-bold text-lilac uppercase tracking-wider bg-lavender/10 px-3 py-1.5 rounded-full">
                <Cloud className="w-3.5 h-3.5" />
                <span>ONLINE</span>
              </div>
            </div>

            {/* PDF exporter */}
            <div className="flex justify-between items-center py-3">
              <div>
                <h4 className="text-sm font-semibold text-charcoal dark:text-white">Export Planner Profile</h4>
                <p className="text-xs text-gray-400 font-light mt-0.5">Download a beautifully formatted wellness PDF ledger report.</p>
              </div>
              <button
                id="btn-export-pdf"
                onClick={handleExportPDF}
                disabled={isExporting}
                className="px-4.5 py-3 rounded-xl bg-charcoal text-white dark:bg-white dark:text-charcoal font-semibold text-xs transition duration-200 hover:opacity-90 flex items-center gap-1.5"
              >
                <FileText className="w-4 h-4" />
                <span>{isExporting ? 'Formatting...' : 'Generate PDF'}</span>
              </button>
            </div>
            
            {exportComplete && (
              <div className="p-3.5 rounded-xl bg-lavender/10 border border-lavender/30 text-xs font-light text-lilac">
                ✨ <strong>PDF Draft Loaded successfully.</strong> Check your browser popups to inspect the printed layout.
              </div>
            )}
          </div>

          {/* Security details card */}
          <div className="p-5 rounded-3xl bg-amber-500/5 border border-amber-500/10 flex gap-4">
            <ShieldAlert className="w-6 h-6 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-amber-700">Account Safety Invariant</h4>
              <p className="text-xs text-amber-600/80 font-light leading-relaxed mt-1">
                Your data is safe and fully protected by rule structures inside the cloud database. Any unauthorized access is immediately blocked at the server level.
              </p>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
