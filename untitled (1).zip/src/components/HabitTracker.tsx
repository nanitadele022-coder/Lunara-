/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc 
} from 'firebase/firestore';
import { db, auth } from '../firebase';
import { Habit, HabitFrequency } from '../types';
import { 
  Plus, 
  Check, 
  Trash2, 
  Flame, 
  Award, 
  Activity, 
  Calendar, 
  Info, 
  Sparkles 
} from 'lucide-react';

export default function HabitTracker() {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [name, setName] = useState('');
  const [frequency, setFrequency] = useState<HabitFrequency>('daily');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const COLLECTION_PATH = 'habits';

  // Get date strings for the past 7 days (M, T, W, Th, F, Sa, Su)
  const getPastSevenDays = () => {
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
      days.push({ dateStr, dayName, d });
    }
    return days;
  };

  const daysList = getPastSevenDays();
  const todayStr = new Date().toISOString().split('T')[0];

  useEffect(() => {
    if (!auth.currentUser) return;
    const userId = auth.currentUser.uid;

    setIsLoading(true);
    const q = query(
      collection(db, COLLECTION_PATH),
      where('userId', '==', userId)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items: Habit[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        items.push({
          id: docSnap.id,
          userId: data.userId,
          name: data.name,
          frequency: data.frequency,
          streak: data.streak || 0,
          history: data.history || []
        });
      });
      setHabits(items);
      setIsLoading(false);
    }, (err) => {
      console.error(err);
      setError('Failed to fetch habit streaks securely.');
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleAddHabit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    if (!name.trim()) return;

    try {
      const payload = {
        userId: auth.currentUser.uid,
        name: name.trim(),
        frequency,
        streak: 0,
        history: [],
        createdAt: new Date().toISOString()
      };

      await addDoc(collection(db, COLLECTION_PATH), payload);
      setName('');
      setError(null);
    } catch (err) {
      console.error(err);
      setError('Could not establish habit card in cloud servers.');
    }
  };

  // Streaks recalculation helper
  const calculateStreak = (history: string[]): number => {
    const sorted = [...history].sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
    if (sorted.length === 0) return 0;

    let currentStreak = 0;
    const d = new Date();
    
    // Check if completed today or yesterday
    const today = d.toISOString().split('T')[0];
    d.setDate(d.getDate() - 1);
    const yesterday = d.toISOString().split('T')[0];

    if (!sorted.includes(today) && !sorted.includes(yesterday)) {
      return 0; // Streak broken
    }

    let checkD = new Date();
    while (true) {
      const checkStr = checkD.toISOString().split('T')[0];
      if (sorted.includes(checkStr)) {
        currentStreak++;
        checkD.setDate(checkD.getDate() - 1);
      } else {
        break;
      }
    }
    return currentStreak;
  };

  const toggleHabitDate = async (habit: Habit, dateStr: string) => {
    try {
      const hasCompleted = habit.history.includes(dateStr);
      let updatedHistory: string[];

      if (hasCompleted) {
        updatedHistory = habit.history.filter(d => d !== dateStr);
      } else {
        updatedHistory = [...habit.history, dateStr];
      }

      const calculated = calculateStreak(updatedHistory);

      await updateDoc(doc(db, COLLECTION_PATH, habit.id), {
        history: updatedHistory,
        streak: calculated
      });
    } catch (err) {
      console.error(err);
      setError('Failed to toggle completion cell.');
    }
  };

  const handleDeleteHabit = async (id: string) => {
    try {
      await deleteDoc(doc(db, COLLECTION_PATH, id));
    } catch (err) {
      console.error(err);
      setError('Failed to delete habit config.');
    }
  };

  return (
    <div id="habit-module" className="max-w-5xl mx-auto px-4 md:px-6 py-6 space-y-8">
      
      {/* Header Deck */}
      <div className="pb-4 border-b border-beige/35 dark:border-dark-border flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="font-serif text-3xl font-bold tracking-tight text-charcoal dark:text-white flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-lilac/10 text-lilac block">🔥</span>
            Habit Tracker
          </h1>
          <p className="text-gray-500 font-light text-sm mt-1">Develop lifelong routines through aesthetic daily tracking gates.</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        
        {/* Input panel component */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white/75 dark:bg-dark-panel/65 border border-beige/35 dark:border-dark-border p-6 rounded-3xl backdrop-blur-md">
            <h2 className="font-serif text-xl font-bold mb-4 text-charcoal dark:text-white flex items-center gap-1.5">
              <Plus className="w-4.5 h-4.5 text-lilac" />
              Incubate New Habit
            </h2>

            <form onSubmit={handleAddHabit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Habit Descriptor</label>
                <input
                  id="habit-form-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Drink 2.5L Water or Read 15 pages"
                  className="w-full px-4 py-3 border border-beige/40 dark:border-dark-border rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-lilac bg-white dark:bg-dark-bg text-charcoal dark:text-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400">Target Rhythm</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setFrequency('daily')}
                    className={`p-2.5 rounded-xl text-xs font-medium border text-center transition ${
                      frequency === 'daily'
                        ? 'bg-lavender/15 text-lilac border-lavender'
                        : 'bg-white/40 dark:bg-dark-bg/60 border-beige/30'
                    }`}
                  >
                    Daily
                  </button>
                  <button
                    type="button"
                    onClick={() => setFrequency('weekly')}
                    className={`p-2.5 rounded-xl text-xs font-medium border text-center transition ${
                      frequency === 'weekly'
                        ? 'bg-lavender/15 text-lilac border-lavender'
                        : 'bg-white/40 dark:bg-dark-bg/60 border-beige/30'
                    }`}
                  >
                    Weekly
                  </button>
                </div>
              </div>

              <button
                id="habit-form-submit"
                type="submit"
                className="w-full py-3 px-4 bg-charcoal text-white dark:bg-white dark:text-charcoal rounded-xl text-xs font-mono font-bold uppercase tracking-wide hover:opacity-90 transition shadow flex items-center justify-center gap-1.5"
              >
                Assemble Habit
              </button>
            </form>
          </div>

          {/* Badges Component */}
          <div className="bg-white/75 dark:bg-dark-panel/65 border border-beige/35 dark:border-dark-border p-6 rounded-3xl backdrop-blur-md space-y-4">
            <h3 className="font-serif text-lg font-bold text-charcoal dark:text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-lilac" />
              Streak Milestones
            </h3>
            
            <div className="space-y-3">
              {[
                { title: 'Streak Starter', desc: 'Maintain any habit for 3 consecutive days', req: 3 },
                { title: 'Consistent Mind', desc: 'Maintain any habit for 7 consecutive days', req: 7 },
                { title: 'Unshakable Will', desc: 'Reach a peak 14-day streak cycle', req: 14 }
              ].map((badge, i) => {
                const isEarned = habits.some(h => h.streak >= badge.req);
                return (
                  <div key={i} className={`p-3 rounded-2xl border flex items-center gap-3.5 transition-all ${
                    isEarned 
                      ? 'bg-lavender/10 border-lavender/40' 
                      : 'bg-white/30 dark:bg-dark-bg/30 border-beige/10 opacity-50'
                  }`}>
                    <span className="text-2xl">{isEarned ? '🏆' : '🔒'}</span>
                    <div>
                      <p className={`text-xs font-bold ${isEarned ? 'text-lilac' : 'text-gray-400'}`}>{badge.title}</p>
                      <p className="text-[10px] text-gray-400 font-light mt-0.5">{badge.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Habits list component */}
        <div className="lg:col-span-2 space-y-5">
          {isLoading ? (
            <div className="text-center py-12 text-sm text-gray-400 italic">Streaming habit history...</div>
          ) : habits.length === 0 ? (
            <div className="p-12 text-center rounded-3xl border-2 border-dashed border-beige/35 dark:border-dark-border/40 bg-white/25">
              <p className="text-gray-400 text-sm font-light italic">No habits logs active.</p>
              <p className="text-[11px] text-gray-400 font-mono mt-1">Implement habits using the form card nearby to ignite streaks.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {habits.map((h) => (
                <div 
                  key={h.id} 
                  className="bg-white dark:bg-dark-panel border border-beige/35 dark:border-dark-border rounded-3xl p-5 shadow-sm space-y-4"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-semibold text-charcoal dark:text-white text-md">{h.name}</h4>
                      <p className="text-[10px] font-mono text-gray-400 uppercase tracking-widest mt-1">Frequency: {h.frequency}</p>
                    </div>
                    
                    <div className="flex items-center gap-3.5">
                      <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-600 font-serif text-xs font-bold">
                        <Flame className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                        <span>{h.streak} Day Streak</span>
                      </div>
                      
                      <button
                        id={`habit-delete-${h.id}`}
                        onClick={() => handleDeleteHabit(h.id)}
                        className="text-gray-300 hover:text-red-500 p-1.5 transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* 7-day completion grid */}
                  <div className="pt-3 border-t border-beige/10">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400 block mb-3">Past 7 Days Logs</span>
                    <div className="grid grid-cols-7 gap-2.5">
                      {daysList.map((day) => {
                        const isDone = h.history.includes(day.dateStr);
                        const isToday = day.dateStr === todayStr;
                        return (
                          <button
                            key={day.dateStr}
                            id={`habit-${h.id}-day-${day.dateStr}`}
                            onClick={() => toggleHabitDate(h, day.dateStr)}
                            className="flex flex-col items-center gap-1.5 p-2 rounded-xl border border-beige/15 dark:border-dark-border/40 hover:bg-beige/10 transition-all text-center"
                          >
                            <span className="text-[9px] font-mono font-medium text-gray-400 uppercase">{day.dayName}</span>
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center border text-xs transition ${
                              isDone 
                                ? 'bg-lilac text-white border-lilac font-bold scale-105' 
                                : 'border-gray-200 dark:border-dark-border text-transparent'
                            }`}>
                              <Check className="w-3.5 h-3.5" />
                            </div>
                            <span className={`text-[8px] font-mono ${isToday ? 'text-lilac font-bold' : 'text-gray-400 font-light'}`}>
                              {day.d.getDate()}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
