/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from './firebase';

import LandingPage from './components/LandingPage';
import Auth from './components/Auth';
import Onboarding from './components/Onboarding';
import Dashboard from './components/Dashboard';
import DailyPlanner from './components/DailyPlanner';
import HabitTracker from './components/HabitTracker';
import BudgetTracker from './components/BudgetTracker';
import Journal from './components/Journal';
import GoalTracker from './components/GoalTracker';
import Settings from './components/Settings';

import { 
  Sparkles, 
  LayoutDashboard, 
  Calendar, 
  Flame, 
  TrendingUp, 
  PenTool, 
  Target, 
  Settings as SettingsIcon, 
  Menu, 
  X,
  LogOut,
  Sun,
  Moon
} from 'lucide-react';

type Tab = 'dashboard' | 'planner' | 'habits' | 'budget' | 'journal' | 'goals' | 'settings';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [onboardingCompleted, setOnboardingCompleted] = useState<boolean | null>(null);
  const [userIntention, setUserIntention] = useState('Flow');

  // Router view for guest users
  const [guestView, setGuestView] = useState<'landing' | 'auth'>('landing');

  // Navigation state for authorized users
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Theme support
  const [dark, setDark] = useState(false);

  // Track Firebase Auth lifecycle
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        // Fetch User's profile to inspect Onboarding status
        try {
          const userDoc = await getDoc(doc(db, 'users', user.uid));
          if (userDoc.exists()) {
            const data = userDoc.data();
            setOnboardingCompleted(!!data.onboardingCompleted);
            if (data.onboardingDetails?.idealMood) {
              setUserIntention(data.onboardingDetails.idealMood);
            }
          } else {
            setOnboardingCompleted(false); // Force onboarding flow
          }
        } catch (error) {
          console.error("Firestore auth sync check failure: ", error);
          setOnboardingCompleted(false);
        }
      } else {
        setOnboardingCompleted(null);
      }
      setAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleAuthSuccess = () => {
    setGuestView('landing');
  };

  const handleOnboardingComplete = (details: { idealMood: string }) => {
    setUserIntention(details.idealMood);
    setOnboardingCompleted(true);
    setActiveTab('dashboard');
  };

  const handleLogout = async () => {
    try {
      await auth.signOut();
      setActiveTab('dashboard');
      setGuestView('landing');
    } catch (error) {
      console.error(error);
    }
  };

  const toggleTheme = () => {
    setDark(!dark);
    document.documentElement.classList.toggle('dark');
  };

  if (authLoading) {
    return (
      <div id="loader-view" className="min-h-screen bg-warm-white dark:bg-dark-bg text-charcoal dark:text-gray-200 flex flex-col justify-center items-center gap-4">
        <div className="relative w-12 h-12 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-4 border-lavender/30 border-t-lilac animate-spin"></div>
          <Sparkles className="w-5.5 h-5.5 text-lilac" />
        </div>
        <p className="font-serif italic font-light tracking-wide text-sm opacity-85">Centering your digital sanctuary...</p>
      </div>
    );
  }

  // Not Logged In Flows
  if (!currentUser) {
    if (guestView === 'landing') {
      return (
        <div className={dark ? 'dark' : ''}>
          <LandingPage 
            onGetStarted={() => setGuestView('auth')} 
            onLoginClick={() => setGuestView('auth')} 
          />
        </div>
      );
    }
    return (
      <div className={dark ? 'dark' : ''}>
        <Auth 
          onBack={() => setGuestView('landing')} 
          onAuthSuccess={handleAuthSuccess} 
        />
      </div>
    );
  }

  // Logged In, but needs Onboarding
  if (onboardingCompleted === false) {
    return (
      <div className={dark ? 'dark' : ''}>
        <Onboarding onComplete={handleOnboardingComplete} />
      </div>
    );
  }

  // Main Premium Interface
  return (
    <div className={dark ? 'dark' : ''}>
      <div id="lunara-app-root" className="min-h-screen bg-warm-white dark:bg-dark-bg text-charcoal dark:text-gray-200 flex flex-col md:flex-row">
        
        {/* Decorative Top-Right Ambient Blob */}
        <div className="absolute top-0 right-0 w-[500px] h-[400px] bg-lavender/5 dark:bg-lavender/5 rounded-full blur-[120px] pointer-events-none z-0"></div>

        {/* --- DESKTOP SIDEBAR NAVIGATION PANEL --- */}
        <aside id="desktop-sidebar" className="hidden md:flex flex-col justify-between w-64 bg-white/70 dark:bg-dark-panel/90 border-r border-beige/40 dark:border-dark-border py-8 px-5 shrink-0 z-10 backdrop-blur-md">
          <div className="space-y-8">
            {/* Branding Logo */}
            <div className="flex items-center gap-2 px-2.5">
              <div className="w-8.5 h-8.5 rounded-xl bg-lavender/25 flex items-center justify-center border border-lavender/40">
                <Sparkles className="w-5 h-5 text-lilac" />
              </div>
              <span className="font-serif text-xl font-bold tracking-tight text-charcoal dark:text-white">Lunara</span>
            </div>

            {/* Navigation options list */}
            <nav className="space-y-1.5">
              {[
                { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
                { id: 'planner', label: 'Scheduler', icon: <Calendar className="w-4 h-4" /> },
                { id: 'habits', label: 'Habits Tracker', icon: <Flame className="w-4 h-4" /> },
                { id: 'budget', label: 'Ledger Planner', icon: <TrendingUp className="w-4 h-4" /> },
                { id: 'journal', label: 'Reflective Diary', icon: <PenTool className="w-4 h-4" /> },
                { id: 'goals', label: 'SMART Goals', icon: <Target className="w-4 h-4" /> },
                { id: 'settings', label: 'Sanctuary Console', icon: <SettingsIcon className="w-4 h-4" /> },
              ].map((tab) => {
                const active = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    id={`nav-btn-desktop-${tab.id}`}
                    onClick={() => setActiveTab(tab.id as Tab)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-semibold uppercase tracking-wider transition-all duration-200 ${
                      active
                        ? 'bg-lavender/10 text-lilac border border-lavender/20 shadow-sm'
                        : 'border border-transparent hover:bg-beige/10 hover:text-lilac'
                    }`}
                  >
                    {tab.icon}
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Sidebar bottom profiles */}
          <div className="space-y-4 pt-6 border-t border-beige/25">
            <div className="flex items-center justify-between px-2.5">
              <span className="text-[10px] font-mono font-bold text-gray-400">THEME MODE</span>
              <button
                id="btn-sidebar-theme"
                onClick={toggleTheme}
                className="p-1.5 hover:bg-beige/10 rounded-lg text-lilac"
              >
                {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>
            </div>

            <div className="flex items-center gap-3 px-2">
              <div className="w-9 h-9 rounded-full bg-lavender/25 flex items-center justify-center text-lilac font-serif border border-lavender/30 overflow-hidden">
                {currentUser.photoURL ? (
                  <img src={currentUser.photoURL} alt="User photo avatar" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                ) : (
                  currentUser.displayName?.charAt(0) || 'L'
                )}
              </div>
              <div className="overflow-hidden">
                <p className="text-xs font-bold truncate text-charcoal dark:text-white">
                  {currentUser.displayName || 'Venerated User'}
                </p>
                <button
                  id="btn-sidebar-logout"
                  onClick={handleLogout}
                  className="text-[10px] font-mono text-gray-400 hover:text-lilac flex items-center gap-1 transition mt-0.5"
                >
                  <LogOut className="w-3 h-3" /> Sign Out
                </button>
              </div>
            </div>
          </div>
        </aside>

        {/* --- MOBILE COMPACT HEADER --- */}
        <header id="mobile-navigation" className="md:hidden flex justify-between items-center px-6 py-4 bg-white dark:bg-dark-panel border-b border-beige/40 dark:border-dark-border relative z-20">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-lavender/20 flex items-center justify-center">
              <Sparkles className="w-4.5 h-4.5 text-lilac" />
            </div>
            <span className="font-serif text-lg font-bold">Lunara</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              id="btn-theme-mobile"
              onClick={toggleTheme}
              className="p-2 text-lilac"
            >
              {dark ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
            </button>
            <button
              id="btn-mobile-menu"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-charcoal hover:text-lilac"
            >
              {mobileMenuOpen ? <X className="w-5.5 h-5.5" /> : <Menu className="w-5.5 h-5.5" />}
            </button>
          </div>
        </header>

        {/* Mobile Navigation Dropdown lists */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              id="mobile-drawer"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="md:hidden bg-white dark:bg-dark-panel border-b border-beige/40 dark:border-dark-border absolute top-16 left-0 w-full p-6 space-y-4 z-15 shadow-xl"
            >
              <nav className="grid grid-cols-2 gap-2.5">
                {[
                  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-3.5 h-3.5" /> },
                  { id: 'planner', label: 'Scheduler', icon: <Calendar className="w-3.5 h-3.5" /> },
                  { id: 'habits', label: 'Habits', icon: <Flame className="w-3.5 h-3.5" /> },
                  { id: 'budget', label: 'Budget Ledger', icon: <TrendingUp className="w-3.5 h-3.5" /> },
                  { id: 'journal', label: 'Reflections', icon: <PenTool className="w-3.5 h-3.5" /> },
                  { id: 'goals', label: 'Aspirations', icon: <Target className="w-3.5 h-3.5" /> },
                  { id: 'settings', label: 'Console', icon: <SettingsIcon className="w-3.5 h-3.5" /> },
                ].map((tab) => {
                  const active = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      id={`nav-btn-mobile-${tab.id}`}
                      onClick={() => {
                        setActiveTab(tab.id as Tab);
                        setMobileMenuOpen(false);
                      }}
                      className={`flex items-center gap-2 p-3 rounded-xl border text-[10px] font-mono tracking-wider font-bold uppercase ${
                        active
                          ? 'bg-lavender/10 text-lilac border-lavender/30'
                          : 'bg-warm-white/10 border-transparent hover:bg-beige/10'
                      }`}
                    >
                      {tab.icon}
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
              </nav>

              <button
                id="btn-mobile-logout"
                onClick={() => {
                  handleLogout();
                  setMobileMenuOpen(false);
                }}
                className="w-full py-3 bg-red-500/10 text-red-600 rounded-xl text-[10px] uppercase font-mono font-bold tracking-widest block text-center"
              >
                Sign Out from Lunara
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* --- CORE CONTENT DASHBOARD ROUTER WORKSPACE --- */}
        <main id="lunara-main-workspace" className="flex-grow relative z-5 py-8 md:py-12 overflow-y-auto w-full md:max-w-4xl lg:max-w-5xl xl:max-w-6xl mx-auto px-4 sm:px-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              {activeTab === 'dashboard' && <Dashboard onNavClick={setActiveTab} userIntention={userIntention} />}
              {activeTab === 'planner' && <DailyPlanner />}
              {activeTab === 'habits' && <HabitTracker />}
              {activeTab === 'budget' && <BudgetTracker />}
              {activeTab === 'journal' && <Journal />}
              {activeTab === 'goals' && <GoalTracker />}
              {activeTab === 'settings' && (
                <Settings 
                  onLogout={handleLogout} 
                  dark={dark} 
                  onThemeToggle={toggleTheme} 
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>

      </div>
    </div>
  );
}
